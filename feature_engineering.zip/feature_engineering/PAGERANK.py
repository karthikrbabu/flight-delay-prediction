# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## PAGERANK 
# MAGIC 
# MAGIC As we have seen there is a clear positive skew in the business of airports across the country. We have seen that **ORD** or **ATL** are two of the busiest airports, while there are hundreds of other airports that operate on a much smaller scale.
# MAGIC 
# MAGIC ##### Goal:
# MAGIC Use the NetworkX Graph library to analyze the underlying flow of traffic at all US airports via Pagerank.
# MAGIC 
# MAGIC ##### Hypothesis:
# MAGIC By calculating the **Pagerank**(popularity) of an airport, we are able to capture the network flow that exists amongst airports in the US. This score would reflect the random chance of traveller ending up at a given airport. We hope to see a meaningful correlation between Pagerank and `DEP_DEL15` whether that is positive or negative. As we get to modelling stages, we will experiment with `ORIGIN_PAGERANK` and `DEST_PAGERANK` both as features.

# COMMAND ----------

import networkx as nx
import numpy as np
import pandas as pd
import plotly.express as px
import collections
import math


import pyspark.sql.functions as f
from pyspark.sql.types import *
from pyspark.sql.functions import isnan, when, count, col

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Pull in cleaned flights data

# COMMAND ----------

airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc/part-00*.parquet")

# COMMAND ----------

#Because between query may have edge case, I'm just being explicit here
air_w_year = airlines.select("ORIGIN", "ORIGIN_UTC", "DEST", "DEST_UTC",  
                              f.year("ORIGIN_UTC").alias('utc_org_year'), 
                              f.year("DEST_UTC").alias('utc_dest_year'),                              
                             )
print(air_w_year.count())
display(air_w_year)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Build this metric only based off training data

# COMMAND ----------

airlines = air_w_year.where(f.col("utc_org_year") < 2019)
airlines.select("utc_org_year").distinct().collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Convert the sample to Pandas
# MAGIC * To use NetworkX
# MAGIC * Ease of visual building

# COMMAND ----------


airlines_pd = airlines.toPandas()
airlines_pd.head()

# COMMAND ----------

airlines_pd.shape

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get all unique airports in out flights data

# COMMAND ----------

total_unique_airports = list(set(airlines_pd["ORIGIN"]).union(set(airlines_pd["DEST"])))
len(total_unique_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Initialize NetworkX Directed Graph, and add all the airports as nodes

# COMMAND ----------

#Init A Directed Graph
G = nx.DiGraph()

#Add all airports as nodes
G.add_nodes_from(total_unique_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Group all `ORIGIN -> DEST` flight paths and get the counts
# MAGIC 
# MAGIC We will use these counts as the weights on this directed graph. Where the weight of an edge from node A to Node B is the number of times a flight has made this trip in the time range 2015-2018.

# COMMAND ----------

grouped_by_trip = airlines_pd.groupby(['ORIGIN','DEST']).size().reset_index()
grouped_by_trip = grouped_by_trip.rename(columns={0: "count"})
grouped_by_trip.head()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Add all the edges of graph with weight as the total number of times a given trip has occurred.

# COMMAND ----------

#For every origin and destination add edge with weight which represents total number of trips across all time 2015-2019
for row in grouped_by_trip.iterrows():
  row_obj = row[1]
  G.add_edge(row_obj["ORIGIN"], row_obj["DEST"], weight = row_obj["count"])

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Compute the Page Rank of the airports

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC airport_pr = nx.pagerank(G, alpha=0.85, personalization=None, max_iter=1000, tol=1e-06, nstart=None, weight='weight', dangling=None)
# MAGIC airport_pr_sorted = {k: v for k, v in sorted(airport_pr.items(), key=lambda item: -item[1])}

# COMMAND ----------

airport_pr_sorted

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Some graph metrics 

# COMMAND ----------

#2015-2018
print("Number of total edges: ", G.number_of_edges())

print("Number of total trips : ", G.size(weight='weight'))

print("Sanity check with grouped trips", sum(grouped_by_trip["count"]))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Aiport Edge Degree
# MAGIC 
# MAGIC We wanted to gain an understanding of the behavior as per the **In-Degree** and **Out-Degree** for all airports we are analyzing

# COMMAND ----------

# MAGIC %md
# MAGIC #### In-Degree Analysis

# COMMAND ----------

in_degree_sequence = sorted([d for n, d in G.in_degree], reverse=True)  # degree sequence
in_degree_count = collections.Counter(in_degree_sequence)
in_deg, in_cnt = zip(*in_degree_count.items())

in_degree_count = pd.DataFrame({"in_degree": in_deg, "count":in_cnt})

in_degree_count.describe()

# COMMAND ----------

fig = px.bar(in_degree_count, x='in_degree', y='count',
             hover_data=['in_degree', 'count'], color='count', height=400,
             title="Airport In-Degree Count")

fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Out-Degree Analysis

# COMMAND ----------

out_degree_sequence = sorted([d for n, d in G.out_degree], reverse=True)  # degree sequence
out_degree_count = collections.Counter(out_degree_sequence)
out_degree, out_cnt = zip(*out_degree_count.items())
out_degree_count = pd.DataFrame({"out_degree": out_degree, "count":out_cnt})

out_degree_count.describe()

# COMMAND ----------

fig = px.bar(out_degree_count, x='out_degree', y='count',
             hover_data=['out_degree', 'count'], color='count', height=400,
             title="Airport Out-Degree Count")

fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### We have computed a Page rank for every airport
# MAGIC 
# MAGIC Pull in `airport_meta` table and add this as a new data point for every airport that we have seen in our training data.

# COMMAND ----------

airport_meta = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta/part-00000*.parquet")
print(airport_meta.count())
display(airport_meta)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Broadcast the PageRank table, and use a UDF to add this feature to all airports.

# COMMAND ----------

iata_to_pr = sc.broadcast(airport_pr)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Note, there can be airports that we have note seen in training that show up in validation or test.
# MAGIC 
# MAGIC For these airports we asign it an even probability, multiplied by a teleportation factor. By doing though the sum of scores will be greater than **1.0** we are still able to represent new airports that must have been built recently or started flying minimally given they did not show up in any of the training data.
# MAGIC 
# MAGIC $$ pageRankNewAirport = \frac{1}{n} * telFactor$$

# COMMAND ----------

def map_iata_to_pr(iata):
  if iata in iata_to_pr.value:
    return iata_to_pr.value[iata]
  #In case the station doesn't exist we use (1/N)
  return (1/365)*.15

#convert to a UDF Function by passing in the function and return type of function
udf_map_to_pr = f.udf(map_iata_to_pr, DoubleType())
airport_meta = airport_meta.withColumn("pagerank", udf_map_to_pr("IATA"))
airport_meta.show()

# COMMAND ----------

airport_meta.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta')

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Pagerank Spread

# COMMAND ----------

airport_meta_pd = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta/part-00*.parquet").toPandas()
airport_meta_pd.head()

# COMMAND ----------

fig = px.bar(airport_meta_pd.sort_values(by=["pagerank"], ascending=False), x='IATA', y='pagerank',
             hover_data=['IATA', 'pagerank', 'state','station_tz'], color='pagerank',
             title="Station Pagerank Scores", height=400)
fig.show()

# COMMAND ----------


