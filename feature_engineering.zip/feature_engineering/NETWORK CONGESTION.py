# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext, Window
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np
import plotly.express as px

sqlContext = SQLContext(sc)

import networkx as nx

# COMMAND ----------

# read airlines data
airlines_final = spark.read.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final")
airlines_final.registerTempTable('airlines')

# COMMAND ----------

# initalize graph object
G = nx.DiGraph()

# COMMAND ----------

# get all origin and destination airports
nodes = airlines_final.select('ORIGIN').distinct().union(airlines_final.select('DEST').distinct())

# COMMAND ----------

# create all airports as nodes
for row in nodes.rdd.collect():
  G.add_node(row.ORIGIN)

# COMMAND ----------

# add all OD pairs as edges
for row in airlines_final.select('ORIGIN','DEST').distinct().rdd.collect():
  G.add_edge(row.ORIGIN, row.DEST)

# COMMAND ----------

# compute centrality
bc = nx.betweenness_centrality(G)

# COMMAND ----------

# get top 10 most central nodes
sorted(bc.items(), key=lambda x: x[1], reverse=True)

# COMMAND ----------

# -----
# Now calculate the count of delayed arrivals as departures for the top 10 airports

# COMMAND ----------

# training data
train = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train")
train.registerTempTable('train')

# COMMAND ----------

# test data
test = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test")
test.registerTempTable('test')

# COMMAND ----------

# validation data
validation = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation")
validation.registerTempTable('validation')

# COMMAND ----------

# get all of the 2-hour prior to departure times in UTC
# for train
possible_utcs_train = spark.sql("""
SELECT DISTINCT ORIGIN_UTC_ADJ_MAX FROM train
""")
possible_utcs_train = possible_utcs_train.withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC_ADJ_MAX"))
possible_utcs_train.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/possible_utcs_train')
# for test
possible_utcs_test = spark.sql("""
SELECT DISTINCT ORIGIN_UTC_ADJ_MAX FROM test
""")
possible_utcs_test = possible_utcs_test.withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC_ADJ_MAX"))
possible_utcs_test.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/possible_utcs_test')
# for validation
possible_utcs_validation = spark.sql("""
SELECT DISTINCT ORIGIN_UTC_ADJ_MAX FROM validation
""")
possible_utcs_validation = possible_utcs_validation.withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC_ADJ_MAX"))
possible_utcs_validation.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/possible_utcs_validation')

# read back parquet files for speed
possible_utcs_train = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/possible_utcs_train')
possible_utcs_train.registerTempTable('utc_train')
possible_utcs_test = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/possible_utcs_test')
possible_utcs_test.registerTempTable('utc_test')
possible_utcs_validation = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/possible_utcs_validation')
possible_utcs_validation.registerTempTable('utc_validation')

# COMMAND ----------

# Get just the necessary columns from the busiest airports to reduce the amount of shuffling, so they are each computed individually
# and added back together
for origin in ['ORD','DFW','ATL','DEN','MSP','ANC','CLT','SLC','DTW','LAX']:
  airport = spark.sql(f"""
    SELECT DEP_DEL15, ARR_DEL15, DEST_UTC, ORIGIN FROM train WHERE ORIGIN = '{origin}' ORDER BY DEST_UTC
  """)
  airport.write.mode('overwrite').parquet(f'dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/{origin}_train')
  
for origin in ['ORD','DFW','ATL','DEN','MSP','ANC','CLT','SLC','DTW','LAX']:
  airport = spark.sql(f"""
    SELECT DEP_DEL15, ARR_DEL15, DEST_UTC, ORIGIN FROM test WHERE ORIGIN = '{origin}' ORDER BY DEST_UTC
  """)
  airport.write.mode('overwrite').parquet(f'dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/{origin}_test')
  
for origin in ['ORD','DFW','ATL','DEN','MSP','ANC','CLT','SLC','DTW','LAX']:
  print(origin)
  airport = spark.sql(f"""
    SELECT DEP_DEL15, ARR_DEL15, DEST_UTC, ORIGIN FROM validation WHERE ORIGIN = '{origin}' ORDER BY DEST_UTC
  """)
  airport.write.mode('overwrite').parquet(f'dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/{origin}_validation')

# COMMAND ----------

# The calculation of the sum of delays by departure time is divided by by airport and by year to keep the shuffle size small
for dataset in ['train', 'test', 'validation']:
  for origin in ['ORD','DFW','ATL','DEN','MSP','ANC','CLT','SLC','DTW','LAX']:
    for year in range(2015,2021):
      origin_airport_data = spark.read.parquet(f'dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/{origin}_{dataset}')
      origin_airport_data.registerTempTable('origin_airport')
      hub_delays = spark.sql(f"""
      SELECT utc.ORIGIN_UTC_ADJ_MAX, COALESCE(sum(ord.ARR_DEL15)+sum(ord.DEP_DEL15),0) as NETWORK_CONGESTION
      FROM utc_{dataset}
      LEFT JOIN origin_airport AS ord ON ord.DEST_UTC BETWEEN utc.DAY_ZERO AND utc.ORIGIN_UTC_ADJ_MAX
      WHERE DAY_ZERO >= '{year}-01-01' AND DAY_ZERO < '{year+1}-01-01'
      GROUP BY utc.ORIGIN_UTC_ADJ_MAX
    """)
      hub_delays.write.mode('overwrite').parquet(f'dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/{origin}_NC_{year}_{dataset}')

# COMMAND ----------

for dataset in ['train', 'test', 'validation']:
  # read back the delays from parqet files
  airport_groups = []
  for origin in ['ORD','DFW','ATL','DEN','MSP','ANC','CLT','SLC','DTW','LAX']:
    year_airports = []
    for year in range(2015, 2021):
      year_airports.append(spark.read.parquet(f'dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/{origin}_NC_{year}_{dataset}'))
    airport_groups.append(year_airports)
  
  # an a year by year basis
  # make columns for each each airport and sum the columns together to add together all airports by year
  year_groups = []
  for i in range(0, len(airport_groups[0])):
    tmp1 = airport_groups[0][i].withColumnRenamed('NETWORK_CONGESTION','NETWORK_CONGESTION_0').join(airport_groups[0][i].withColumnRenamed('NETWORK_CONGESTION','NETWORK_CONGESTION_1'), ['ORIGIN_UTC_ADJ_MAX']).select('ORIGIN_UTC_ADJ_MAX', (col('NETWORK_CONGESTION_0') + col('NETWORK_CONGESTION_1')).alias('NETWORK_CONGESTION'))
    for group_index in range(1, len(airport_groups)):
      tmp1 = tmp1.withColumnRenamed('NETWORK_CONGESTION','NETWORK_CONGESTION_0').join(airport_groups[group_index][i].withColumnRenamed('NETWORK_CONGESTION','NETWORK_CONGESTION_1'), ['ORIGIN_UTC_ADJ_MAX']).select('ORIGIN_UTC_ADJ_MAX', (col('NETWORK_CONGESTION_0') + col('NETWORK_CONGESTION_1')).alias('NETWORK_CONGESTION'))
    year_groups.append(tmp1)
  # write out the computed columns
  final = year_groups[0].union(year_groups[1]).union(year_groups[2]).union(year_groups[3]).union(year_groups[4]).union(year_groups[5])
  final.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/{dataset}')
    

# COMMAND ----------

# at this point NETWORK_CONGESTION has been joined to the train table
# visualize Network Congestion vs Delays
train = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/train")
train.registerTempTable('train')
spark.sql('''SELECT ROUND(NETWORK_CONGESTION / 1000,0) AS NETWORK_CONGESTION_BINNED, SUM(DEP_DEL15) as DELAY_COUNT, COUNT(DEP_DELAY) as TOTAL_COUNT FROM train GROUP BY ROUND(NETWORK_CONGESTION / 1000,0) ORDER BY NETWORK_CONGESTION_BINNED''').display()

# COMMAND ----------

network_histogram = spark.sql('''SELECT ROUND(NETWORK_CONGESTION / 1000,0) AS NETWORK_CONGESTION_BINNED, SUM(DEP_DEL15) as DELAY_COUNT, COUNT(DEP_DELAY) as TOTAL_COUNT FROM train GROUP BY ROUND(NETWORK_CONGESTION / 1000,0) ORDER BY NETWORK_CONGESTION_BINNED''').toPandas()

# COMMAND ----------

fig = px.bar(network_histogram, x='NETWORK_CONGESTION_BINNED', y='DELAY_COUNT',
             hover_data=['NETWORK_CONGESTION_BINNED', 'DELAY_COUNT'], color='DELAY_COUNT',
             labels={'pop':'Number of delays by amount of congestion'}, height=400)
fig.update_layout(barmode='stack')
fig.show()

# COMMAND ----------


