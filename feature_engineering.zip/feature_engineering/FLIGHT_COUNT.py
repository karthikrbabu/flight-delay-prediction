# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import isnan, when, count, col
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

import pandas as pd
sqlContext = SQLContext(sc)


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## FLIGHT_COUNT
# MAGIC 
# MAGIC ##### Goal:
# MAGIC On a per day basis compute the total number of flights departing, and arriving at a given airport.
# MAGIC 
# MAGIC ##### Hypothesis:
# MAGIC The number of flights to/from an airport tells us how busy that airport is on a given day. This feature would be very correlated to the size/popularity of an airport, we hope to see if there is a strong correlation between this and predicting `DEP_DEL15`
# MAGIC 
# MAGIC 
# MAGIC Note: Our data only deals with flights that were neither diverted nor cancelled 

# COMMAND ----------

airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc/part-00*.parquet")

print("Number of flights (2015 - 2019):  ", airlines.count())
print("Number of data columns:  ", len(airlines.columns))

display(airlines)

# COMMAND ----------

airlines.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC Because our feature is a sum built off of scheduled flight data, we are able to build this feature safely on data across all years.

# COMMAND ----------

# MAGIC %md
# MAGIC #### First perform the group on origin and date to get the counts

# COMMAND ----------

orgin_date_agg = airlines.groupBy(f.to_date("ORIGIN_UTC").alias("date"), "ORIGIN") \
                         .agg(count("*").alias("count"))

print(orgin_date_agg.count())
orgin_date_agg.show()

# COMMAND ----------

display(orgin_date_agg.where((col("date").isNull()) | (col("ORIGIN").isNull()) | (col("count").isNull())))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Next perform the group on destination and date to get the counts

# COMMAND ----------

dest_date_agg = airlines.groupBy(f.to_date("DEST_UTC").alias("date"), "DEST") \
                         .agg(count("*").alias("count"))

print(dest_date_agg.count())
dest_date_agg.show()

# COMMAND ----------

#Renaming to union the dataframes
dest_date_agg = dest_date_agg.withColumnRenamed("DEST", "ORIGIN")
display(dest_date_agg)

# COMMAND ----------

display(dest_date_agg.where((col("date").isNull()) | (col("DEST").isNull()) | (col("count").isNull())))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Union the two datasets together so that we can do another aggregation this time to sum the to and from counts by day

# COMMAND ----------

#Not fully done yet...
flights_by_day = orgin_date_agg.union(dest_date_agg).withColumnRenamed("ORIGIN", "IATA")

print(flights_by_day.count())
display(flights_by_day)

# COMMAND ----------

#Sanity check that we've simply stacked the dataframes onto one another
568880 + 568916

# COMMAND ----------

#This should wrap it up
flights_by_day = flights_by_day.groupBy("date", "IATA") \
                      .agg(f.sum("count").alias("flight_count"))

print(flights_by_day.count())
display(flights_by_day)

# COMMAND ----------

#Number of rows makes sense, its slightly larger than both previous tables
569988

# COMMAND ----------

#Verifying that we don't have any issues in our table
missing_ones = flights_by_day.where((col("date").isNull()) | (col("IATA").isNull()) | (col("flight_count").isNull()))
print(missing_ones.count())
display(missing_ones)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Write the `flights_per_day` table to DBFS for use in data joining at a later stage.

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/flights_per_day", True)

#Write cleaned airlines data to our store
flights_by_day.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/flights_per_day")

# COMMAND ----------

flights_by_day.printSchema()

# COMMAND ----------

display(flights_by_day)

# COMMAND ----------


