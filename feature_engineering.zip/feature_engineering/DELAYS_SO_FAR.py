# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## DELAYS_SO_FAR
# MAGIC 
# MAGIC From papers we've read we, as well as general experience, if an airport is experiencing delays on a given morning, this delay will propagate throughout the day to impact later flights. We would like to capture this information explicitly associated by flight **TAIL_NUM**
# MAGIC 
# MAGIC ##### Goal:
# MAGIC For a given flight, represented by TAIL_NUM, figure out the number of times that same TAIL_NUM was delayed previously on that day up to 2 hours before the given flight.
# MAGIC 
# MAGIC ##### Hypothesis:
# MAGIC If I am to fly out of LAX at 7PM to SFO. For my flights given TAIL_NUM, which is a unique identifier for that flight route (origin -> destination) if that TAIL_NUM is experiencing flight delays anytime prior to the time of my flight on that same day, there is a chance that this will cause my flight to be delayed as well.

# COMMAND ----------

#Imports
import numpy as np
import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC Because our feature is built off of data on a day only up until the 2 hours before a "chosen" flight to predict on, we are able to build this feature safely on data across all years.

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final")
print("Number of flights (2015 - 2019):  ", data.count())
print("Number of data columns:  ", len(data.columns))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Running calculations on the whole dataset

# COMMAND ----------

keep_cols = ['TAIL_NUM','ORIGIN_UTC','ARR_DEL15','ORIGIN_UTC_ADJ_MAX']
data_trim = data.select(*keep_cols)
print("Number of flights (2015 - 2019):  ", data_trim.count())
print("Number of data columns:  ", len(data_trim.columns))
display(data_trim)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC Add a column that represents the beginning of a day so that we can use this in our range query, then register this table for use.

# COMMAND ----------

data_trim = data_trim.withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC"))
data_trim.registerTempTable('data_trim')

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC Query to compute row by row feature of the `DELAYS_SO_FAR` for a given `TAIL_NUM` on a given day. 
# MAGIC 
# MAGIC We choose to order by `ORIGIN_UTC` as the very first flight for a given day was initially not being reflected in our query. By sorting we were able to manual sanity checks that all flights for a given airport and day were being reflected in our output.
# MAGIC 
# MAGIC Because we are doing a **LEFT_JOIN** the null rows that we end up getting simply reflect the first flight for a day, for which the delays so far will always be **0**. Therefore once our query is complete we are able to do a **fillNa()** and substitute the empty values with **0** as this aligns with the meaning of our metric.

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC delays_so_far = spark.sql("""
# MAGIC     SELECT d1.TAIL_NUM, d1.ORIGIN_UTC, sum(d2.ARR_DEL15) as delays_so_far
# MAGIC       FROM data_trim as d1
# MAGIC       LEFT JOIN data_trim d2 
# MAGIC         ON d1.TAIL_NUM = d2.TAIL_NUM 
# MAGIC           AND d2.ORIGIN_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
# MAGIC       GROUP BY d1.TAIL_NUM, d1.ORIGIN_UTC
# MAGIC   """).orderBy("ORIGIN_UTC")
# MAGIC 
# MAGIC print(delays_so_far.count())
# MAGIC display(delays_so_far)

# COMMAND ----------

#Represents the first flight of the day, delays so far is 0.
delays_so_far = delays_so_far.fillna(0, 'delays_so_far')
print("Number of rows  ", delays_so_far.count())
print("Number of data columns:  ", len(delays_so_far.columns))
display(delays_so_far)

# COMMAND ----------

delays_so_far.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC We can see that 77.248% of our flights have no delays prior to the flight on the same day, and that it is very rare that we see more than 3-4 delays for a given `TAIL_NUM` prior to that flight on the same day. The output below is a good sanity check, and shows signs of parallel with the imbalance nature of our label class `DEP_DEL15`

# COMMAND ----------

d_group_pd = delays_so_far.groupBy("delays_so_far").count().toPandas().sort_values(by=["delays_so_far"])
d_group_pd.head(20)

# COMMAND ----------

fig = px.bar(d_group_pd, x='delays_so_far', y='count',
             hover_data=['delays_so_far', 'count'], color='delays_so_far',
             labels={'pop':'Number of Flights '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC The reason this final dataset has a lesser number of rows is due to some duplicate `TAIL_NUM`'s in our data. The way our query operates, we end up selecting one of the duplicates that matches the JOIN condition and move forward. This is a mistake in the data as there cannot be identical `TAIL_NUM`'s at the same moment in time. These instances are resolved by the join. 

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Write the feature data, for use in data joining at a later stage.

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/delays_so_far", True)

#Write cleaned airlines data to our store
delays_so_far.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/delays_so_far")
