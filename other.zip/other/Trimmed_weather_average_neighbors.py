# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext, Window
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np

#from haversine import haversine, Unit

sqlContext = SQLContext(sc)

# COMMAND ----------

airlines_final = spark.read.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final")
airlines_final.registerTempTable('airlines')

# COMMAND ----------

# all airline data
all_station_dates = airlines_final.select('YEAR','MONTH','DAY_OF_MONTH','DEP_HOUR','ORIGIN_STATION','ORIGIN_TS') \
                                        .withColumn('W_YEAR', year(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_MONTH', month(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_DAY_OF_MONTH', dayofmonth(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_HOUR', hour(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('ID', concat(col('W_YEAR'), lit('-'), lpad(col('W_MONTH'),2,'0'), lit('-'), lpad(col('W_DAY_OF_MONTH'),2,'0'), lit('-'), lpad(col('W_HOUR'),2,'0'), lit('-'), col('ORIGIN_STATION')  )) \
                                        .select('W_YEAR', 'W_MONTH', 'W_DAY_OF_MONTH', 'W_HOUR', 'ORIGIN_STATION', 'ID').distinct().orderBy('ID') #.orderBy('W_YEAR','W_MONTH','W_DAY_OF_MONTH','W_HOUR','ORIGIN_STATION')
display(all_station_dates)
all_station_dates.registerTempTable('all_station_dates')

# COMMAND ----------

weather = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_trimmed').withColumn('HOUR', hour('DATE'))
weather.registerTempTable('weather')

# COMMAND ----------

station_neighbors = spark.read.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_neighbors")
station_neighbors.registerTempTable('station_neighbors')

# COMMAND ----------

display(weather.limit(100))

# COMMAND ----------

spark.sql("""SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR ORIGIN_STATION as STATION,
                        concat(W_YEAR)
                        FROM all_station_dates as asd

# COMMAND ----------

average_weather_wnd = spark.sql("""SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, 
                        avg(w1.WND_Speed) as AVG_WND_SPEED, variance(w1.WND_Speed) as VAR_WND_SPEED, 
                        count(WND_Speed) as CNT_WND_SPEED, COUNT(neighbor_id) as CNT_WND_SPEED_STN, ORIGIN_STATION as STATION,
                        ID
                        FROM all_station_dates as asd
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        LEFT JOIN (SELECT * FROM weather as w1 WHERE w1.WND_Speed_Qlty == '5') w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR AND w1.STATION == sn.neighbor_id
                        GROUP BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR, ORIGIN_STATION, ID""")
average_weather_wnd.registerTempTable('average_weather_wnd')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_avg_stations_wnd')
display(average_weather_wnd)

# COMMAND ----------

average_weather_wnd_all = spark.sql("""
SELECT  W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN, asd.ORIGIN_STATION as STATION, asd.ID
FROM all_station_dates as asd
LEFT JOIN average_weather_wnd w1 ON asd.ID == w1.ID

""")
average_weather_wnd_all.count()

# COMMAND ----------

average_weather_wnd_all.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_avg_stations_wnd')

# COMMAND ----------

average_weather_wnd_all = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_avg_stations_wnd')

# COMMAND ----------

display(average_weather_wnd_all)

# COMMAND ----------

average_weather_ht = spark.sql("""SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, 
                        min(w1.CIG_Height) as MIN_CIG_HEIGHT, avg(w1.CIG_Height) AS AVG_CIG_HEIGHT,
                        variance(CIG_Height) as VAR_CIG_HEIGHT,
                        count(CIG_Height) as CNT_CIG_HEIGHT, COUNT( DISTINCT neighbor_id) as CNT_CIG_HEIGHT_STN, ORIGIN_STATION as STATION,
                        ID
                        FROM all_station_dates as asd
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        LEFT JOIN (SELECT * FROM weather as w1 WHERE CIG_Qlty NOT IN ('2', '3', '6', '7')) w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR AND w1.STATION == sn.neighbor_id
                        GROUP BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR, ORIGIN_STATION, ID""")
average_weather_ht.registerTempTable('average_weather_ht')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
#average_weather_ht.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_ht')
display(average_weather_ht)

# COMMAND ----------

average_weather_ht_all = spark.sql("""
SELECT  W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, asd.ORIGIN_STATION as STATION, asd.ID
FROM all_station_dates as asd
LEFT JOIN average_weather_ht w1 ON asd.ID == w1.ID
""")
#average_weather_ht_all.count()
average_weather_ht_all.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_ht')

# COMMAND ----------

average_weather_vis = spark.sql("""SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, 
                        min(w1.VIS_Dis) as MIN_VIS_DIS, avg(w1.VIS_Dis) as AVG_VIS_DIS,
                        variance(w1.VIS_Dis) as VAR_VIS_DIS,
                        count(VIS_Dis) as CNT_VIS_DIS, COUNT(DISTINCT neighbor_id) as CNT_VIS_DIS_STN,
                        ORIGIN_STATION as STATION, ID
                        FROM all_station_dates as asd
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        LEFT JOIN (SELECT * FROM weather as w1 WHERE w1.VIS_Qlty NOT IN ('2', '3', '6', '7')) w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR AND w1.STATION == sn.neighbor_id
                        GROUP BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR, ORIGIN_STATION, ID""")
average_weather_vis.registerTempTable('average_weather_vis')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
#average_weather_ht.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_ht')
#display(average_weather_vis)

# COMMAND ----------

average_weather_vis_all = spark.sql("""
SELECT  W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS, CNT_VIS_DIS_STN, asd.ORIGIN_STATION as STATION, asd.ID
FROM all_station_dates as asd
LEFT JOIN average_weather_vis w1 ON asd.ID == w1.ID
""")
#average_weather_vis_all.count()
average_weather_vis_all.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_vis')

# COMMAND ----------

average_weather_tmp = spark.sql("""SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, 
                        avg(w1.TMP_Degree) as AVG_TMP_DEG, variance(TMP_Degree) as VAR_TMP_DEG, 
                        count(TMP_Degree) as CNT_TMP_DEG, COUNT(DISTINCT neighbor_id) as CNT_TMP_DEG_STN,
                        ORIGIN_STATION as STATION, ID
                        FROM all_station_dates as asd
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        LEFT JOIN (SELECT * FROM weather as w1 WHERE TMP_Qlty NOT IN ('2', '3', '6', '7')) w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR AND w1.STATION == sn.neighbor_id
                        GROUP BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR, ORIGIN_STATION, ID""")
average_weather_tmp.registerTempTable('average_weather_tmp')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
#average_weather_ht.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_ht')
#display(average_weather_tmp)

# COMMAND ----------

average_weather_tmp_all = spark.sql("""
SELECT  W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, AVG_TMP_DEG, VAR_TMP_DEG, CNT_TMP_DEG, CNT_TMP_DEG_STN, asd.ORIGIN_STATION as STATION, asd.ID
FROM all_station_dates as asd
LEFT JOIN average_weather_tmp w1 ON asd.ID == w1.ID
""")
#average_weather_tmp_all.count()
average_weather_tmp_all.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_tmp')

# COMMAND ----------

average_weather_dew = spark.sql("""SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, 
                        avg(w1.DEW_Degree) as AVG_DEW_DEG, variance(DEW_Degree) as VAR_DEW_DEG, 
                        count(DEW_Degree) as CNT_DEW_DEG, COUNT(DISTINCT neighbor_id) as CNT_DEW_DEG_STN,
                        ORIGIN_STATION as STATION, ID
                        FROM all_station_dates as asd
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        LEFT JOIN (SELECT * FROM weather as w1 WHERE DEW_Degree NOT IN ('2', '3', '6', '7')) w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR AND w1.STATION == sn.neighbor_id
                        GROUP BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR, ORIGIN_STATION, ID""")
average_weather_dew.registerTempTable('average_weather_dew')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
#average_weather_ht.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_ht')
#display(average_weather_dew)

# COMMAND ----------

average_weather_dew_all = spark.sql("""
SELECT  W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, AVG_DEW_DEG, VAR_DEW_DEG, CNT_DEW_DEG, CNT_DEW_DEG_STN, asd.ORIGIN_STATION as STATION, asd.ID
FROM all_station_dates as asd
LEFT JOIN average_weather_dew w1 ON asd.ID == w1.ID
""")
#average_weather_dew_all.count()
average_weather_dew_all.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_dew')

# COMMAND ----------

average_weather_slp = spark.sql("""SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, 
                        avg(w1.SLP_Pressure) as AVG_SLP, variance(SLP_Pressure) as VAR_SLP, 
                        count(SLP_Pressure) as CNT_SLP, COUNT(neighbor_id) as CNT_SLP_STN,
                        ORIGIN_STATION as STATION, ID
                        FROM all_station_dates as asd
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        LEFT JOIN (SELECT * FROM weather as w1 WHERE SLP_Pressure NOT IN ('2', '3', '6', '7')) w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR AND w1.STATION == sn.neighbor_id
                        GROUP BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR, ORIGIN_STATION, ID""")
average_weather_slp.registerTempTable('average_weather_slp')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
#average_weather_ht.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_ht')
#display(average_weather_slp)

# COMMAND ----------

average_weather_slp.registerTempTable('average_weather_slp')

# COMMAND ----------

average_weather_slp_all = spark.sql("""
SELECT  W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, AVG_SLP, VAR_SLP, CNT_SLP, CNT_SLP_STN, asd.ORIGIN_STATION as STATION, asd.ID
FROM all_station_dates as asd
LEFT JOIN average_weather_slp w1 ON asd.ID == w1.ID
""")
#average_weather_dew_all.count()
average_weather_slp_all.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_slp')

# COMMAND ----------



# COMMAND ----------

display(average_weather_wnd_all.limit(100))

# COMMAND ----------

average_weather_wnd_all.count()

# COMMAND ----------

average_weather_wnd_all.registerTempTable('average_weather_wnd')

# COMMAND ----------

average_weather_ht_all = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_ht')
average_weather_ht_all.registerTempTable('average_weather_ht')

# COMMAND ----------

average_weather_vis_all = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_vis')
average_weather_vis_all.registerTempTable('average_weather_vis')

# COMMAND ----------

average_weather_tmp_all = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_tmp')
average_weather_tmp_all.registerTempTable('average_weather_tmp')

# COMMAND ----------

average_weather_dew_all = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_dew')
average_weather_dew_all.registerTempTable('average_weather_dew')

# COMMAND ----------

average_weather_slp_all = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_average_weather_slp')
average_weather_slp_all.registerTempTable('average_weather_slp')

# COMMAND ----------

stations_neighbors_weather_metrics = spark.sql("""SELECT wnd.YEAR, wnd.MONTH, wnd.DAY_OF_MONTH, wnd.HOUR,
                        AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN,
                        MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN,
                        MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS, CNT_VIS_DIS_STN,
                        AVG_TMP_DEG, VAR_TMP_DEG, CNT_TMP_DEG, CNT_TMP_DEG_STN,
                        AVG_DEW_DEG, VAR_DEW_DEG, CNT_DEW_DEG, CNT_DEW_DEG_STN,
                        AVG_SLP, VAR_SLP, CNT_SLP, CNT_SLP_STN,
                        wnd.STATION, wnd.ID
                        FROM average_weather_wnd as wnd
                        LEFT JOIN average_weather_ht ht ON ht.ID = wnd.ID
                        LEFT JOIN average_weather_vis vis ON vis.ID = wnd.ID
                        LEFT JOIN average_weather_tmp tmp ON tmp.ID = wnd.ID
                        LEFT JOIN average_weather_dew dew ON dew.ID = wnd.ID
                        LEFT JOIN average_weather_slp slp ON slp.ID = wnd.ID   
                        ORDER BY wnd.ID
                        """)
#average_weather_wnd.registerTempTable('average_weather_wnd')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
#average_weather_wnd.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/trimmed_avg_stations_wnd')
display(stations_neighbors_weather_metrics)

# COMMAND ----------

stations_neighbors_weather_metrics.count()

# COMMAND ----------

stations_neighbors_weather_metrics.registerTempTable('neighbor_weather')

# COMMAND ----------

gap_count = stations_neighbors_weather_metrics.withColumn("grp",
              f.row_number().over(Window.orderBy(col("ID")))
              - f.row_number().over(Window.partitionBy("AVG_DEW_DEG").orderBy(col("ID")))
              ) \
    .withColumn("Result", f.row_number().over(Window.partitionBy("grp").orderBy(col("ID")))) \
    .drop("grp")

# COMMAND ----------

gap_count.registerTempTable('gap_count')

# COMMAND ----------

display(gap_count.filter('AVG_DEW_DEG is null').groupby('Result').count())

# COMMAND ----------

null_rows = spark.sql('SELECT * FROM neighbor_weather WHERE AVG_WND_SPEED is null')
display(null_rows)

# COMMAND ----------

null_rows.count()

# COMMAND ----------

stations_neighbors_weather_metrics.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/weather/neighbor_weather_metrics')

# COMMAND ----------

missing_sta = all_station_dates.join(stations_neighbors_all, [all_station_dates.W_YEAR == stations_neighbors_all.YEAR, all_station_dates.W_MONTH == stations_neighbors_all.MONTH, all_station_dates.W_DAY_OF_MONTH == stations_neighbors_all.DAY_OF_MONTH, all_station_dates.W_HOUR == stations_neighbors_all.HOUR, all_station_dates.ORIGIN_STATION == stations_neighbors_all.STATION], 'anti')

# COMMAND ----------

display(missing_sta.select('ORIGIN_STATION').distinct())

# COMMAND ----------

missing = all_station_dates.join(average_weather_wnd, [all_station_dates.W_YEAR == average_weather_wnd.YEAR, all_station_dates.W_MONTH == average_weather_wnd.MONTH, all_station_dates.W_DAY_OF_MONTH == average_weather_wnd.DAY_OF_MONTH, all_station_dates.W_HOUR == average_weather_wnd.HOUR, all_station_dates.ORIGIN_STATION == average_weather_wnd.STATION], 'anti')

# COMMAND ----------

display(missing)

# COMMAND ----------

display(weather.filter('STATION == "78514011603" AND YEAR == "2015" AND MONTH == "1" and DAY_OF_MONTH == "0" and HOUR == "0"'))

# COMMAND ----------

# Weather Table (All columns)
weather_final_all = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_all_columns").withColumn('HOUR', hour('DATE'))
display(weather_final_all)

# COMMAND ----------

display(weather_final_all.filter('STATION == "78514011603" AND YEAR == "2015" AND MONTH == "1" and DAY_OF_MONTH == "0" and HOUR == "0"'))

# COMMAND ----------

weather_raw = spark.read.option("header", "true")\
                    .parquet(f"dbfs:/mnt/mids-w261/datasets_final_project/weather_data/*.parquet").withColumn('HOUR', hour('DATE')).withColumn('YEAR', year('DATE')).withColumn('MONTH', month('DATE')).withColumn('DAY_OF_MONTH', dayofmonth('DATE'))

# COMMAND ----------

display(weather_raw.filter('STATION == "78514011603" AND YEAR == "2015" AND MONTH == "1" and DAY_OF_MONTH == "0" and HOUR == "0"'))

# COMMAND ----------


