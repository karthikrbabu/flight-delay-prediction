# Databricks notebook source
import numpy as np
import pandas as pd
import plotly as px
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from datetime import datetime
import time

import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.ml.feature import StringIndexer, VectorIndexer, VectorAssembler, StandardScaler, OneHotEncoder, SQLTransformer
from pyspark.ml.classification import LogisticRegression 
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml import Pipeline
from pyspark.sql import Window

from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

import mlflow
import mlflow.spark

# COMMAND ----------

# MAGIC %md
# MAGIC Get count of incoming delayed flight so far each day to each airport.  Also average incoming delay so far.

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_final")

print(data.count())
display(data)

# COMMAND ----------

# MAGIC %md try on sample subset

# COMMAND ----------

test_sample = data.orderBy('ORIGIN_UTC').limit(10000).withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC"))

# COMMAND ----------

test_sample.registerTempTable('sample_table')

# COMMAND ----------

count_incoming_delays = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, COALESCE(sum(d2.ARR_DEL15),0) as incoming_delays
      FROM sample_table as d1
      LEFT JOIN sample_table d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC
  """)

display(count_incoming_delays)

# COMMAND ----------

id_group_pd = count_incoming_delays.groupBy("incoming_delays").count().toPandas()
id_group_pd.head(20)

# COMMAND ----------

avg_incoming_delay = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, COALESCE(avg(d2.ARR_DELAY),0) as avg_incoming_delay
      FROM sample_table as d1
      LEFT JOIN sample_table d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC
  """)

display(avg_incoming_delay)

# COMMAND ----------

test_sample_with_count = test_sample.join(count_incoming_delays, ['ORIGIN','ORIGIN_UTC'], 'left')
test_sample_with_count.count()

# COMMAND ----------

display(test_sample_with_count)

# COMMAND ----------

test_sample_with_count_avg = test_sample_with_count.join(avg_incoming_delay, ['ORIGIN','ORIGIN_UTC'], 'left')
test_sample_with_count_avg.count()

# COMMAND ----------

display(test_sample_with_count_avg.drop('DAY_ZERO'))

# COMMAND ----------

# MAGIC %md
# MAGIC That worked. Let's do the whole thing.

# COMMAND ----------

# train

# COMMAND ----------

# verify row count doesn't change
data.count()

# COMMAND ----------

data_with_zero_day = data.orderBy('ORIGIN_UTC').withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC"))
data_with_zero_day.registerTempTable('data')
count_incoming_delays = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, CONCAT(d1.ORIGIN, d1.ORIGIN_UTC, d1.TAIL_NUM, d1.DEST, d1.OP_CARRIER_FL_NUM) AS ID, COALESCE(sum(d2.ARR_DEL15),0) as CNT_INCOMING_DELAYS
      FROM data as d1
      LEFT JOIN data d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC, d1.TAIL_NUM, d1.DEST, d1.OP_CARRIER_FL_NUM
  """)

avg_incoming_delay = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, d1.TAIL_NUM, d1.DEST, d1.OP_CARRIER_FL_NUM, COALESCE(avg(d2.ARR_DELAY),0) as AVG_INCOMING_DELAY
      FROM sample_table as d1
      LEFT JOIN sample_table d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC, d1.TAIL_NUM, d1.DEST, d1.OP_CARRIER_FL_NUM
  """)

data_with_count = data.join(count_incoming_delays, ['ORIGIN', 'TAIL_NUM', 'ORIGIN_UTC', 'DEST', 'OP_CARRIER_FL_NUM'], 'left')
data_with_count_avg = data_with_count.join(avg_incoming_delay, ['ORIGIN', 'TAIL_NUM', 'ORIGIN_UTC', 'DEST', 'OP_CARRIER_FL_NUM'], 'left')

# COMMAND ----------

all_data = data
data = all_data.filter('YEAR == "2015"')

# COMMAND ----------

data_with_zero_day = data.orderBy('ORIGIN_UTC').withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC"))
data_with_zero_day.createOrReplaceTempView('data')
count_incoming_delays = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, CONCAT(d1.ORIGIN, d1.ORIGIN_UTC, d1.TAIL_NUM, d1.DEST, d1.OP_CARRIER_FL_NUM) AS ID, 
    COALESCE(sum(d2.ARR_DEL15),0) as CNT_INCOMING_DELAYS, COALESCE(avg(d2.ARR_DELAY),0) as AVG_INCOMING_DELAY
      FROM data as d1
      LEFT JOIN data d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC, ID
  """)

# COMMAND ----------

count_incoming_delays.count()

# COMMAND ----------

count_incoming_delays.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/airline/incoming_delays_train_2015')

# COMMAND ----------

# verify row count doesn't change
data_with_count_avg.count()

# COMMAND ----------

# one more sanity check before writing
display(data_with_count_avg)

# COMMAND ----------

# overwrite train
data_with_count_avg.write.mode('overwrite').parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_final")

# COMMAND ----------

# test

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test_final")

# COMMAND ----------

# verify row count doesn't change
data.count()

# COMMAND ----------

data_with_zero_day = data.orderBy('ORIGIN_UTC').withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC"))
data_with_zero_day.createOrReplaceTempView('data')
count_incoming_delays = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, COALESCE(sum(d2.ARR_DEL15),0) as CNT_INCOMING_DELAYS
      FROM data as d1
      LEFT JOIN data d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC
  """)

avg_incoming_delay = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, COALESCE(avg(d2.ARR_DELAY),0) as AVG_INCOMING_DELAY
      FROM sample_table as d1
      LEFT JOIN sample_table d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC
  """)

data_with_count = data.join(count_incoming_delays, ['ORIGIN','ORIGIN_UTC'], 'left')
data_with_count_avg = data_with_count.join(avg_incoming_delay, ['ORIGIN','ORIGIN_UTC'], 'left')

# COMMAND ----------

# verify row count doesn't change
data_with_count_avg.count()

# COMMAND ----------

# one more sanity check before writing
display(data_with_count_avg)

# COMMAND ----------

# overwrite test
data_with_count_avg.write.mode('overwrite').parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test_final")

# COMMAND ----------

# val

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation_final")

# COMMAND ----------

# verify row count doesn't change
data.count()

# COMMAND ----------

data_with_zero_day = data.orderBy('ORIGIN_UTC').withColumn("DAY_ZERO", f.date_trunc("day", "ORIGIN_UTC"))
data_with_zero_day.createOrReplaceTempView('data')
count_incoming_delays = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, COALESCE(sum(d2.ARR_DEL15),0) as CNT_INCOMING_DELAYS
      FROM data as d1
      LEFT JOIN data d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC
  """)

avg_incoming_delay = spark.sql("""
    SELECT d1.ORIGIN, d1.ORIGIN_UTC, COALESCE(avg(d2.ARR_DELAY),0) as AVG_INCOMING_DELAY
      FROM sample_table as d1
      LEFT JOIN sample_table d2 
        ON d1.ORIGIN = d2.DEST 
          AND d2.DEST_UTC BETWEEN d1.DAY_ZERO AND d1.ORIGIN_UTC_ADJ_MAX
      GROUP BY d1.ORIGIN, d1.ORIGIN_UTC
  """)

data_with_count = data.join(count_incoming_delays, ['ORIGIN','ORIGIN_UTC'], 'left')
data_with_count_avg = data_with_count.join(avg_incoming_delay, ['ORIGIN','ORIGIN_UTC'], 'left')

# COMMAND ----------

# verify row count doesn't change
data_with_count_avg.count()

# COMMAND ----------

# one more sanity check before writing
display(data_with_count_avg)

# COMMAND ----------

# overwrite val
data_with_count_avg.write.mode('overwrite').parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation_final")
