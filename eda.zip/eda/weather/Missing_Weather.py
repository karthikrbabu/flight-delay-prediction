# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext, Window
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np

#from haversine import haversine, Unit

sqlContext = SQLContext(sc)

# COMMAND ----------

final_data = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/data')

# COMMAND ----------

display(final_data.limit(100))

# COMMAND ----------

final_data.registerTempTable('final_data')

# COMMAND ----------

display(spark.sql('SELECT * FROM final_data WHERE AVG_WND_SPEED_ORIGIN is null'))

# COMMAND ----------

final_data.printSchema()

# COMMAND ----------

display(spark.sql('''SELECT * FROM final_data 
WHERE AVG_WND_SPEED_ORIGIN is null OR 
MIN_CIG_HEIGHT_ORIGIN is null OR 
MIN_VIS_DIS_ORIGIN is null OR 
AVG_TMP_DEG_ORIGIN is null OR 
AVG_DEW_DEG_ORIGIN is null OR
AVG_SLP_ORIGIN is null OR
AVG_WND_SPEED_DEST is null OR
MIN_CIG_HEIGHT_DEST is null OR
MIN_VIS_DIS_DEST is null OR
AVG_TMP_DEG_DEST is null OR
AVG_DEW_DEG_DEST is null OR
AVG_SLP_DEST is null
'''))

# COMMAND ----------



# COMMAND ----------

airlines_final = spark.read.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final")
weather_origin_helper = spark.read.option("header", "true").parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/woh")
weather_dest_helper = spark.read.option("header", "true").parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_dest_helper")
station_neighbors = spark.read.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_neighbors")
weather = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/weather/weather_final_13_Nov').withColumn('HOUR', hour('DATE'))#.distinct()

# COMMAND ----------

airlines_final.registerTempTable('airlines_final')
weather_origin_helper.registerTempTable('weather_origin_helper')
weather_dest_helper.registerTempTable('weather_dest_helper')
weather.registerTempTable('weather_final')
station_neighbors.registerTempTable('station_neighbors')

# COMMAND ----------

airlines_woh = airlines_final.join(weather_origin_helper, [airlines_final.ORIGIN_STATION == weather_origin_helper.ORIGIN_STATION, airlines_final.ORIGIN_UTC == weather_origin_helper.ORIGIN_UTC], 'left').select(*airlines_final, weather_origin_helper.origin_max_date)

display(airlines_woh)

# COMMAND ----------

# anti
airlines_origin_missing = airlines_final.join(weather_origin_helper, [airlines_final.ORIGIN_STATION == weather_origin_helper.ORIGIN_STATION, airlines_final.ORIGIN_UTC == weather_origin_helper.ORIGIN_UTC], 'left_anti')#.select(*airlines_final, weather_origin_helper.origin_max_date)

display(airlines_origin_missing)

# COMMAND ----------

airlines_origin_missing.count()

# COMMAND ----------

airlines_origin_missing.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airlines/airlines_origin_missing')

# COMMAND ----------

airlines_origin_missing = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airlines/airlines_origin_missing')

# COMMAND ----------

airlines_woh.registerTempTable('airlines_woh')

# COMMAND ----------

display(spark.sql('''SELECT * FROM airlines_woh 
WHERE origin_max_date is null
'''))

# COMMAND ----------

spark.sql('''SELECT * FROM airlines_woh 
WHERE origin_max_date is null
''').count()

# COMMAND ----------

airlines_dest_missing = airlines_final.join(weather_dest_helper, [airlines_final.DEST_STATION == weather_dest_helper.DEST_STATION, airlines_final.ORIGIN_UTC == weather_dest_helper.ORIGIN_UTC],'anti')#.select(*airlines_woh, weather_dest_helper.dest_max_date)

display(airlines_dest_missing)

# COMMAND ----------

airlines_dest_missing.count()

# COMMAND ----------

airlines_dest_missing.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/airlines/airlines_dest_missing')

# COMMAND ----------

airlines_all_missing = airlines_origin_missing.union(airlines_dest_missing).distinct()

# COMMAND ----------

airlines_all_missing.count()

# COMMAND ----------

280140 + 279874

# COMMAND ----------

airports = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta')

# COMMAND ----------

phoenix = airports.filter('IATA == "AZA"')

# COMMAND ----------



# COMMAND ----------

phoenix_weather = phoenix.join(weather, ['STATION'])
display(phoenix_weather)

# COMMAND ----------

display(phoenix)

# COMMAND ----------

display(weather.filter('NAME like "%PHOENIX%"'))

# COMMAND ----------

display(weather.limit(100))

# COMMAND ----------

weather_stations = weather.select('STATION', 'LATITUDE', 'LONGITUDE').distinct()

# COMMAND ----------

stations = spark.read.option("header", "true").csv("dbfs:/mnt/mids-w261/DEMO8/gsod/stations.csv.gz")

# COMMAND ----------

display(stations.filter('usaf == "722780"'))

# COMMAND ----------

udf_phoenix_near = udf(lambda lat,lng: haversine((33.307778, -111.655556), (float(lat),float(lng))) < 50, BooleanType())

near_phoenix = stations.filter('lat is not null AND lon is not null').withColumn('phoenix_near', udf_phoenix_near(col('lat'),col('lon')))

# COMMAND ----------

display(near_phoenix.filter('phoenix_near == TRUE'))

# COMMAND ----------

near_phoenix_weather = weather_stations.withColumn('phoenix_near', udf_phoenix_near(col('LATITUDE'),col('LONGITUDE'))).filter('phoenix_near == TRUE')
display(near_phoenix_weather)

# COMMAND ----------

stations_station_id = stations.withColumn('STATION', concat(col('usaf'),col('wban')))

# COMMAND ----------

display(stations_station_id.join(near_phoenix_weather, ['STATION']))

# COMMAND ----------

33.307778, -111.655556

# COMMAND ----------

display(airlines_origin_missing.filter('ORIGIN == "DLG"'))

# COMMAND ----------

display(airlines_final.select('ORIGIN').distinct())

# COMMAND ----------

from haversine import haversine, Unit

# COMMAND ----------

pip install haversine

# COMMAND ----------

weather_origin_helper.select('ORIGIN_STATION').distinct().count()

# COMMAND ----------

aza_neighbors = airports.filter('IATA == "AZA"').select(col('STATION').alias('station_id')).join(station_neighbors, ['station_id'])
#aza_neighbors_full = aza_neighbors.join(stations_station_id, [aza_neighbors.neighbor_id == stations_station_id.STATION])
display(aza_neighbors)

# COMMAND ----------

aza_neighbors.registerTempTable('aza_neighbors')

# COMMAND ----------

display(spark.sql('SELECT count(distinct station_id) FROM station_neighbors'))

# COMMAND ----------

display(airlines_final.limit(100))

# COMMAND ----------

airlines_small = airlines_final.filter('YEAR == "2017" AND MONTH < 4')
all_station_dates = airlines_small.select('YEAR','MONTH','DAY_OF_MONTH','DEP_HOUR','ORIGIN_STATION','ORIGIN_TS') \
                                        .withColumn('W_YEAR', year(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_MONTH', month(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_DAY_OF_MONTH', dayofmonth(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_HOUR', hour(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .select('W_YEAR', 'W_MONTH', 'W_DAY_OF_MONTH', 'W_HOUR', 'ORIGIN_STATION').distinct().orderBy('W_YEAR','W_MONTH','W_DAY_OF_MONTH','W_HOUR','ORIGIN_STATION')
display(all_station_dates)
all_station_dates.registerTempTable('all_station_dates')

# COMMAND ----------

all_station_dates.count()

# COMMAND ----------

# all airline data
all_station_dates = airlines_final.select('YEAR','MONTH','DAY_OF_MONTH','DEP_HOUR','ORIGIN_STATION','ORIGIN_TS') \
                                        .withColumn('W_YEAR', year(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_MONTH', month(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_DAY_OF_MONTH', dayofmonth(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_HOUR', hour(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .select('W_YEAR', 'W_MONTH', 'W_DAY_OF_MONTH', 'W_HOUR', 'ORIGIN_STATION').distinct().orderBy('W_YEAR','W_MONTH','W_DAY_OF_MONTH','W_HOUR','ORIGIN_STATION')
display(all_station_dates)
all_station_dates.registerTempTable('all_station_dates')

# COMMAND ----------

all_station_dates.count()

# COMMAND ----------

average_weather_plus = spark.sql("""SELECT asd.W_YEAR as YEAR, asd.W_MONTH as MONTH, asd.W_DAY_OF_MONTH as DAY_OF_MONTH, asd.W_HOUR as HOUR, 
                        asd.ORIGIN_STATION as STATION,
                        avg(wnd.WND_Speed) as AVG_WND_SPEED, variance(wnd.WND_Speed) as VAR_WND_SPEED, 
                        count(wnd.WND_Speed) as CNT_WND_SPEED, COUNT(DISTINCT wnd.STATION) as CNT_WND_SPEED_STN, 
                        
                        min(ht.CIG_Height) as MIN_CIG_HEIGHT, avg(ht.CIG_Height) AS AVG_CIG_HEIGHT,
                        variance(ht.CIG_Height) as VAR_CIG_HEIGHT,
                        count(ht.CIG_Height) as CNT_CIG_HEIGHT, COUNT(DISTINCT ht.STATION) as CNT_CIG_HEIGHT_STN, 
                        
                        min(vis.VIS_Dis) as MIN_VIS_DIS, avg(vis.VIS_Dis) as AVG_VIS_DIS,
                        variance(vis.VIS_Dis) as VAR_VIS_DIS,
                        count(vis.VIS_Dis) as CNT_VIS_DIS, COUNT(distinct vis.STATION) as CNT_VIS_STN, 
                        
                        avg(tmp.TMP_Degree) as AVG_TMP_DEG, variance(tmp.TMP_Degree) as VAR_TMP_DEG,
                        count(tmp.TMP_Degree) as CNT_TMP_DEG, COUNT(DISTINCT tmp.STATION) as CNT_TMP_DEG_STN,
                        
                        avg(dew.DEW_Degree) as AVG_DEW_DEG, variance(dew.DEW_Degree) as VAR_DEW_DEG, 
                        count(dew.DEW_Degree) as CNT_DEW_DEG, COUNT(DISTINCT dew.STATION) as CNT_DEW_DEG_STN,
                        
                        avg(slp.SLP_Pressure) as AVG_SLP, variance(slp.SLP_Pressure) as VAR_SLP, 
                        count(slp.SLP_Pressure) as CNT_SLP, COUNT(DISTINCT slp.STATION) as CNT_SLP_STN
                        
                        FROM all_station_dates as asd
                      
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        
                        LEFT JOIN weather_final as wnd ON W_YEAR == wnd.YEAR AND W_MONTH == wnd.MONTH 
                          AND W_DAY_OF_MONTH == wnd.DAY_OF_MONTH AND W_HOUR == wnd.HOUR AND sn.neighbor_id = wnd.STATION
                          
                        LEFT JOIN weather_final as ht ON W_YEAR == ht.YEAR AND W_MONTH == ht.MONTH 
                          AND W_DAY_OF_MONTH == ht.DAY_OF_MONTH AND W_HOUR == ht.HOUR AND sn.neighbor_id = ht.STATION
                          
                        LEFT JOIN weather_final as vis ON W_YEAR == vis.YEAR AND W_MONTH == vis.MONTH 
                          AND W_DAY_OF_MONTH == vis.DAY_OF_MONTH AND W_HOUR == vis.HOUR AND sn.neighbor_id = vis.STATION
                          
                        LEFT JOIN weather_final as tmp ON W_YEAR == tmp.YEAR AND W_MONTH == tmp.MONTH 
                          AND W_DAY_OF_MONTH == tmp.DAY_OF_MONTH AND W_HOUR == tmp.HOUR AND sn.neighbor_id = tmp.STATION
                          
                        LEFT JOIN weather_final as dew ON W_YEAR == dew.YEAR AND W_MONTH == dew.MONTH 
                          AND W_DAY_OF_MONTH == dew.DAY_OF_MONTH AND W_HOUR == dew.HOUR AND sn.neighbor_id = dew.STATION
                          
                        JOIN weather_final as slp ON W_YEAR == slp.YEAR AND W_MONTH == slp.MONTH 
                          AND W_DAY_OF_MONTH == slp.DAY_OF_MONTH AND W_HOUR == slp.HOUR AND sn.neighbor_id = slp.STATION
                        
                        WHERE wnd.WND_Speed_Qlty == '5'
                        AND ht.CIG_Qlty NOT IN ('2', '3', '6', '7')
                        AND vis.VIS_Qlty NOT IN ('2', '3', '6', '7')
                        AND tmp.TMP_Qlty NOT IN ('2', '3', '6', '7')
                        AND dew.DEW_Degree NOT IN ('2', '3', '6', '7')
                        AND slp.SLP_Pressure NOT IN ('2', '3', '6', '7')
                        GROUP BY asd.W_YEAR, asd.W_MONTH, asd.W_DAY_OF_MONTH, asd.W_HOUR, asd.ORIGIN_STATION
                        ORDER BY asd.ORIGIN_STATION, asd.W_YEAR, asd.W_MONTH, asd.W_DAY_OF_MONTH, asd.W_HOUR""")
average_weather_plus.registerTempTable('average_weather_plus')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
average_weather_plus.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_plus_2017_1')
display(average_weather_plus)

# COMMAND ----------

airlines_small = airlines_final.filter('YEAR == "2017" AND MONTH > 6')
all_station_dates = airlines_small.select('YEAR','MONTH','DAY_OF_MONTH','DEP_HOUR','ORIGIN_STATION','ORIGIN_TS') \
                                        .withColumn('W_YEAR', year(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_MONTH', month(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_DAY_OF_MONTH', dayofmonth(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_HOUR', hour(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .select('W_YEAR', 'W_MONTH', 'W_DAY_OF_MONTH', 'W_HOUR', 'ORIGIN_STATION').distinct().orderBy('W_YEAR','W_MONTH','W_DAY_OF_MONTH','W_HOUR','ORIGIN_STATION')
display(all_station_dates)
all_station_dates.registerTempTable('all_station_dates')

# COMMAND ----------

airlines_small = airlines_final.filter('YEAR == "2019"')
all_station_dates = airlines_small.select('YEAR','MONTH','DAY_OF_MONTH','DEP_HOUR','ORIGIN_STATION','ORIGIN_TS') \
                                        .withColumn('W_YEAR', year(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_MONTH', month(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_DAY_OF_MONTH', dayofmonth(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_HOUR', hour(airlines_small.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .select('W_YEAR', 'W_MONTH', 'W_DAY_OF_MONTH', 'W_HOUR', 'ORIGIN_STATION').distinct().orderBy('W_YEAR','W_MONTH','W_DAY_OF_MONTH','W_HOUR','ORIGIN_STATION')
display(all_station_dates)
all_station_dates.registerTempTable('all_station_dates')

# COMMAND ----------

average_weather_plus = spark.sql("""SELECT asd.W_YEAR as YEAR, asd.W_MONTH as MONTH, asd.W_DAY_OF_MONTH as DAY_OF_MONTH, asd.W_HOUR as HOUR, 
                        asd.ORIGIN_STATION as STATION,
                        avg(wnd.WND_Speed) as AVG_WND_SPEED, variance(wnd.WND_Speed) as VAR_WND_SPEED, 
                        count(wnd.WND_Speed) as CNT_WND_SPEED, COUNT(DISTINCT wnd.STATION) as CNT_WND_SPEED_STN, 
                        
                        min(ht.CIG_Height) as MIN_CIG_HEIGHT, avg(ht.CIG_Height) AS AVG_CIG_HEIGHT,
                        variance(ht.CIG_Height) as VAR_CIG_HEIGHT,
                        count(ht.CIG_Height) as CNT_CIG_HEIGHT, COUNT(DISTINCT ht.STATION) as CNT_CIG_HEIGHT_STN, 
                        
                        min(vis.VIS_Dis) as MIN_VIS_DIS, avg(vis.VIS_Dis) as AVG_VIS_DIS,
                        variance(vis.VIS_Dis) as VAR_VIS_DIS,
                        count(vis.VIS_Dis) as CNT_VIS_DIS, COUNT(distinct vis.STATION) as CNT_VIS_STN, 
                        
                        avg(tmp.TMP_Degree) as AVG_TMP_DEG, variance(tmp.TMP_Degree) as VAR_TMP_DEG,
                        count(tmp.TMP_Degree) as CNT_TMP_DEG, COUNT(DISTINCT tmp.STATION) as CNT_TMP_DEG_STN,
                        
                        avg(dew.DEW_Degree) as AVG_DEW_DEG, variance(dew.DEW_Degree) as VAR_DEW_DEG, 
                        count(dew.DEW_Degree) as CNT_DEW_DEG, COUNT(DISTINCT dew.STATION) as CNT_DEW_DEG_STN,
                        
                        avg(slp.SLP_Pressure) as AVG_SLP, variance(slp.SLP_Pressure) as VAR_SLP, 
                        count(slp.SLP_Pressure) as CNT_SLP, COUNT(DISTINCT slp.STATION) as CNT_SLP_STN
                        
                        FROM all_station_dates as asd
                      
                        LEFT JOIN station_neighbors sn ON sn.station_id == asd.ORIGIN_STATION 
                        
                        LEFT JOIN weather_final as wnd ON W_YEAR == wnd.YEAR AND W_MONTH == wnd.MONTH 
                          AND W_DAY_OF_MONTH == wnd.DAY_OF_MONTH AND W_HOUR == wnd.HOUR AND sn.neighbor_id = wnd.STATION
                          
                        LEFT JOIN weather_final as ht ON W_YEAR == ht.YEAR AND W_MONTH == ht.MONTH 
                          AND W_DAY_OF_MONTH == ht.DAY_OF_MONTH AND W_HOUR == ht.HOUR AND sn.neighbor_id = ht.STATION
                          
                        LEFT JOIN weather_final as vis ON W_YEAR == vis.YEAR AND W_MONTH == vis.MONTH 
                          AND W_DAY_OF_MONTH == vis.DAY_OF_MONTH AND W_HOUR == vis.HOUR AND sn.neighbor_id = vis.STATION
                          
                        LEFT JOIN weather_final as tmp ON W_YEAR == tmp.YEAR AND W_MONTH == tmp.MONTH 
                          AND W_DAY_OF_MONTH == tmp.DAY_OF_MONTH AND W_HOUR == tmp.HOUR AND sn.neighbor_id = tmp.STATION
                          
                        LEFT JOIN weather_final as dew ON W_YEAR == dew.YEAR AND W_MONTH == dew.MONTH 
                          AND W_DAY_OF_MONTH == dew.DAY_OF_MONTH AND W_HOUR == dew.HOUR AND sn.neighbor_id = dew.STATION
                          
                        JOIN weather_final as slp ON W_YEAR == slp.YEAR AND W_MONTH == slp.MONTH 
                          AND W_DAY_OF_MONTH == slp.DAY_OF_MONTH AND W_HOUR == slp.HOUR AND sn.neighbor_id = slp.STATION
                        
                        WHERE wnd.WND_Speed_Qlty == '5'
                        AND ht.CIG_Qlty NOT IN ('2', '3', '6', '7')
                        AND vis.VIS_Qlty NOT IN ('2', '3', '6', '7')
                        AND tmp.TMP_Qlty NOT IN ('2', '3', '6', '7')
                        AND dew.DEW_Degree NOT IN ('2', '3', '6', '7')
                        AND slp.SLP_Pressure NOT IN ('2', '3', '6', '7')
                        GROUP BY asd.W_YEAR, asd.W_MONTH, asd.W_DAY_OF_MONTH, asd.W_HOUR, asd.ORIGIN_STATION
                        ORDER BY asd.ORIGIN_STATION, asd.W_YEAR, asd.W_MONTH, asd.W_DAY_OF_MONTH, asd.W_HOUR""")
average_weather_plus.registerTempTable('average_weather_plus')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
average_weather_plus.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_plus_2019')
display(average_weather_plus)

# COMMAND ----------



# COMMAND ----------

average_weather_wnd = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, 
                        avg(w1.WND_Speed) as AVG_WND_SPEED, variance(w1.WND_Speed) as VAR_WND_SPEED, 
                        count(WND_Speed) as CNT_WND_SPEED, COUNT(neighbor_id) as CNT_WND_SPEED_STN, first(station_id) as STATION
                        FROM all_station_dates as asd
                        LEFT JOIN weather_final as w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR
                        LEFT JOIN station_neighbors sn ON w1.STATION == sn.neighbor_id AND sn.station_id == asd.ORIGIN_STATION 
                        WHERE w1.WND_Speed_Qlty == '5'
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, station_id""")
average_weather_wnd.registerTempTable('average_weather_wnd')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd')
display(average_weather_wnd)

# COMMAND ----------

average_weather_wnd.count()

# COMMAND ----------

average_weather_height = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, 
                        min(w1.CIG_Height) as MIN_CIG_HEIGHT, avg(w1.CIG_Height) AS AVG_CIG_HEIGHT,
                        variance(CIG_Height) as VAR_CIG_HEIGHT,
                        count(CIG_Height) as CNT_CIG_HEIGHT, COUNT( DISTINCT neighbor_id) as CNT_CIG_HEIGHT_STN,
                        first(station_id) as STATION
                        FROM all_station_dates as asd
                        JOIN weather_final as w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR
                        JOIN station_neighbors sn on w1.STATION == sn.neighbor_id AND sn.station_id == asd.ORIGIN_STATION
                        WHERE CIG_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, station_id""")
average_weather_height.registerTempTable('average_weather_height')
#average_weather_height.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_height_6m')
average_weather_height.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_height')
display(average_weather_height)

# COMMAND ----------

average_weather_vis = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, 
                        min(w1.VIS_Dis) as MIN_VIS_DIS, avg(w1.VIS_Dis) as AVG_VIS_DIS,
                        variance(w1.VIS_Dis) as VAR_VIS_DIS,
                        count(VIS_Dis) as CNT_VIS_DIS, COUNT(DISTINCT neighbor_id) as CNT_VIS_DIS_STN,
                        first(station_id) as STATION
                        FROM all_station_dates as asd
                        JOIN weather_final as w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR
                        JOIN station_neighbors sn on w1.STATION == sn.neighbor_id 
                        WHERE w1.VIS_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, station_id""")
average_weather_vis.registerTempTable('average_weather_vis')
#average_weather_vis.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_vis_6m')
average_weather_vis.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_vis')
display(average_weather_vis)

# COMMAND ----------

average_weather_tmp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, 
                        avg(w1.TMP_Degree) as AVG_TMP_DEG, variance(TMP_Degree) as VAR_TMP_DEG, 
                        count(TMP_Degree) as CNT_TMP_DEG, COUNT(DISTINCT neighbor_id) as CNT_TMP_DEG_STN,
                        first(station_id) as STATION
                        FROM all_station_dates as asd
                        JOIN weather_final as w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR
                        JOIN station_neighbors sn on w1.STATION == sn.neighbor_id 
                        WHERE TMP_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, station_id""")
average_weather_tmp.registerTempTable('average_weather_tmp')
#average_weather_tmp.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_tmp_6m')
average_weather_tmp.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_tmp')
display(average_weather_tmp)

# COMMAND ----------

average_weather_dew = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, 
                        avg(w1.DEW_Degree) as AVG_DEW_DEG, variance(DEW_Degree) as VAR_DEW_DEG, 
                        count(DEW_Degree) as CNT_DEW_DEG, COUNT(DISTINCT neighbor_id) as CNT_DEW_DEG_STN,
                        first(station_id) as STATION
                        FROM all_station_dates as asd
                        JOIN weather_final as w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR
                        JOIN station_neighbors sn on w1.STATION == sn.neighbor_id 
                        WHERE DEW_Degree NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, station_id""")
average_weather_dew.registerTempTable('average_weather_dew')
#average_weather_dew.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_dew_6m')
average_weather_dew.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_dew')
display(average_weather_dew)

# COMMAND ----------



# COMMAND ----------

average_weather_slp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, 
                        avg(w1.SLP_Pressure) as AVG_SLP, variance(SLP_Pressure) as VAR_SLP, 
                        count(SLP_Pressure) as CNT_SLP, COUNT(neighbor_id) as CNT_SLP_STN,
                        first(station_id) as STATION
                        FROM all_station_dates as asd
                        JOIN weather_final as w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR
                        JOIN station_neighbors sn on w1.STATION == sn.neighbor_id 
                        WHERE SLP_Pressure NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, station_id""")
average_weather_slp.registerTempTable('average_weather_slp')
#average_weather_slp.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_slp_6m')
average_weather_slp.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_slp')
display(average_weather_slp)

# COMMAND ----------

average_weather_wnd = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
average_weather_height = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_height_6m')

# COMMAND ----------

average_weather_wnd.registerTempTable('average_weather_wnd')
average_weather_height.registerTempTable('average_weather_height')

# COMMAND ----------

all_average_weather = spark.sql("""
  SELECT asd.W_YEAR as YEAR, asd.W_MONTH as MONTH, asd.W_DAY_OF_MONTH as DAY_OF_MONTH, asd.W_HOUR as HOUR, wnd.REPORT_TYPE, asd.ORIGIN_STATION as STATION, AVG_WND_SPEED, VAR_WND_SPEED, 
       CNT_WND_SPEED, CNT_WND_SPEED_STN, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT,
       VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN,
       MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS, CNT_VIS_DIS_STN,
       AVG_TMP_DEG, VAR_TMP_DEG, CNT_TMP_DEG, CNT_TMP_DEG_STN,
       AVG_DEW_DEG, VAR_DEW_DEG, CNT_DEW_DEG, CNT_DEW_DEG_STN,
       AVG_SLP, VAR_SLP, CNT_SLP, CNT_SLP_STN
       
       
    FROM all_station_dates as asd
    LEFT JOIN average_weather_wnd wnd ON asd.W_YEAR == wnd.YEAR AND asd.W_MONTH == wnd.MONTH 
      AND asd.W_DAY_OF_MONTH == wnd.DAY_OF_MONTH AND asd.W_HOUR == wnd.HOUR AND wnd.STATION = asd.ORIGIN_STATION
    LEFT JOIN average_weather_height ht ON asd.W_YEAR == ht.YEAR AND asd.W_MONTH == ht.MONTH 
      AND asd.W_DAY_OF_MONTH == ht.DAY_OF_MONTH AND asd.W_HOUR == ht.HOUR AND ht.STATION = asd.ORIGIN_STATION
    LEFT JOIN average_weather_vis vis ON asd.W_YEAR == vis.YEAR AND asd.W_MONTH == vis.MONTH 
      AND asd.W_DAY_OF_MONTH == vis.DAY_OF_MONTH AND asd.W_HOUR == vis.HOUR AND vis.STATION = asd.ORIGIN_STATION
    LEFT JOIN average_weather_tmp tmp ON asd.W_YEAR == tmp.YEAR AND asd.W_MONTH == tmp.MONTH 
      AND asd.W_DAY_OF_MONTH == tmp.DAY_OF_MONTH AND asd.W_HOUR == tmp.HOUR AND tmp.STATION = asd.ORIGIN_STATION
    LEFT JOIN average_weather_dew dew ON asd.W_YEAR == dew.YEAR AND asd.W_MONTH == dew.MONTH 
      AND asd.W_DAY_OF_MONTH == dew.DAY_OF_MONTH AND asd.W_HOUR == dew.HOUR AND dew.STATION = asd.ORIGIN_STATION
    LEFT JOIN average_weather_slp slp ON asd.W_YEAR == slp.YEAR AND asd.W_MONTH == slp.MONTH 
      AND asd.W_DAY_OF_MONTH == slp.DAY_OF_MONTH AND asd.W_HOUR == slp.HOUR AND slp.STATION = asd.ORIGIN_STATION
""")

# COMMAND ----------

all_average_weather.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/all_average_weather_neighbors')

# COMMAND ----------

all_average_weather = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/all_average_weather_neighbors')

# COMMAND ----------

display(all_average_weather.limit(10))

# COMMAND ----------

all_average_weather = spark.sql("""
  SELECT asd.W_YEAR as YEAR, asd.W_MONTH as MONTH, asd.W_DAY_OF_MONTH as DAY_OF_MONTH, asd.W_HOUR as HOUR, wnd.REPORT_TYPE, asd.ORIGIN_STATION as STATION, AVG_WND_SPEED, VAR_WND_SPEED, 
       CNT_WND_SPEED, CNT_WND_SPEED_STN, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT,
       VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN,
       
    FROM all_station_dates as asd
    LEFT JOIN average_weather_wnd wnd ON asd.W_YEAR == wnd.YEAR AND asd.W_MONTH == wnd.MONTH 
      AND asd.W_DAY_OF_MONTH == wnd.DAY_OF_MONTH AND asd.W_HOUR == wnd.HOUR AND wnd.STATION = asd.ORIGIN_STATION
    LEFT JOIN average_weather_height ht ON asd.W_YEAR == ht.YEAR AND asd.W_MONTH == ht.MONTH 
      AND asd.W_DAY_OF_MONTH == ht.DAY_OF_MONTH AND asd.W_HOUR == ht.HOUR AND ht.STATION = asd.ORIGIN_STATION
""")

# COMMAND ----------

all_station_dates.count()

# COMMAND ----------

display(all_average_weather.limit(10))

# COMMAND ----------

display(all_average_weather)

# COMMAND ----------

display(airports.filter('STATION == "72392523190"'))

# COMMAND ----------

display(all_average_weather.filter('STATION == "72392523190" AND AVG_WND_SPEED is null').orderBy('YEAR','MONTH','DAY_OF_MONTH','HOUR'))

# COMMAND ----------

display(station_neighbors.filter('station_id == "72392523190"'))

# COMMAND ----------

display(weather.limit(10))

# COMMAND ----------

sba_weather = spark.sql("""SELECT weather_final.*, station_neighbors.neighbor_id
FROM weather_final
JOIN station_neighbors ON station_neighbors.neighbor_id = weather_final.STATION
WHERE station_neighbors.station_id == '72392523190'
AND YEAR == '2015' and MONTH == '1' and DAY_OF_MONTH == '7' 
ORDER BY DATE""")
display(sba_weather)

# COMMAND ----------

ASD = spark.sql("SELECT * FROM all_station_dates as asd WHERE ORIGIN_STATION == '72392523190' ORDER BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR")
display(ASD)

# COMMAND ----------



# COMMAND ----------

average_weather_wnd_sba = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, 
                        avg(w1.WND_Speed) as AVG_WND_SPEED, variance(w1.WND_Speed) as VAR_WND_SPEED, 
                        count(WND_Speed) as CNT_WND_SPEED, COUNT(neighbor_id) as CNT_WND_SPEED_STN, first(station_id) as STATION
                        FROM all_station_dates as asd
                        LEFT JOIN weather_final as w1 ON W_YEAR == w1.YEAR AND W_MONTH == w1.MONTH 
                          AND W_DAY_OF_MONTH == w1.DAY_OF_MONTH AND W_HOUR == w1.HOUR
                        LEFT JOIN station_neighbors sn ON w1.STATION == sn.neighbor_id AND sn.station_id == asd.ORIGIN_STATION
                        WHERE w1.WND_Speed_Qlty == '5'
                        AND sn.station_id == '72392523190'
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.HOUR, w1.REPORT_TYPE, station_id
                        ORDER BY YEAR, MONTH, DAY_OF_MONTH, HOUR, STATION
                        """)
#average_weather_wnd.registerTempTable('average_weather_wnd')
#average_weather_wnd.write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd_6m')
display(average_weather_wnd_sba)

# COMMAND ----------

display(all_average_weather.filter('STATION == "72392523190" AND AVG_WND_SPEED is null').withColumn('datetime',concat(col('YEAR'),lpad(col('MONTH'),2,'0'), lpad(col('DAY_OF_MONTH'),2,'0'), lpad(col('HOUR'),2,'0'))).orderBy('YEAR','MONTH','DAY_OF_MONTH','HOUR'))

# COMMAND ----------

test_null_counter = all_average_weather.filter('STATION == "72392523190"').withColumn('datetime',concat(col('YEAR'),lpad(col('MONTH'),2,'0'), lpad(col('DAY_OF_MONTH'),2,'0'), lpad(col('HOUR'),2,'0'))).orderBy('YEAR','MONTH','DAY_OF_MONTH','HOUR')

# COMMAND ----------

display(test_null_counter.withColumn("grp",
              f.row_number().over(Window.orderBy(col("datetime")))
              - f.row_number().over(Window.partitionBy("AVG_WND_SPEED").orderBy(col("datetime")))
              ) \
    .withColumn("Result", f.row_number().over(Window.partitionBy("grp").orderBy(col("datetime")))) \
    .drop("grp"))

# COMMAND ----------

from pyspark.sql import Window

# COMMAND ----------


