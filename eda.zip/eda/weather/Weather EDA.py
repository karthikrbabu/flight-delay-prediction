# Databricks notebook source
# MAGIC %md # Airline delays 
# MAGIC ## Bureau of Transportation Statistics
# MAGIC https://www.transtats.bts.gov/DL_SelectFields.asp?Table_ID=236   
# MAGIC https://www.bts.gov/topics/airlines-and-airports/understanding-reporting-causes-flight-delays-and-cancellations
# MAGIC 
# MAGIC 2015 - 2019

# COMMAND ----------

# MAGIC %md ### Additional sources
# MAGIC This might be useful in matching station codes to airports:
# MAGIC 1. http://dss.ucar.edu/datasets/ds353.4/inventories/station-list.html
# MAGIC 2. https://www.world-airport-codes.com/

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr,split,explode,split
from pyspark.sql.functions import isnan, when, count, col,isnull

import numpy as np
#spark = SparkSession.builder.getOrCreate()

sqlContext = SQLContext(sc)


# COMMAND ----------

# MAGIC %md # Weather
# MAGIC https://data.nodc.noaa.gov/cgi-bin/iso?id=gov.noaa.ncdc:C00532

# COMMAND ----------

# MAGIC %md
# MAGIC ## EDA on weather data
# MAGIC As a frequent flyer, we know that flight departures (and arrivals)  often get affected by weather conditions, so it makes sense to collect and process weather data corresponding to the origin and destination airports at the time of departure and arrival respectively and build features based upon this data. A weather table  has been pre-downloaded from the National Oceanic and Atmospheric Administration repository  to S3 in the form of  parquet files (thereby enabling pushdown querying and efficient joins). The weather data is for the period Jan 2015 – December 2019.

# COMMAND ----------

# ORIGINAL WEATHER DATA
weather = spark.read.option("header", "true")\
                    .parquet(f"dbfs:/mnt/mids-w261/datasets_final_project/weather_data/*.parquet")

# Adding specific date columns I need for JOIN
weather = weather.select(year(col("DATE")).alias("YEAR"), month(col("DATE")).alias("MONTH"), dayofmonth(col("DATE")).alias("DAY_OF_MONTH"), concat(rpad(lpad(hour(col("DATE")), 2, '0'), 4, '0'), lit('-'), lpad(hour(col("DATE")), 2, '0'), lit('59')).alias('HOUR_BLOCK'), *weather)

# Filter out all weather observations that don't align between station begin and end

display(weather)

# COMMAND ----------

weather.groupby('YEAR').count().display()

# COMMAND ----------

#stations is a csv file that contains the details of all the weather stations and the associated 'lat' and longitude
stations = spark.read.option("header", "true").csv("dbfs:/mnt/mids-w261/DEMO8/gsod/stations.csv.gz")

cleaned_weather = weather.join(stations, [concat(col("usaf"), col("wban")) == weather.STATION, col('country') == "US"]).filter(weather.DATE.between(to_timestamp(stations.begin, 'yyyyMMdd'), to_timestamp(stations.end, 'yyyyMMdd') + expr("INTERVAL 24 hours"))).select(*weather,stations.country)

cleaned_weather.display()

# COMMAND ----------

# we'll remove the rows from 2019 in this dataframe and treat 2019 separately as our test data
cleaned_weather = cleaned_weather.filter(cleaned_weather["YEAR"]!=2019)

# COMMAND ----------

cleaned_weather[['YEAR']].distinct().show()

# COMMAND ----------

weather.registerTempTable('weather')
stations.registerTempTable('stations')

cleaned_weather_19 = spark.sql("""
SELECT weather.*, stations.country
FROM weather, stations
WHERE weather.YEAR==2019 and concat(stations.usaf, stations.wban) == weather.STATION AND stations.country == 'US' """)
display(cleaned_weather_19)
cleaned_weather_19.count()

# COMMAND ----------

# The  original weather table has around 230 M records
cleaned_weather.count()

# COMMAND ----------

# MAGIC %md
# MAGIC Weather plays a crucial component in scheduling and on-time prediction of the flights.In this section we analyze the data collected at various stations and would try to identify their pattern and distribution.
# MAGIC 
# MAGIC Goal - We have the following high-level goals in mind:
# MAGIC - Understand the distribution of various variables.
# MAGIC - Understand the pattern with a goal to identify outliers and possible errors in reading(s).
# MAGIC 
# MAGIC Data :
# MAGIC Weather data is collected from various weather sensors placed at different stations. Each station has a corresponding number and readings from that station.
# MAGIC Let us start by taking an overall statistical summary of the data.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preface
# MAGIC The Integrated Surface Dataset (ISD) is composed of worldwide surface weather observations from over 35,000 stations parameters included are: air quality, atmospheric pressure, atmospheric temperature/dew point, atmospheric winds, clouds, precipitation, ocean waves, tides and more. 
# MAGIC 
# MAGIC We can broadly classify the elements of the dataset into two main categories:
# MAGIC - Mandatory data =>The mandatory data section contains meteorological information on the basic elements such as winds, visibility, and temperature.
# MAGIC These are the most commonly reported parameters and are available most of the time.
# MAGIC - Additional Data Section => These additional data contain information of significance and/or which are received with varying degrees of frequency.
# MAGIC 
# MAGIC For the purpose of this study :
# MAGIC - We will limit the weather observations to the stations in the US only.
# MAGIC - We'll focus on mandatory data section as the additional data is missing for most of the records.
# MAGIC - We'll ignore the 'remarks section as ,as these are a set of characeters in plain language that do not provide much insight into decision making.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Analysis of Mandatory data variables.

# COMMAND ----------

# MAGIC %md
# MAGIC #### W1.0-Station
# MAGIC This field represents a unique station id and is formed from the concatenation of weather station id and WBAN id. We'll use this identifier to get the weather details at a particular location.
# MAGIC 
# MAGIC #### W2.0 - Date
# MAGIC This field indicates a timestamp when the reading was taken corresponding to a station.

# COMMAND ----------

# MAGIC %md
# MAGIC #### W3.0 Source 
# MAGIC This is categorical data attribute.The flag of a GEOPHYSICAL-POINT-OBSERVATION showing the source or combination of sources used in creating the
# MAGIC observation.
# MAGIC We analyze the distribution of this column below.

# COMMAND ----------

# MAGIC %md
# MAGIC ### W4.0 Latitude and Longitude information.
# MAGIC This is latitude and longitude co-ordinate of a geo-location.
# MAGIC 
# MAGIC ###W5.0 Report- type
# MAGIC The code that denotes the type of geophysical surface observation.
# MAGIC 
# MAGIC ### W6.0 Elevation
# MAGIC The elevation of a GEOPHYSICAL-POINT-OBSERVATION relative to Mean Sea Level (MSL).
# MAGIC 
# MAGIC ### W7.0 Call_sign
# MAGIC  The identifier that represents the call letters assigned to a FIXED-WEATHER-STATION.
# MAGIC    - Missing values are denoted by 99999
# MAGIC 
# MAGIC #### W8.0 Quality Control 
# MAGIC  The name of the quality control process applied to a weather observation.
# MAGIC    - V01 = No A or M Quality Control applied
# MAGIC    - V02 = Automated Quality Control
# MAGIC    - V03 = subjected to Quality Control
# MAGIC    

# COMMAND ----------

# MAGIC %md
# MAGIC ### Weather observations- readings from various weather stations
# MAGIC The section below describes the actuel readings that are made from the sensors.
# MAGIC 
# MAGIC #### W9.0 Wind
# MAGIC The wind measurement is a composite field in our observation and consists of the following attributes.
# MAGIC 
# MAGIC #### W9.1 WIND-OBSERVATION direction angle
# MAGIC The angle(in angular degrees), measured in a clockwise direction, between true north and the direction from which the wind is blowing.
# MAGIC 
# MAGIC ### W9.2 WIND-OBSERVATION direction quality code
# MAGIC The code that denotes a quality status of a reported WIND-OBSERVATION direction angle.
# MAGIC  0 = Passed gross limits check
# MAGIC  1 = Passed all quality control checks
# MAGIC  2 = Suspect
# MAGIC  3 = Erroneous
# MAGIC  4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  6 = Suspect, data originate from an NCEI data source
# MAGIC  7 = Erroneous, data originate from an NCEI data source
# MAGIC  9 = Passed gross limits check if element is present
# MAGIC  
# MAGIC #### W9.2 Filters
# MAGIC    - We'll not use the following values in our analysis:
# MAGIC      - 2 = Suspect
# MAGIC      - 3 = Erroneous
# MAGIC      
# MAGIC ### W9.3 WIND-OBSERVATION type code
# MAGIC The code that denotes the character of the WIND-OBSERVATION.
# MAGIC 
# MAGIC 
# MAGIC ### W9.4 WIND-OBSERVATION speed rate
# MAGIC  The rate of horizontal travel of air past a fixed point.
# MAGIC 
# MAGIC **NOTE: If a value of 9 appears with a wind speed of 0000, this indicates calm winds.
# MAGIC 
# MAGIC ### W9.5 WIND-OBSERVATION speed quality code
# MAGIC  The code that denotes a quality status of a reported WIND-OBSERVATION speed rate.
# MAGIC - 0 = Passed gross limits check
# MAGIC - 1 = Passed all quality control checks
# MAGIC - 2 = Suspect
# MAGIC - 3 = Erroneous
# MAGIC - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC - 6 = Suspect, data originate from an NCEI data source
# MAGIC - 7 = Erroneous, data originate from an NCEI data source
# MAGIC - 9 = Passed gross limits check if element is present
# MAGIC  
# MAGIC #### W9.5 WIND-OBSERVATION speed quality code filters
# MAGIC We'll only retain the observations with the following values in our analysis
# MAGIC - 0 = Passed gross limits check
# MAGIC - 1 = Passed all quality control checks
# MAGIC - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC - 9 = Passed gross limits check if element is present
# MAGIC 
# MAGIC  

# COMMAND ----------

# MAGIC %md 
# MAGIC ### 10.Sky condition observations
# MAGIC The section below describes the high level description of the sky-condition observations.

# COMMAND ----------

# MAGIC %md
# MAGIC ### W10.1 SKY-CONDITION-OBSERVATION ceiling height dimension
# MAGIC The height above ground level (AGL) of the lowest cloud or obscuring phenomena layer aloft with 5/8 or more summation total sky
# MAGIC cover, which may be predominantly opaque, or the vertical visibility into a surface-based obstruction.
# MAGIC 
# MAGIC ### W10.2 SKY-CONDTION-OBSERVATION ceiling quality code
# MAGIC  The code that denotes a quality status of a reported ceiling height dimension.
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 2 = Suspect
# MAGIC  - 3 = Erroneous
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 6 = Suspect, data originate from an NCEI data source
# MAGIC  - 7 = Erroneous, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC  
# MAGIC #### W10.2 SKY-CONDTION-OBSERVATION ceiling quality code filters
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC  
# MAGIC ### W10.3 SKY-CONDTION-OBSERVATION ceiling quality code
# MAGIC The code that denotes the method used to determine the ceiling.
# MAGIC  - A = Aircraft
# MAGIC  - B = Balloon
# MAGIC  - C = Statistically derived
# MAGIC  - D = Persistent cirriform ceiling (pre-1950 data)
# MAGIC  - E = Estimated
# MAGIC  - M = Measured
# MAGIC  - P = Precipitation ceiling (pre-1950 data)
# MAGIC  - R = Radar
# MAGIC  - S = ASOS augmented
# MAGIC  - U = Unknown ceiling (pre-1950 data)
# MAGIC  - V = Variable ceiling (pre-1950 data)
# MAGIC  - W = Obscured
# MAGIC  - 9 = Missing
# MAGIC 
# MAGIC #### W10.3 SKY-CONDTION-OBSERVATION ceiling quality code filter
# MAGIC We'll only use the following attributes in our analysis.
# MAGIC  - A = Aircraft
# MAGIC  - B = Balloon
# MAGIC  - C = Statistically derived
# MAGIC  - E = Estimated
# MAGIC  - M = Measured
# MAGIC  - R = Radar
# MAGIC  - S = ASOS augmented
# MAGIC  - W = Obscured
# MAGIC  
# MAGIC  
# MAGIC 
# MAGIC ### W10.4 SKY-CONDITION-OBSERVATION CAVOK code
# MAGIC  The code that represents whether the 'Ceiling and Visibility Okay' (CAVOK) condition has been reported.
# MAGIC - N = No
# MAGIC - Y = Yes
# MAGIC - 9 = Missing
# MAGIC 
# MAGIC #### W10.4 SKY-CONDITION-OBSERVATION CAVOK code filter
# MAGIC We'll only use the following in our analysis:
# MAGIC - N= No
# MAGIC - Y = Yes

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Visibility observations
# MAGIC The section below provides a brief overview of the explanatory variables that indicate visibility

# COMMAND ----------

# MAGIC %md
# MAGIC ### W11.1 VISIBILITY-OBSERVATION distance dimension
# MAGIC The horizontal distance at which an object can be seen and identified.
# MAGIC 
# MAGIC ### W11.2 VISIBILITY-OBSERVATION distance quality code
# MAGIC The horizontal distance at which an object can be seen and identified.
# MAGIC The code that denotes a quality status of a reported distance of a visibility observation.
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 6 = Suspect, data originate from an NCEI data source
# MAGIC  - 7 = Erroneous, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC 
# MAGIC #### W11.1 VISIBILITY-OBSERVATION distance quality code filter
# MAGIC We'll only retain the observations with the following attributes 
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC 
# MAGIC 
# MAGIC ### W11.3  VISIBILITY-OBSERVATION variability code
# MAGIC The code that denotes whether or not the reported visibility is variable.
# MAGIC  - N = Not variable
# MAGIC  - V = Variable
# MAGIC  - 9 = Missing
# MAGIC 
# MAGIC ### W11.4 VISIBILITY-OBSERVATION quality variability code
# MAGIC The code that denotes a quality status of a reported VISIBILITY-OBSERVATION variability code.
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 2 = Suspect
# MAGIC  - 3 = Erroneous
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 6 = Suspect, data originate from an NCEI data source
# MAGIC  - 7 = Erroneous, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC 
# MAGIC #### W11.4  VISIBILITY-OBSERVATION quality variability code filter
# MAGIC We'll only retain the following values in our analysis:
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present

# COMMAND ----------

# MAGIC %md
# MAGIC ### Air Temperature attributes.
# MAGIC The section below provides a geenral overview of the data attributes for the observations on air temperature.

# COMMAND ----------

# MAGIC %md
# MAGIC ### W12.1 Air temperature
# MAGIC  The temperature of the air.
# MAGIC  MIN: -0932 MAX: +0618 UNITS: Degrees Celsius
# MAGIC  SCALING FACTOR: 10
# MAGIC ### W12.1 Air Temperature filter
# MAGIC Missing values are indicated by +9999 and will be ignored
# MAGIC 
# MAGIC ### W12.2 Air temperature quality code
# MAGIC  The code that denotes a quality status of an AIR-TEMPERATURE-OBSERVATION.
# MAGIC    - 0 = Passed gross limits check
# MAGIC    - 1 = Passed all quality control checks
# MAGIC    - 2 = Suspect
# MAGIC    - 3 = Erroneous
# MAGIC    - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC    - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC    - 6 = Suspect, data originate from an NCEI data source
# MAGIC    - 7 = Erroneous, data originate from an NCEI data source
# MAGIC    - 9 = Passed gross limits check if element is present
# MAGIC    - A = Data value flagged as suspect, but accepted as a good value
# MAGIC    - C = Temperature and dew point received from Automated Weather Observing System (AWOS) 
# MAGIC    - I = Data value not originally in data, but inserted by validator
# MAGIC    - M = Manual changes made to value based on information provided by NWS or FAA
# MAGIC    - P = Data value not originally flagged as suspect, but replaced by validator
# MAGIC    - R = Data value replaced with value computed by NCEI software
# MAGIC    - U = Data value replaced with edited value 
# MAGIC #### W12.2 Air temperature quality code filter
# MAGIC We'll only retain the following values
# MAGIC    - 0 = Passed gross limits check
# MAGIC    - 1 = Passed all quality control checks
# MAGIC    - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC    - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC    - 9 = Passed gross limits check if element is present
# MAGIC    - A = Data value flagged as suspect, but accepted as a good value
# MAGIC    - C = Temperature and dew point received from Automated Weather Observing System (AWOS) 
# MAGIC    - I = Data value not originally in data, but inserted by validator
# MAGIC    - M = Manual changes made to value based on information provided by NWS or FAA
# MAGIC    - P = Data value not originally flagged as suspect, but replaced by validator
# MAGIC    - R = Data value replaced with value computed by NCEI software
# MAGIC    - U = Data value replaced with edited value 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Dew Point observations
# MAGIC The sectio below describes the key attributes of the dew-point data collected from weather stations.

# COMMAND ----------

# MAGIC %md
# MAGIC ### W13.1 Dew Point temperature
# MAGIC The temperature in ,Degrees Celsius,to which a given parcel of air must be cooled at constant pressure and water vapor content in order for saturation to occur.
# MAGIC MIN: -0982 MAX: +0368 UNITS: 
# MAGIC 
# MAGIC ### W13.2 Dew point quality code
# MAGIC  The code that denotes a quality status of the reported dew point temperature.
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 2 = Suspect
# MAGIC  - 3 = Erroneous
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 6 = Suspect, data originate from an NCEI data source
# MAGIC  - 7 = Erroneous, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC  - A = Data value flagged as suspect, but accepted as a good value
# MAGIC  - C = Temperature and dew point received from Automated Weather Observing System (AWOS) 
# MAGIC  - I = Data value not originally in data, but inserted by validator
# MAGIC  - M = Manual changes made to value based on information provided by NWS or FAA
# MAGIC  - P = Data value not originally flagged as suspect, but replaced by validator
# MAGIC  - R = Data value replaced with value computed by NCEI software
# MAGIC  - U = Data value replaced with edited value
# MAGIC #### W13.2 Dew point quality code filter
# MAGIC  We'll retain the following values for our analysis
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC  - A = Data value flagged as suspect, but accepted as a good value
# MAGIC  - C = Temperature and dew point received from Automated Weather Observing System (AWOS) 
# MAGIC  - I = Data value not originally in data, but inserted by validator
# MAGIC  - M = Manual changes made to value based on information provided by NWS or FAA
# MAGIC  - P = Data value not originally flagged as suspect, but replaced by validator
# MAGIC  - R = Data value replaced with value computed by NCEI software
# MAGIC  - U = Data value replaced with edited value

# COMMAND ----------

# MAGIC %md
# MAGIC ### Atmospheric Pressure
# MAGIC The section below describes the various data observations on atmospheric pressure.

# COMMAND ----------

# MAGIC %md
# MAGIC #### W14.1 Sea level pressure 
# MAGIC The air pressure relative to Mean Sea Level (MSL).
# MAGIC #### W14.1 Sea level pressure filter
# MAGIC Missing values are denoted by 99999 and wo;; be ignored
# MAGIC 
# MAGIC #### W14.1 Sea level pressure quality code
# MAGIC  The code that denotes a quality status of the sea level pressure of an observation
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 2 = Suspect
# MAGIC  - 3 = Erroneous
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 6 = Suspect, data originate from an NCEI data source
# MAGIC  - 7 = Erroneous, data originate from an NCEI data sou
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC  
# MAGIC #### W14.2 Sea level pressure quality code filter
# MAGIC  We'll only retain the following observations.
# MAGIC  - 0 = Passed gross limits check
# MAGIC  - 1 = Passed all quality control checks
# MAGIC  - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC  - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC  - 9 = Passed gross limits check if element is present
# MAGIC  

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Additional Data section
# MAGIC As mentioned in the section above the 'additional data' corresponds to the attributes which are observed in addition to the mandatory observations. We present our analysis below on this additional data.

# COMMAND ----------

all_cols = cleaned_weather.columns

  
  

# COMMAND ----------


# df.orderBy(["age","city"],ascending=[0,1]).collect()
#[cleaned_weather.groupBy("AW1").count().orderBy(["count","AW1"],ascending = False).collect()][0]

# COMMAND ----------

# vals = []
# for col in (range(20,len(all_cols))):
#   print(cleaned_weather[col])
#   vals.append(cleaned_weather.groupBy(cleaned_weather[col]).count().orderBy(["count",cleaned_weather[col]],ascending = False).take(1))
#   #print(vals.append(cleaned_weather.groupBy(cleaned_weather[col]).count().orderBy(["count",cleaned_weather[col]],ascending = False).take(1)))


# COMMAND ----------

# for i in vals:
#   print(f'\n {i}')
  
  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Dropping columns with NA values
# MAGIC As we have seen in the previous section the columns that represent 'Additional Data' in the weather table has a lot of NA values. 
# MAGIC We'll remove these columns and work with the columns that indicate 'Mandatory weather variables'

# COMMAND ----------

cols_list = cleaned_weather.columns

# COMMAND ----------

# getting an index of all the columns
for i in range(0,len(cols_list)):
  print(f'i = {i} and col = {cols_list[i]}')
  
  

# COMMAND ----------

# Now lets drop the columns
temp_df = cleaned_weather
temp_df_new = cleaned_weather

cleaned_weather_trimmed = cleaned_weather

for i in range(20,len(cols_list)):
  print(f'ith column = {cols_list[i]}')
  temp_df_new = temp_df.drop(cols_list[i])
  cleaned_weather_trimmed = temp_df_new 
  temp_df = temp_df_new
  
#clean_weather_trimmed = temp_df_new
  
  
  
  

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Column split
# MAGIC Now that we've removed the unwanted columns we will focus on individual weather attibutes(WND etc.).
# MAGIC These observations related to the weather are grouped in a single column and we want to split it into multiple columns.
# MAGIC 
# MAGIC In the section that follows , we aim to wplit each combined column into multiple ones to continue our analysis.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Split 1- The Wind attributes.
# MAGIC The wind column has been combined to indicate the following attribute values of the measurement related to the wind:
# MAGIC - W1=>WIND-OBSERVATION direction angle,the angle, measured in a clockwise direction, between true north and the direction from which the wind is blowing.
# MAGIC  MIN: 001 MAX: 360 UNITS: Angular Degrees
# MAGIC  SCALING FACTOR: 1
# MAGIC  999 = Missing. If type code (below) = V, then 999 indicates variable wind direction.
# MAGIC  
# MAGIC - W2=> WIND-OBSERVATION direction quality code.The code that denotes a quality status of a reported WIND-OBSERVATION direction angle.
# MAGIC 
# MAGIC - W3=> WIND-OBSERVATION type code.The code that denotes the character of the WIND-OBSERVATION.
# MAGIC   - '9' indicates that the data is missing.
# MAGIC 
# MAGIC - W4=> WIND-OBSERVATION speed rate. The rate of horizontal travel of air past a fixed point.
# MAGIC  UNITS: meters per second
# MAGIC  SCALING FACTOR: 10.
# MAGIC  - 9999 indicates missing values
# MAGIC  
# MAGIC  - W5 =>WIND-OBSERVATION speed quality code. The code that denotes a quality status of a reported WIND-OBSERVATION speed rate.
# MAGIC  
# MAGIC  We'll now create additional columns in our "trimmed_data_frame" to represent these values as separate columns.
# MAGIC  
# MAGIC  - WND_Angle = WIND-OBSERVATION direction angle
# MAGIC  - WND_Qlty = WIND-OBSERVATION direction quality code
# MAGIC  - WND_Obs = WIND-OBSERVATION type code
# MAGIC  - WND_Speed = WIND-OBSERVATION speed rate
# MAGIC  - WND_Speed_Qlty = WIND-OBSERVATION speed quality code
# MAGIC  
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC   
# MAGIC   

# COMMAND ----------

#Let us now try to append these columns to the data frame
#df_concat = df_1.union(df_2)
from functools import reduce



#clean_weather_trimmed_split = clean_weather_trimmed.union(df_split)

# COMMAND ----------

# The code below splits the comma separated column values into individual columns.
#- WND_Angle = WIND-OBSERVATION direction angle
 #- WND_Qlty = WIND-OBSERVATION direction quality code
 #- WND_Obs = WIND-OBSERVATION type code
 #- WND_Speed = WIND-OBSERVATION speed rate
 #- WND_Speed_Qlty = WIND-OBSERVATION speed quality code
#weather_split = weather_split.withColumn('WIND_DIR', split_col.getItem(0).cast(IntegerType()))

split_col = f.split(cleaned_weather['WND'], ',')
cleaned_weather = cleaned_weather.withColumn('WND_Angle', split_col.getItem(0).cast(IntegerType()))
cleaned_weather = cleaned_weather.withColumn('WND_Qlty', split_col.getItem(1))
cleaned_weather = cleaned_weather.withColumn('WND_Obs', split_col.getItem(2))
cleaned_weather = cleaned_weather.withColumn('WND_Speed', split_col.getItem(3).cast(IntegerType()))
cleaned_weather = cleaned_weather.withColumn('WND_Speed_Qlty', split_col.getItem(4))
#df = df.withColumn('NAME2', split_col.getItem(1))

# COMMAND ----------

split_col = f.split(cleaned_weather['WND'], ',')
cleaned_weather_19 = cleaned_weather_19.withColumn('WND_Angle', split_col.getItem(0).cast(IntegerType()))
cleaned_weather_19 = cleaned_weather_19.withColumn('WND_Qlty', split_col.getItem(1))
cleaned_weather_19 = cleaned_weather_19.withColumn('WND_Obs', split_col.getItem(2))
cleaned_weather_19 = cleaned_weather_19.withColumn('WND_Speed', split_col.getItem(3).cast(IntegerType()))
cleaned_weather_19 = cleaned_weather_19.withColumn('WND_Speed_Qlty', split_col.getItem(4))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Split 2- The Sky Conditions
# MAGIC 
# MAGIC This column provides more information about the conditions of the sky.
# MAGIC We'll split the data into the following columns.

# COMMAND ----------

# We'll now split the CGI obervations into muliple columns

split_col = f.split(cleaned_weather['CIG'], ',')
cleaned_weather = cleaned_weather.withColumn('CIG_Height', split_col.getItem(0).cast(IntegerType()))
cleaned_weather = cleaned_weather.withColumn('CIG_Qlty', split_col.getItem(1))
cleaned_weather = cleaned_weather.withColumn('CIG_Ceiling', split_col.getItem(2))
cleaned_weather = cleaned_weather.withColumn('CIG_CAVOK', split_col.getItem(3))

#df = df.withColumn('NAME2', split_col.getItem(1))

# COMMAND ----------

split_col = f.split(cleaned_weather['CIG'], ',')
cleaned_weather_19 = cleaned_weather_19.withColumn('CIG_Height', split_col.getItem(0).cast(IntegerType()))
cleaned_weather_19 = cleaned_weather_19.withColumn('CIG_Qlty', split_col.getItem(1))
cleaned_weather_19 = cleaned_weather_19.withColumn('CIG_Ceiling', split_col.getItem(2))
cleaned_weather_19 = cleaned_weather_19.withColumn('CIG_CAVOK', split_col.getItem(3))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Split 3- The Visibility Conditions
# MAGIC 
# MAGIC This column provides more information about the visibility conditions.
# MAGIC 
# MAGIC  

# COMMAND ----------

#We will now split the column into muliple cols

split_col = f.split(cleaned_weather['VIS'], ',')
cleaned_weather = cleaned_weather.withColumn('VIS_Dis', split_col.getItem(0).cast(IntegerType()))
cleaned_weather = cleaned_weather.withColumn('VIS_Qlty', split_col.getItem(1))
cleaned_weather = cleaned_weather.withColumn('VIS_Var', split_col.getItem(2))
cleaned_weather = cleaned_weather.withColumn('VIS_Var_Qlty', split_col.getItem(3))



# COMMAND ----------

split_col = f.split(cleaned_weather['VIS'], ',')
cleaned_weather_19 = cleaned_weather_19.withColumn('VIS_Dis', split_col.getItem(0).cast(IntegerType()))
cleaned_weather_19 = cleaned_weather_19.withColumn('VIS_Qlty', split_col.getItem(1))
cleaned_weather_19 = cleaned_weather_19.withColumn('VIS_Var', split_col.getItem(2))
cleaned_weather_19 = cleaned_weather_19.withColumn('VIS_Var_Qlty', split_col.getItem(3))

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Split 4- The Temperature Observations
# MAGIC 
# MAGIC This column provides more information about the temperature conditions.
# MAGIC 
# MAGIC 
# MAGIC  

# COMMAND ----------


split_col = f.split(cleaned_weather['TMP'], ',')
cleaned_weather = cleaned_weather.withColumn('TMP_Degree', split_col.getItem(0).cast(IntegerType()))
cleaned_weather = cleaned_weather.withColumn('TMP_Qlty', split_col.getItem(1))


# COMMAND ----------

split_col = f.split(cleaned_weather['TMP'], ',')
cleaned_weather_19 = cleaned_weather_19.withColumn('TMP_Degree', split_col.getItem(0).cast(IntegerType()))
cleaned_weather_19 = cleaned_weather_19.withColumn('TMP_Qlty', split_col.getItem(1))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Split 5- The Dew Observations
# MAGIC 
# MAGIC These attributes indicate the Dew observations of the air

# COMMAND ----------

#SPlitting the DEW column


split_col = f.split(cleaned_weather['DEW'], ',')
cleaned_weather = cleaned_weather.withColumn('DEW_Degree', split_col.getItem(0).cast(IntegerType()))
cleaned_weather = cleaned_weather.withColumn('DEW_Qlty', split_col.getItem(1))

# COMMAND ----------

split_col = f.split(cleaned_weather['DEW'], ',')
cleaned_weather_19 = cleaned_weather_19.withColumn('DEW_Degree', split_col.getItem(0).cast(IntegerType()))
cleaned_weather_19 = cleaned_weather_19.withColumn('DEW_Qlty', split_col.getItem(1))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Split 6- The Pressure Observations
# MAGIC 
# MAGIC These attributes indicate the atmospheric pressure measurements.
# MAGIC  

# COMMAND ----------

split_col = f.split(cleaned_weather['SLP'], ',')
cleaned_weather = cleaned_weather.withColumn('SLP_Pressure', split_col.getItem(0).cast(IntegerType()))
cleaned_weather = cleaned_weather.withColumn('SLP_Qlty', split_col.getItem(1))

# COMMAND ----------

split_col = f.split(cleaned_weather['SLP'], ',')
cleaned_weather_19 = cleaned_weather_19.withColumn('SLP_Pressure', split_col.getItem(0).cast(IntegerType()))
cleaned_weather_19 = cleaned_weather_19.withColumn('SLP_Qlty', split_col.getItem(1))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Now our dataframe has all the columns that are split into individual values.WE'll now get rid of the aggregated columns - WND, SLP,VIS and TMP.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Let's now get rid of the redundant columns

# COMMAND ----------

cleaned_weather_final = cleaned_weather.drop("WND","CIG","VIS","TMP","DEW","SLP")
cleaned_weather_19_final = cleaned_weather_19.drop("WND","CIG","VIS","TMP","DEW","SLP")

# COMMAND ----------

#ANalyzing the cols

for i in range(10,len(cleaned_weather_final.columns)):
  print(cleaned_weather_final[i])
  #print(cleaned_weather_final.groupBy(cleaned_weather_final[i]).count().orderBy(["count",cleaned_weather_final[i]],ascending = False))
  
        
  

#for col in (range(20,len(all_cols))):
#   print(cleaned_weather[col])
#   vals.append(cleaned_weather.groupBy(cleaned_weather[col]).count().orderBy(["count",cleaned_weather[col]],ascending = False).take(1))
#   #print(vals.append(cleaned_weather.groupBy(cleaned_weather[col]).count().orderBy(["count",cleaned_weather[col]],ascending = False).take(1)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Analysis of Weather Attributes.
# MAGIC Now that we have finalized our data frame , let's analyze the Individueal features.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 1 - Analysis of "Wind"

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 1.1 Wind Angle -  The angle, measured in a clockwise direction, between true north and the direction from which the wind is blowing.
# MAGIC 
# MAGIC - Type = Quantitative
# MAGIC - Range = 1 - 360
# MAGIC - Missing  = 999

# COMMAND ----------

#Lets look at the statistics of WND_Angle
cleaned_weather_final[['WND_Angle']].describe().show()


# COMMAND ----------

#Analysis of Missing values

WND_Angle_NA =cleaned_weather_final.filter(cleaned_weather_final["WND_Angle"] == 999)

# COMMAND ----------

WND_Angle_present =cleaned_weather_final.filter(cleaned_weather_final["WND_Angle"] != 999)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### The plot below shows the average angle of WIND

# COMMAND ----------

WND_Angle_present[['YEAR','WND_Angle']].display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Missing values of WND_ANGLE over the years

# COMMAND ----------

WND_Angle_NA[['YEAR','WND_Angle']].display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC - The number of missing values for WND_ANGLE are roughly the same each year.

# COMMAND ----------

all_cols = cleaned_weather_final.columns

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1.2 Wind Qlty -The code that denotes a quality status of a reported WIND-OBSERVATION direction angle.
# MAGIC - Type = Qualitative
# MAGIC - Range = 0-9
# MAGIC - 0 = Passed gross limits check
# MAGIC - 1 = Passed all quality control checks
# MAGIC - 2 = Suspect
# MAGIC - 3 = Erroneous
# MAGIC - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC - 6 = Suspect, data originate from an NCEI data source
# MAGIC - 7 = Erroneous, data originate from an NCEI data source
# MAGIC - 9 = Passed gross limits check if element is present

# COMMAND ----------

#cleaned_weather_final.groupBy(cleaned_weather_final['WND_Qlty']).count().orderBy(["count",cleaned_weather_final['WND_Qlty']],ascending = False)

cleaned_weather_final[['WND_Qlty','YEAR']].groupBy("WND_Qlty","YEAR").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Observation:
# MAGIC Wind Quality:
# MAGIC -Our domain for this variable is 0-9 and  'Quality status' = 'U' , 'A' , 'P' are unknown values that we should drop.

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 1.3 Wind_Obs- The code that denotes the character of the WIND-OBSERVATION.
# MAGIC 
# MAGIC Type = Qualitative
# MAGIC - Missing Values = 9
# MAGIC - A = Abridged Beaufort
# MAGIC - B = Beaufort
# MAGIC - C = Calm
# MAGIC - H = 5-Minute Average Speed
# MAGIC - N = Normal
# MAGIC - R = 60-Minute Average Speed
# MAGIC - Q = Squall
# MAGIC - T = 180 Minute Average Speed
# MAGIC - V = Variable

# COMMAND ----------

cleaned_weather_final[['WND_Obs']].groupBy("WND_Obs").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC Wind_Obs:
# MAGIC -Almost 30% of the the values are unknown and should be analyzed further/dropped.

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1.4 Wind_Speed
# MAGIC - (Scaling factor = 10)
# MAGIC - Units = m/sec
# MAGIC - Type = Quantitative
# MAGIC - Scaling = 10
# MAGIC - Missing Values = 99999

# COMMAND ----------

WND_Speed_NA = cleaned_weather_final.filter(cleaned_weather_final["WND_Speed"] != 99999)

# COMMAND ----------

# MAGIC %md
# MAGIC ### The Bar chart below shows average Wind speed over the years

# COMMAND ----------

WND_Speed_NA[['WND_Speed','YEAR']].display()

# COMMAND ----------

cleaned_weather_final[['WND_Speed']].describe().show()

# COMMAND ----------

#Analysis of missing values

WND_NA = cleaned_weather_final.filter(cleaned_weather_final["WND_Speed"] == 9999)

# COMMAND ----------

# MAGIC %md
# MAGIC ### count of Missing values for WND_SPEED over the years

# COMMAND ----------

WND_NA[['WND_Speed','YEAR']].display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC Wind_Speed:
# MAGIC - Almost 6M records have missing values.
# MAGIC - The number is same across the years.

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 1.4 Wind_Speed_Qlty  The code that denotes a quality status of a reported WIND-OBSERVATION speed rate.
# MAGIC 
# MAGIC Type = Qualitative
# MAGIC 
# MAGIC - 0 = Passed gross limits check
# MAGIC - 1 = Passed all quality control checks
# MAGIC - 2 = Suspect
# MAGIC - 3 = Erroneous
# MAGIC - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC - 6 = Suspect, data originate from an NCEI data source
# MAGIC - 7 = Erroneous, data originate from an NCEI data source
# MAGIC - 9 = Passed gross limits check if element is present

# COMMAND ----------

cleaned_weather_final[['WND_Speed_Qlty','YEAR']].groupBy("WND_Speed_Qlty",'YEAR').count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC Wind Speed Quality:
# MAGIC -Our domain for this variable is 0-9 and  'Quality status' = 'U' , 'A' , 'P' , 'I' are unknown values that we should drop.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 2 - Analysis of "SKY Conditions"

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 2.1 CIG_Height.
# MAGIC The height above ground level (AGL) of the lowest cloud or obscuring phenomena layer , which may be predominantly opaque, or the vertical visibility into a surface-based obstruction.
# MAGIC - Type = Quantitative
# MAGIC - Range = 0-22000
# MAGIC - Missing  = 99999

# COMMAND ----------

cleaned_weather_final[['CIG_Height']].describe().show()

# COMMAND ----------

# Lets Check the number of missing values
cleaned_weather_final.filter(cleaned_weather_final["CIG_Height"] == 99999).count()

# COMMAND ----------

CIG_Height_present = cleaned_weather_final.filter(cleaned_weather_final["CIG_Height"] != 99999)

# COMMAND ----------

# MAGIC %md
# MAGIC ### The bar chart below displays the average of lowest obscuring phenomena over the years

# COMMAND ----------

CIG_Height_present[['CIG_Height','YEAR']].display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Observation:
# MAGIC CIG_Height:
# MAGIC - We have around 75878410 records that are missing.
# MAGIC - The vertical visibility does not change much on an average.

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 2.2 CIG_Qlty
# MAGIC The code that denotes a quality status of a reported ceiling height dimension.
# MAGIC 
# MAGIC - Type = Qualitative
# MAGIC - 0 = Passed gross limits check
# MAGIC - 1 = Passed all quality control checks
# MAGIC - 2 = Suspect
# MAGIC - 3 = Erroneous
# MAGIC - 4 = Passed gross limits check, data originate from an NCEI data source
# MAGIC - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC - 6 = Suspect, data originate from an NCEI data source
# MAGIC - 7 = Erroneous, data originate from an NCEI data source
# MAGIC - 9 = Passed gross limits check if element is present

# COMMAND ----------

cleaned_weather_final[['CIG_Qlty','YEAR']].groupBy("CIG_Qlty","YEAR").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Observation:
# MAGIC CIG_Height:
# MAGIC - This seems to be an important factor as the value is of 'reasonable' quality for all the records

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 2.3 CIG_Ceiling 
# MAGIC  The code that denotes the method used to determine the ceiling.
# MAGIC 
# MAGIC - Type = Qualitative
# MAGIC - Missing = 9
# MAGIC - Measured = 'M'
# MAGIC - Obscures = 'W'

# COMMAND ----------

cleaned_weather_final[['CIG_Ceiling']].groupBy("CIG_Ceiling").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC CIG_Ceiling:
# MAGIC - Almost 171M values are missing and should be dropped.

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2.4 CIG_CAVOK 
# MAGIC  The code that represents whether the 'Ceiling and Visibility Okay' (CAVOK) condition has been reported.
# MAGIC 
# MAGIC - Type = Qualitative
# MAGIC - Missing = 9

# COMMAND ----------

cleaned_weather_final[['CIG_CAVOK']].groupBy("CIG_CAVOK").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC CIG_CAVOK:
# MAGIC - Intesresting to note that there are no values for which CAVOK is 'Y'

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 3 - Analysis of "Visibility Conditions"

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 3.1 VIS_Dis
# MAGIC  The horizontal distance at which an object can be seen and identified.
# MAGIC - Units = Meters
# MAGIC - Type = Quantitative
# MAGIC - Range = 0-160000
# MAGIC - Missing  = 999999

# COMMAND ----------

# Lets take a count of missing values
cleaned_weather_final.filter(cleaned_weather_final["VIS_Dis"] == 999999).count()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC VIS_DIS:
# MAGIC - 69770868 missing values

# COMMAND ----------

VIS_DIS_present = cleaned_weather_final.filter(cleaned_weather_final["VIS_DIS"] != 999999)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Plot- Avg Visibility over years

# COMMAND ----------

VIS_DIS_present[['VIS_DIS','YEAR']].display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3.2 VIS_Qlty
# MAGIC  The code that denotes a quality status of a reported distance of a visibility observation.
# MAGIC 
# MAGIC - Type = Qualitative
# MAGIC - Range = 0-9
# MAGIC - 0 = Passed gross limits check
# MAGIC -  1 = Passed all quality control checks
# MAGIC - 2 = Suspect
# MAGIC - 3 = Erroneous
# MAGIC - 4 Passed gross limits check, data originate from an NCEI data source
# MAGIC - 5 = Passed all quality control checks, data originate from an NCEI data source
# MAGIC - 6 = Suspect, data originate from an NCEI data source-  7 = Erroneous, data originate from an NCEI data source
# MAGIC - 9 = Passed gross limits check if element is present

# COMMAND ----------

cleaned_weather_final[['VIS_Qlty']].groupBy("VIS_Qlty").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC VIS_QLTY:
# MAGIC - The values 'I','P','A' are outside our domain and should be dropped

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 3.3 VIS_Var
# MAGIC The code that denotes whether or not the reported visibility is variable.
# MAGIC 
# MAGIC 
# MAGIC - Type = Qualitative
# MAGIC - Range = N,V,9

# COMMAND ----------

cleaned_weather_final[['VIS_Var','YEAR']].groupBy("VIS_Var",'YEAR').count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3.4 VIS_Var_Qlty
# MAGIC - Type = Qualitative
# MAGIC - Range = 0-9

# COMMAND ----------

cleaned_weather_final[['VIS_Var_Qlty']].groupBy("VIS_Var_Qlty").count().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Observation:
# MAGIC VIS_QLTY:
# MAGIC - The value A' is outside our domain and should be dropped
# MAGIC - We shuld also further analyze the data values which are missing

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 4 - Analysis of "Temperature"

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 4.1 TMP_Degree
# MAGIC The temperature of the air in Degree Celcius
# MAGIC 
# MAGIC - Type = Quantitaive
# MAGIC - Scaling = 10
# MAGIC - Missing  =9999 

# COMMAND ----------

cleaned_weather_final.filter(cleaned_weather_final["TMP_Degree"] == 9999).count()

# COMMAND ----------

TMP_Degree_NA = cleaned_weather_final.filter(cleaned_weather_final["TMP_Degree"] == 9999)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Count of Missing values for TMP over the Years

# COMMAND ----------

TMP_Degree_NA[['TMP_Degree','YEAR']].display()

# COMMAND ----------

TMP_Degree_Not_NA = cleaned_weather_final.filter(cleaned_weather_final["TMP_Degree"] != 9999)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Avg TMP over the years

# COMMAND ----------

TMP_Degree_Not_NA[['TMP_Degree','YEAR']].display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Observations :
# MAGIC - The average temp for 2018 is marginally less(for those recs that have a value)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### 4.2 TMP_Qlty
# MAGIC The code that denotes a quality status of an AIR-TEMPERATURE-OBSERVATION.
# MAGIC 
# MAGIC - Type = Qualitative
# MAGIC - Missing  = 9999

# COMMAND ----------

cleaned_weather_final[['TMP_Qlty']].groupBy("TMP_Qlty").count().show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 5.1 - Dew_Degree
# MAGIC - Quantitative
# MAGIC - MIN: -0982 MAX: +0368
# MAGIC - UNITS: Degrees Celsius
# MAGIC - SCALING FACTOR: 10
# MAGIC - 9999 = Missing.

# COMMAND ----------

#Let us find out the missing values
cleaned_weather_final.filter(cleaned_weather_final["DEW_Degree"] == 9999).count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 5.2 - Dew_Qlty
# MAGIC - MIN: -0982 MAX: +0368
# MAGIC - UNITS: Degrees Celsius
# MAGIC - SCALING FACTOR: 10
# MAGIC - 9999 = Missing.

# COMMAND ----------

cleaned_weather_final[['DEW_Qlty']].groupBy("DEW_Qlty").count().show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 6 - Analysis of "Atmospheric pressure"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Section 6.1 - SLP_Pressure
# MAGIC The air pressure relative to Mean Sea Level (MSL).
# MAGIC - MIN: 08600 
# MAGIC - MAX: 10900
# MAGIC - UNITS: Hectopascals
# MAGIC - SCALING FACTOR: 10
# MAGIC - 99999 = Missing.

# COMMAND ----------

# Let;s analyze the missing values
cleaned_weather_final.filter(cleaned_weather_final["SLP_Pressure"] == 99999).count()

# COMMAND ----------

cleaned_weather_final[['SLP_Qlty']].groupBy("SLP_Qlty").count().show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Next, Lets drop all the missing values represented by 9's in the dataset.

# COMMAND ----------

cleaned_weather_final.columns


# COMMAND ----------

#Let's remove missing values for WND_Angle
##df.filter(df["age"]>24).show()
cleaned_weather_final_no_missing_vals = cleaned_weather_final.filter((cleaned_weather_final['WND_Angle'] != 999) | (cleaned_weather_final['WND_Obs'] != '9') | (cleaned_weather_final['WND_Speed'] != 9999) | (cleaned_weather_final['CIG_Height'] != 99999)|(cleaned_weather_final['CIG_CAVOK'] != '9') | (cleaned_weather_final['VIS_Dis'] != 999999)|(cleaned_weather_final['VIS_Var'] != '9') |(cleaned_weather_final['TMP_Degree'] != 9999) | (cleaned_weather_final['DEW_Degree'] != 9999) |(cleaned_weather_final['SLP_Pressure'] != 99999)|(cleaned_weather_final['REPORT_TYPE'] == 'FM-15'))


# COMMAND ----------

cleaned_weather_19_final.columns

# COMMAND ----------

cleaned_weather_final_no_missing_vals_19 = cleaned_weather_19_final.filter((cleaned_weather_19_final['WND_Angle'] != 999) | (cleaned_weather_19_final['WND_Obs'] != '9') | (cleaned_weather_19_final['WND_Speed'] != 9999) | (cleaned_weather_19_final['CIG_Height'] != 99999)|(cleaned_weather_19_final['CIG_CAVOK'] != '9') | (cleaned_weather_19_final['VIS_Dis'] != 999999)|(cleaned_weather_19_final['VIS_Var'] != '9') |(cleaned_weather_19_final['TMP_Degree'] != 9999) | (cleaned_weather_19_final['DEW_Degree'] != 9999) |(cleaned_weather_19_final['SLP_Pressure'] != 99999)|(cleaned_weather_19_final['REPORT_TYPE'] == 'FM-15'))


# COMMAND ----------

cleaned_weather_final_no_missing_vals.count()

# COMMAND ----------

cleaned_weather_final_no_missing_vals.count()

# COMMAND ----------

cleaned_weather_final_no_missing_vals_19.count()

# COMMAND ----------

weather_final = cleaned_weather_final_no_missing_vals
weather_final_19 = cleaned_weather_final_no_missing_vals_19

# COMMAND ----------

#weather_final= cleaned_weather_final_no_missing_vals.drop("CIG_Ceiling")

# COMMAND ----------

weather_final= cleaned_weather_final_no_missing_vals.drop("CIG_Ceiling")

# COMMAND ----------

weather_final.count()

# COMMAND ----------

weather_final.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_all_columns")

# COMMAND ----------

weather_final_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_19_all_columns")

# COMMAND ----------

missing_vals_train_val = cleaned_weather_final.filter((cleaned_weather_final['WND_Angle'] == 999) | (cleaned_weather_final['WND_Obs'] == '9') | (cleaned_weather_final['WND_Speed'] == 9999) | (cleaned_weather_final['CIG_Height'] == 99999)|(cleaned_weather_final['CIG_CAVOK'] == '9') | (cleaned_weather_final['VIS_Dis'] == 999999)|(cleaned_weather_final['VIS_Var'] == '9') |(cleaned_weather_final['TMP_Degree'] == 9999) | (cleaned_weather_final['DEW_Degree'] == 9999) |(cleaned_weather_final['SLP_Pressure'] == 99999)|(cleaned_weather_final['REPORT_TYPE'] == 'FM-15'))

# COMMAND ----------

missing_vals_19 = cleaned_weather_19_final.filter((cleaned_weather_19_final['WND_Angle'] == 999) | (cleaned_weather_19_final['WND_Obs'] == '9') | (cleaned_weather_19_final['WND_Speed'] == 9999) | (cleaned_weather_19_final['CIG_Height'] == 99999)|(cleaned_weather_19_final['CIG_CAVOK'] == '9') | (cleaned_weather_19_final['VIS_Dis'] == 999999)|(cleaned_weather_19_final['VIS_Var'] == '9') |(cleaned_weather_19_final['TMP_Degree'] == 9999) | (cleaned_weather_19_final['DEW_Degree'] == 9999) |(cleaned_weather_19_final['SLP_Pressure'] == 99999)|(cleaned_weather_19_final['REPORT_TYPE'] == 'FM-15'))

# COMMAND ----------

missing_vals_train_val[['WND_Angle','WND_Obs','WND_Speed','CIG_Height','VIS_Dis','TMP_Degree','DEW_Degree','SLP_Pressure','YEAR']].display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Observations:
# MAGIC - Intersting to note that 2018 has only missing values in WND_SPEED and SLP_Pressure

# COMMAND ----------

missing_vals_19[['WND_Angle','WND_Obs','WND_Speed','CIG_Height','VIS_Dis','TMP_Degree','DEW_Degree','SLP_Pressure','YEAR']].display()

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/mids-w261/team20SSDK/"))
