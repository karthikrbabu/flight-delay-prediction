# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext, Window
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np

#from haversine import haversine, Unit

sqlContext = SQLContext(sc)

# COMMAND ----------

average_weather_height = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_height')

# COMMAND ----------

average_weather_wnd = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_wnd')
average_weather_wnd.registerTempTable('wnd')
average_weather_wnd.count()

# COMMAND ----------

display(average_weather_height)

# COMMAND ----------

average_weather_height.count()

# COMMAND ----------

average_weather_height.registerTempTable('ht')

# COMMAND ----------

average_weather_vis = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_vis')

# COMMAND ----------

average_weather_vis.registerTempTable('vis')

# COMMAND ----------

display(average_weather_vis)

# COMMAND ----------

average_weather_vis.count()

# COMMAND ----------

average_weather_tmp = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_tmp')
average_weather_tmp.registerTempTable('tmp')

# COMMAND ----------

average_weather_dew = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_dew')
average_weather_dew.registerTempTable('dew')

# COMMAND ----------

average_weather_slp = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data/weather/avg_stations_slp')
average_weather_slp.registerTempTable('slp')

# COMMAND ----------

airlines_final = spark.read.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final")

# COMMAND ----------

# all airline data
all_station_dates = airlines_final.select('YEAR','MONTH','DAY_OF_MONTH','DEP_HOUR','ORIGIN_STATION','ORIGIN_TS') \
                                        .withColumn('W_YEAR', year(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_MONTH', month(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_DAY_OF_MONTH', dayofmonth(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .withColumn('W_HOUR', hour(airlines_final.ORIGIN_TS-expr('INTERVAL 2 HOURS'))) \
                                        .select('W_YEAR', 'W_MONTH', 'W_DAY_OF_MONTH', 'W_HOUR', 'ORIGIN_STATION').distinct().orderBy('W_YEAR','W_MONTH','W_DAY_OF_MONTH','W_HOUR','ORIGIN_STATION')
display(all_station_dates)
all_station_dates.registerTempTable('all_station_dates')

# COMMAND ----------

average_weather_height.printSchema()

# COMMAND ----------

combined_weather = spark.sql("""
SELECT W_YEAR as YEAR, W_MONTH as MONTH, W_DAY_OF_MONTH as DAY_OF_MONTH, W_HOUR as HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, STATION
FROM all_station_dates asd
LEFT JOIN ht ON ht.YEAR == asd.W_YEAR AND ht.MONTH == asd.W_MONTH AND ht.DAY_OF_MONTH == asd.W_DAY_OF_MONTH AND ht.HOUR == asd.W_HOUR
AND ht.STATION == asd.ORIGIN_STATION
ORDER BY W_YEAR, W_MONTH, W_DAY_OF_MONTH, W_HOUR, STATION
""")
display(combined_weather)

# COMMAND ----------

combined_weather.count()

# COMMAND ----------

combined_weather.registerTempTable('cmb')

# COMMAND ----------

all_station_dates.count()

# COMMAND ----------

combined_weather_2 = spark.sql("""
SELECT cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, 
AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN, cmb.STATION
FROM cmb
LEFT JOIN wnd ON wnd.YEAR == cmb.YEAR AND wnd.MONTH == cmb.MONTH AND wnd.DAY_OF_MONTH == cmb.DAY_OF_MONTH AND wnd.HOUR == cmb.HOUR
AND wnd.STATION == cmb.STATION
ORDER BY cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, cmb.STATION
""")
display(combined_weather_2)

# COMMAND ----------

combined_weather_2.registerTempTable('cmb')

# COMMAND ----------

combined_weather_3 = spark.sql("""
SELECT cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, 
AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN, 
MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS_STN,
cmb.STATION
FROM cmb
LEFT JOIN vis ON vis.YEAR == cmb.YEAR AND vis.MONTH == cmb.MONTH AND vis.DAY_OF_MONTH == cmb.DAY_OF_MONTH AND vis.HOUR == cmb.HOUR
AND vis.STATION == cmb.STATION
ORDER BY cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, cmb.STATION
""")
display(combined_weather_3)

# COMMAND ----------

combined_weather_3.registerTempTable('cmb')

# COMMAND ----------

combined_weather_4 = spark.sql("""
SELECT cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, 
AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN, 
MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS_STN,
AVG_TMP_DEG, VAR_TMP_DEG, CNT_TMP_DEG, CNT_TMP_DEG_STN,
cmb.STATION
FROM cmb
LEFT JOIN tmp ON tmp.YEAR == cmb.YEAR AND tmp.MONTH == cmb.MONTH AND tmp.DAY_OF_MONTH == cmb.DAY_OF_MONTH AND tmp.HOUR == cmb.HOUR
AND tmp.STATION == cmb.STATION
ORDER BY cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, cmb.STATION
""")
display(combined_weather_4)

# COMMAND ----------

combined_weather_4.registerTempTable('cmb')

# COMMAND ----------

combined_weather_5 = spark.sql("""
SELECT cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, 
AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN, 
MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS_STN,
AVG_TMP_DEG, VAR_TMP_DEG, CNT_TMP_DEG, CNT_TMP_DEG_STN,
AVG_DEW_DEG, VAR_DEW_DEG, CNT_DEW_DEG, CNT_DEW_DEG_STN,
cmb.STATION
FROM cmb
LEFT JOIN dew ON dew.YEAR == cmb.YEAR AND dew.MONTH == cmb.MONTH AND dew.DAY_OF_MONTH == cmb.DAY_OF_MONTH AND dew.HOUR == cmb.HOUR
AND dew.STATION == cmb.STATION
ORDER BY cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, cmb.STATION
""")
display(combined_weather_5)

# COMMAND ----------

combined_weather_5.registerTempTable('cmb')

# COMMAND ----------

combined_weather_6 = spark.sql("""
SELECT cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, 
AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN, 
MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS_STN,
AVG_TMP_DEG, VAR_TMP_DEG, CNT_TMP_DEG, CNT_TMP_DEG_STN,
AVG_DEW_DEG, VAR_DEW_DEG, CNT_DEW_DEG, CNT_DEW_DEG_STN,
AVG_SLP, VAR_SLP, CNT_SLP, CNT_SLP_STN,
cmb.STATION
FROM cmb
LEFT JOIN slp ON slp.YEAR == cmb.YEAR AND slp.MONTH == cmb.MONTH AND slp.DAY_OF_MONTH == cmb.DAY_OF_MONTH AND slp.HOUR == cmb.HOUR
AND slp.STATION == cmb.STATION
ORDER BY cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, cmb.STATION
""")
display(combined_weather_6)

# COMMAND ----------

combined_weather_6.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/weather/neighbor_station_avg')

# COMMAND ----------

combined_weather_6.registerTempTable('cmb')

# COMMAND ----------

combined_weather_6.write.parquet('dbfs:/mnt/mids-w261/team20SSDK/data-clan/weather/avg_weather_combined')

# COMMAND ----------

combined_weather_6 = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/data-clan/weather/avg_weather_combined')

# COMMAND ----------

final_combined_weather = spark.sql("""
SELECT cmb.*,
cmb.STATION, concat(cmb.STATION, cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR) as ID 
FROM cmb 
WHERE STATION is not null

ORDER BY cmb.STATION, cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR
""")

# COMMAND ----------

final_combined_weather = spark.sql("""
SELECT cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR, MIN_CIG_HEIGHT, AVG_CIG_HEIGHT, VAR_CIG_HEIGHT, CNT_CIG_HEIGHT, CNT_CIG_HEIGHT_STN, 
AVG_WND_SPEED, VAR_WND_SPEED, CNT_WND_SPEED, CNT_WND_SPEED_STN, 
MIN_VIS_DIS, AVG_VIS_DIS, VAR_VIS_DIS, CNT_VIS_DIS_STN,
AVG_TMP_DEG, VAR_TMP_DEG, CNT_TMP_DEG, CNT_TMP_DEG_STN,
AVG_DEW_DEG, VAR_DEW_DEG, CNT_DEW_DEG, CNT_DEW_DEG_STN,
AVG_SLP, VAR_SLP, CNT_SLP, CNT_SLP_STN,
cmb.STATION, concat(cmb.STATION, cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR) as ID FROM cmb ORDER BY cmb.STATION, cmb.YEAR, cmb.MONTH, cmb.DAY_OF_MONTH, cmb.HOUR
""")

# COMMAND ----------

all_station_dates.count()

# COMMAND ----------

final_combined_weather_gap_count = final_combined_weather.withColumn("grp",
              f.row_number().over(Window.orderBy(col("ID")))
              - f.row_number().over(Window.partitionBy("AVG_DEW_DEG").orderBy(col("ID")))
              ) \
    .withColumn("Result", f.row_number().over(Window.partitionBy("grp").orderBy(col("ID")))) \
    .drop("grp")

# COMMAND ----------

display(final_combined_weather_gap_count.filter('AVG_DEW_DEG is null').groupBy('Result').count())

# COMMAND ----------

display(final_combined_weather_gap_count)

# COMMAND ----------

display(final_combined_weather)

# COMMAND ----------

final_combined_weather.count()

# COMMAND ----------

display(combined_weather_6)

# COMMAND ----------

check_table = spark.sql("""
SELECT *
FROM all_station_dates asd
LEFT JOIN cmb ON cmb.YEAR == asd.W_YEAR AND cmb.MONTH == asd.W_MONTH AND cmb.DAY_OF_MONTH == asd.W_DAY_OF_MONTH AND cmb.HOUR == asd.W_HOUR
AND cmb.STATION == asd.ORIGIN_STATION
ORDER BY W_YEAR DESC, W_MONTH, W_DAY_OF_MONTH, W_HOUR, STATION
""")

# COMMAND ----------

display(check_table)

# COMMAND ----------


