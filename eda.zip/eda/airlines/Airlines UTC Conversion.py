# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC # Airlines UTC Conversion
# MAGIC 
# MAGIC The goal of this notebook is to use the cleaned up the `airlines` data and `airports_meta` table we have built to join on UTC information to our airlines data. This UTC information is critical to join the data with the `weather` data. 

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import isnan, when, count, col
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType


import pandas as pd
import us
import plotly.express as px
from datetime import datetime, timedelta
from pytz import timezone
import pytz
import math

sqlContext = SQLContext(sc)


# COMMAND ----------

 #Without UTC conversions
airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest/part-00*.parquet")
print("Number of cleaned airlines rows", airlines.count())
display(airlines)

# COMMAND ----------

#Total number of unique airports 
airlines_set = set([x.ORIGIN for x in airlines.select("ORIGIN").distinct().collect()] + [x.DEST for x in airlines.select("DEST").distinct().collect()])
len(airlines_set)

# COMMAND ----------

airport_meta = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta/part-0000*.parquet")
print("Number of cleaned airport_meta rows", airport_meta.count())
display(airport_meta)

# COMMAND ----------

#Outlier Airport that we are missing in our airlines_meta
airlines_meta_set = set([x.IATA for x in airport_meta.select("IATA").distinct().collect()])
airlines_set - airlines_meta_set

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get Origin Timezones

# COMMAND ----------

origins_joined = airlines.join(airport_meta, airlines.ORIGIN == airport_meta.IATA, how="left").select(airlines["*"],airport_meta["station_tz"].alias("ORIGIN_TZ"))
print(origins_joined.count())
display(origins_joined)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get Destination Timezones

# COMMAND ----------

final_airlines = origins_joined.join(airport_meta, origins_joined.DEST == airport_meta.IATA, how="left").select(origins_joined["*"], airport_meta["station_tz"].alias("DEST_TZ"))
print(final_airlines.count())
display(final_airlines)

# COMMAND ----------

#Just to verify that the missing row is the one that we saw from above - "XWA"
missing_tz = final_airlines.where((col("ORIGIN_TZ").isNull()) | (col("DEST_TZ").isNull()))

print(missing_tz.count())
display(missing_tz)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC **As Sean pointed out, Airport XWA doesn't have a known station ID and therefore we are unable to gather weather data regarding it, again as to why when pre processing we don't get an associated timezone. Because of this we are not able to gather much information regarding this station. **
# MAGIC 
# MAGIC **As per our train/test strategy all the flight data which we have interacting with this airport would not show up in training anyways. Therefore we will be removing the 406 rows flights that interact with this airport **

# COMMAND ----------

og_length = 31746841
after_pruned = 31171612+406
c_o_s = (og_length - after_pruned) / og_length
str(round(c_o_s*100,4))+'% of data discarded'

# COMMAND ----------

final_airlines = final_airlines.filter(col("ORIGIN") != "XWA").filter(col("DEST") != "XWA")

print(final_airlines.count())
display(final_airlines)

# COMMAND ----------

#Verifying that we dropped the XWA rows
31171612 - 31171206

# COMMAND ----------

#Just to verify that there is no missing states missing row is the one that we saw from above - "XWA"
missing_state = final_airlines.where((col("ORIGIN_STATE_ABR").isNull()) | (col("DEST_STATE_ABR").isNull()))

print(missing_state.count())
display(missing_state)

# COMMAND ----------

display(final_airlines.where((col("ORIGIN_STATE_ABR") == "TT") | (col("DEST_STATE_ABR") == "TT")))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Validation on depart, arrival, and flight times

# COMMAND ----------

# Ensure 24-hour time format is within range
final_airlines = final_airlines.filter((f.col('CRS_DEP_TIME')>=0)) \
                                 .filter((f.col('CRS_DEP_TIME')<2401)) \
                                 .filter((f.col('CRS_ARR_TIME')>=0)) \
                                 .filter((f.col('CRS_ARR_TIME')<2401)) \
                                 .filter((f.col('CRS_ELAPSED_TIME') > 15.0)) # Ensure we look at trips that were greater than 15 minutes
print(final_airlines.count())

# COMMAND ----------

#We drop 7 rows after the above filter
31171206 - 31171199

# COMMAND ----------

c_o_s = (31746841 - 31171199) / 31746841
str(round(c_o_s*100,4))+'% of data discarded, ' + str((31746841 - 31171199)) + ' rows'

# COMMAND ----------

# MAGIC %md 
# MAGIC 
# MAGIC ### Need for UTC Time
# MAGIC 
# MAGIC Time zone name in the form of region ID 'area/city', such as 'America/Los_Angeles'. This form of time zone info suffers from some of the problems that we described above like overlapping of local timestamps. However, each UTC time instant is unambiguously associated with one time zone offset for any region ID, and as a result, each timestamp with a region ID based time zone can be unambiguously converted to a timestamp with a zone offset.
# MAGIC 
# MAGIC Of course to join with `weather` data we need things in UTC  

# COMMAND ----------

# MAGIC %md
# MAGIC #### Helper functions to transform columns needed to build the UTC timestamp

# COMMAND ----------

#UDF time string to HOUR
def time_to_hour(time):
  def first_n_digits(num, n):
    return num // 10 ** (int(math.log(num, 10)) - n + 1)  
  if time < 100:
    return 0
  elif time >= 100 and time < 1000:
    return first_n_digits(time, 1)
  elif time == 1000:
    #Special edge case
    return 10
  elif time == 2400:
    #Special edge case
    return 0
  elif time > 1000:
    return first_n_digits(time, 2)

udf_time_to_hour = udf(time_to_hour, IntegerType())

#UDF time string to MINUTE
def time_to_mins(time):
  return time%100
udf_time_to_mins = udf(time_to_mins, IntegerType())

#UDF to convert departure timestamp 
def build_timestamp_dep(date, hour, minute):
  return str(date) + " " + str(hour)+ ":" + str(minute)

udf_build_timestamp_dep = udf(build_timestamp_dep, StringType())

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Note: Timezone conversion errors can occur due to ambiguity 
# MAGIC 
# MAGIC This is caused by daylight savings! We wanted to just track the number of times this occurs, through an accumulator

# COMMAND ----------

#To Track the ambiguos time conversion errors
accumCount=spark.sparkContext.accumulator(0)

# COMMAND ----------

#UDF to convert departure timestamp 
def build_timestamp_arr(dep_date, dep_hour, dep_min, origin_tz, dest_tz, elapsed_time, arr_hour, arr_min):

  #What is the departure time in the arrival states timezone
  originTz = timezone(origin_tz) 
  origin_ts = datetime.strptime (f"{dep_date} {dep_hour}:{dep_min}", "%Y-%m-%d %H:%M")  

  try:
    origin_dt = originTz.localize(origin_ts, is_dst=None)
    dest_state_dep_dt = origin_dt.astimezone(pytz.timezone(dest_tz))
  
    #Add in the elapsed time in minutes
    dest_state_dep_dt += timedelta(minutes=elapsed_time)

    #Get the new date (if at all changed)
    dest_date = dest_state_dep_dt.strftime("%Y-%m-%d")

    return str(dest_date) + " " + str(arr_hour)+ ":" + str(arr_min)

  except:

    #Add whenever we hit an ambiguous time and set is_dst to "True"
    accumCount.add(1)
    
    origin_dt = originTz.localize(origin_ts, is_dst=True)
    dest_state_dep_dt = origin_dt.astimezone(pytz.timezone(dest_tz))
  
    #Add in the elapsed time in minutes
    dest_state_dep_dt += timedelta(minutes=elapsed_time)

    #Get the new date (if at all changed)
    dest_date = dest_state_dep_dt.strftime("%Y-%m-%d")

    return str(dest_date) + " " + str(arr_hour)+ ":" + str(arr_min)    
    
    
    
udf_build_timestamp_arr = udf(build_timestamp_arr, StringType())

# COMMAND ----------

#Add hour and minute columns - DEPARTURE
final_airlines = final_airlines.withColumn("DEP_MIN", udf_time_to_mins(final_airlines.CRS_DEP_TIME)) \
                               .withColumn("DEP_HOUR", udf_time_to_hour(final_airlines.CRS_DEP_TIME)) \
                               .withColumn("ARR_MIN", udf_time_to_mins(final_airlines.CRS_ARR_TIME)) \
                               .withColumn("ARR_HOUR", udf_time_to_hour(final_airlines.CRS_ARR_TIME))


# COMMAND ----------

final_airlines.count()

# COMMAND ----------

#ORIGIN - time stamp and UTC column
final_airlines = final_airlines.withColumn("ORIGIN_TS", udf_build_timestamp_dep(final_airlines.FL_DATE, final_airlines.DEP_HOUR, final_airlines.DEP_MIN)) \
                   .withColumn("ORIGIN_TS", f.col("ORIGIN_TS").cast("Timestamp")) \
                   .withColumn("ORIGIN_UTC",f.to_utc_timestamp(f.col("ORIGIN_TS"), f.col("ORIGIN_TZ")))
display(final_airlines)

# COMMAND ----------

# #DEST - time stamp and UTC column
final_airlines = final_airlines.withColumn("DEST_TS", udf_build_timestamp_arr(final_airlines.FL_DATE, final_airlines.DEP_HOUR, final_airlines.DEP_MIN, 
                                                                  final_airlines.ORIGIN_TZ, final_airlines.DEST_TZ, final_airlines.CRS_ELAPSED_TIME, final_airlines.ARR_HOUR, final_airlines.ARR_MIN)) \
                   .withColumn("DEST_TS",f.col("DEST_TS").cast("Timestamp")) \
                   .withColumn("DEST_UTC",f.to_utc_timestamp(f.col("DEST_TS"), f.col("DEST_TZ")))

# COMMAND ----------

print(final_airlines.count())
display(final_airlines)

# COMMAND ----------

#One row that had a "NULL" with DIV_AIRPORT_LANDINGS
# final_airlines.where(col("DIV_AIRPORT_LANDINGS").isNull() | col("DEST_TS").isNull() | col("DEST_UTC").isNull()))

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc", True)
print(final_airlines.count())

#Write cleaned airlines data to our store
final_airlines.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc")

# COMMAND ----------



# COMMAND ----------

#This many ambiguous cases 
accumCount.value

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Everything should be clean from here on out!

# COMMAND ----------

airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc/part-00*.parquet")
print("Number of cleaned airlines rows", airlines.count())

# COMMAND ----------

#Saved the output printed it nicer below
# airlines.agg(*(f.countDistinct(f.col(c)).alias(c) for c in airlines.columns)).show()

# COMMAND ----------

#Convert the sample to Pandas so we can build some visuals
airlines_pd = airlines.toPandas()
print(airlines_pd.shape)
airlines_pd.head()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Airlines Column Analysis

# COMMAND ----------

# MAGIC %md
# MAGIC #### OP_CARRIER
# MAGIC 
# MAGIC * OP_UNIQUE_CARRIER: string (nullable = true)
# MAGIC * OP_CARRIER_AIRLINE_ID: integer (nullable = true)
# MAGIC * OP_CARRIER: string (nullable = true)

# COMMAND ----------

carrier_count = airlines_pd["OP_CARRIER"].value_counts()
carriers = list(carrier_count.index)
car_count = list(carrier_count)
carrier_count = pd.DataFrame({"carrier": carriers, "count":car_count})

# COMMAND ----------

fig = px.bar(carrier_count, x='carrier', y='count',
             hover_data=['carrier', 'count'], color='carrier',
             labels={'pop':'Number of Flights '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### ORIGIN_STATE_ABR

# COMMAND ----------

origin_state_count = airlines_pd["ORIGIN_STATE_ABR"].value_counts()
states = list(origin_state_count.index)
org_count = list(origin_state_count)
origin_state_count = pd.DataFrame({"states": states, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_state_count, x='states', y='count',
             hover_data=['states', 'count'], color='states',
             labels={'pop':'Number of Flights Origin By State '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### YEAR: integer (nullable = true)

# COMMAND ----------

origin_counts = airlines_pd["YEAR"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"year": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='year', y='count',
             hover_data=['year', 'count'], color='year',
             labels={'pop':'Number of Flights by Year '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### QUARTER: integer (nullable = true)

# COMMAND ----------

origin_counts = airlines_pd["QUARTER"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"quarter": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='quarter', y='count',
             hover_data=['quarter', 'count'], color='quarter',
             labels={'pop':'Number of Flights by Quarter '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### MONTH: integer (nullable = true)

# COMMAND ----------

origin_counts = airlines_pd["MONTH"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"month": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='month', y='count',
             hover_data=['month', 'count'], color='month',
             labels={'pop':'Number of Flights by Month '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### DAY_OF_MONTH: integer (nullable = true)

# COMMAND ----------

origin_counts = airlines_pd["DAY_OF_MONTH"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"day_of_month": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='day_of_month', y='count',
             hover_data=['day_of_month', 'count'], color='day_of_month',
             labels={'pop':'Number of Flights by DAY_OF_MONTH '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### DAY_OF_WEEK: integer (nullable = true)
# MAGIC 
# MAGIC 
# MAGIC 1. Monday
# MAGIC 2. Tuesday
# MAGIC 3. Wednesday
# MAGIC 4. Thursday
# MAGIC 5. Friday
# MAGIC 6. Saturday
# MAGIC 7. Sunday
# MAGIC 9. Unknown

# COMMAND ----------

origin_counts = airlines_pd["DAY_OF_WEEK"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"DAY_OF_WEEK": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='DAY_OF_WEEK', y='count',
             hover_data=['DAY_OF_WEEK', 'count'], color='DAY_OF_WEEK',
             labels={'pop':'Number of Flights by DAY_OF_WEEK '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### ORIGIN_CITY_MARKET_ID: string (nullable = true)

# COMMAND ----------

market_groups = pd.DataFrame({'count' : airlines_pd.groupby(['ORIGIN_CITY_MARKET_ID', 'ORIGIN_CITY_NAME'] ).size()}).reset_index()
market_groups.head()

# COMMAND ----------

market_groups[market_groups["ORIGIN_CITY_NAME"].str.contains("CA")]

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### ORIGIN: string (nullable = true)

# COMMAND ----------

origin_counts = airlines_pd["ORIGIN"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"ORIGIN": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='ORIGIN', y='count',
             hover_data=['ORIGIN', 'count'], color='ORIGIN',
             labels={'pop':'Number of Flights by ORIGIN '}, height=400) 
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### DEST: string (nullable = true)

# COMMAND ----------

origin_counts = airlines_pd["DEST"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"DEST": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='DEST', y='count',
             hover_data=['DEST', 'count'], color='DEST',
             labels={'pop':'Number of Flights by DEST '}, height=400)
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### DEP_DELAY: integer (nullable = true)

# COMMAND ----------

fig = px.histogram(airlines_pd, x="DEP_DELAY")
fig.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### DEP_DEL15: boolean (nullable = true)
# MAGIC 
# MAGIC * 1: Yes Delayed
# MAGIC * 0: Not Delayed
# MAGIC 
# MAGIC We have highly imbalanced data, in this way

# COMMAND ----------

origin_counts = airlines_pd["DEP_DEL15"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"DEP_DEL15": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='DEP_DEL15', y='count',
             hover_data=['DEP_DEL15', 'count'], color='DEP_DEL15',
             labels={'pop':'Number of Flights by DEP_DEL15 '}, height=400)
fig.show()

# COMMAND ----------

delays = (5658711/30641546)*100
on_time = (25512488/31171199)*100

print("Percent Delays: {0}%".format(delays))
print("Percent OnTime: {0}%".format(on_time))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### DISTANCE: string (nullable = true)
# MAGIC 
# MAGIC Distance between airports (miles)		

# COMMAND ----------

airlines_pd["DISTANCE"].mean()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### CRS_ELAPSED_TIME: string (nullable = true)
# MAGIC 
# MAGIC Time (minutes)		

# COMMAND ----------

airlines_pd["CRS_ELAPSED_TIME"].mean()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### AIR_TIME: string (nullable = true)
# MAGIC 
# MAGIC Time (minutes)

# COMMAND ----------

airlines_pd["AIR_TIME"].mean()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### FLIGHTS: double (nullable = true)
# MAGIC 
# MAGIC Number of flights, this is always 1.0

# COMMAND ----------

airlines_pd["FLIGHTS"].value_counts()

# COMMAND ----------

airlines_pd.head()

# COMMAND ----------

airlines.printSchema()

# COMMAND ----------


