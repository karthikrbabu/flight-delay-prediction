# Databricks notebook source
import numpy as np
import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt


import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.sql import Window
from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/final_datasets/data_range/part-00*.parquet")

print(data.count())
print(len(data.columns))
display(data)

# COMMAND ----------

data_pd = data.toPandas()

# COMMAND ----------

data_6 = data.where(col("YEAR") == 2015) \
             .where((col("ORIGIN") == "ORD") | (col("ORIGIN") == "ATL")) \
             .where(col("MONTH").isin([1,2,3,4,5,6]))

# COMMAND ----------

data_6_pd = data_6.toPandas()

# COMMAND ----------

carrier_count = data_pd["OP_UNIQUE_CARRIER"].value_counts()
carriers = list(carrier_count.index)
car_count = list(carrier_count)
carrier_count = pd.DataFrame({"carrier": carriers, "count":car_count})

# COMMAND ----------

fig = px.bar(carrier_count, x='carrier', y='count',
             hover_data=['carrier', 'count'], color='carrier',
             labels={'pop':'Number of Flights '}, height=400)
fig.show()

# COMMAND ----------

origin_counts = data_pd["DEP_DEL15"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"DEP_DEL15": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='DEP_DEL15', y='count',
             hover_data=['DEP_DEL15', 'count'], color='count',
             labels={'pop':'Number of Flights by DEP_DEL15 '}, height=400)
fig.show()

# COMMAND ----------

delays = (4444482/(4444482+20159249))*100
on_time = (20159249/(4444482+20159249))*100

print("Percent Delays: {0}%".format(delays))
print("Percent OnTime: {0}%".format(on_time))

# COMMAND ----------

origin_state_count = data_pd["ORIGIN_STATE_ABR"].value_counts()
states = list(origin_state_count.index)
org_count = list(origin_state_count)
origin_state_count = pd.DataFrame({"states": states, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_state_count, x='states', y='count',
             hover_data=['states', 'count'], color='states',
             labels={'pop':'Number of Flights Origin By State '}, height=400)
fig.show()

# COMMAND ----------

origin_counts = data_pd["YEAR"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"year": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='year', y='count',
             hover_data=['year', 'count'], color='count',
             labels={'pop':'Number of Flights by Year '}, height=400)
fig.show()

# COMMAND ----------

origin_counts = data_pd["MONTH"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"month": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='month', y='count',
             hover_data=['month', 'count'], color='count',
             labels={'pop':'Number of Flights by Month '}, height=400)
fig.show()

# COMMAND ----------

origin_counts = data_pd["DAY_OF_MONTH"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"day_of_month": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='day_of_month', y='count',
             hover_data=['day_of_month', 'count'], color='count',
             labels={'pop':'Number of Flights by DAY_OF_MONTH '}, height=400)
fig.show()

# COMMAND ----------

data_pd.head()

# COMMAND ----------

origin_counts = data_pd["DAY_OF_WEEK"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"day_of_week": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='day_of_week', y='count',
             hover_data=['day_of_week', 'count'], color='count',
             labels={'pop':'Number of Flights by DAY_OF_WEEK '}, height=400)
fig.show()

# COMMAND ----------

origin_counts = data_pd["DEP_HOUR"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"dep_hour": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='dep_hour', y='count',
             hover_data=['dep_hour', 'count'], color='count',
             labels={'pop':'Number of Flights by DEP_HOUR '}, height=400)
fig.show()

# COMMAND ----------

data_pd["ORIGIN_UTC_HOUR"] = [x.hour for x in data_pd["ORIGIN_UTC"]]

# COMMAND ----------

origin_counts = data_pd["ORIGIN_UTC_HOUR"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"ORIGIN_UTC_HOUR": units, "count":org_count})

fig = px.bar(origin_count_pd, x='ORIGIN_UTC_HOUR', y='count',
             hover_data=['ORIGIN_UTC_HOUR', 'count'], color='count',
             labels={'pop':'Number of Flights by ORIGIN_UTC_HOUR '}, height=400)
fig.show()

# COMMAND ----------

origin_counts = data_pd["DEP_DELAY_GROUP"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"DEP_DELAY_GROUP": units, "count":org_count})

fig = px.bar(origin_count_pd, x='DEP_DELAY_GROUP', y='count',
             hover_data=['DEP_DELAY_GROUP', 'count'], color='DEP_DELAY_GROUP',
             labels={'pop':'Number of Flights by DEP_DELAY_GROUP '}, height=400)
fig.show()

# COMMAND ----------

airport_meta = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta/part-00000*.parquet")
print(airport_meta.count())
display(airport_meta)

# COMMAND ----------

airport_meta_pd = airport_meta.toPandas()

# COMMAND ----------

fig = px.histogram(airport_meta_pd , x="pagerank", nbins=100)
fig.show()

# COMMAND ----------

airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_final/part-00*.parquet")
print(airlines.count())
airlines_pd = airlines.toPandas()

# COMMAND ----------

origin_counts = airlines_pd["YEAR"].value_counts()
units = list(origin_counts.index)
org_count = list(origin_counts)
origin_count_pd = pd.DataFrame({"year": units, "count":org_count})

# COMMAND ----------

fig = px.bar(origin_count_pd, x='year', y='count',
             hover_data=['year', 'count'], color='count',
             labels={'pop':'Number of Flights by Year '}, height=400)
fig.show()

# COMMAND ----------

np.array(data_pd.columns)

# COMMAND ----------

carrier_count = data_pd["ORIGIN"].value_counts()
carriers = list(carrier_count.index)
car_count = list(carrier_count)
carrier_count = pd.DataFrame({"ORIGIN": carriers, "count":car_count})

# COMMAND ----------

fig = px.bar(carrier_count, x='ORIGIN', y='count',
             hover_data=['ORIGIN', 'count'], color='ORIGIN',
             labels={'pop':'Number of ORIGIN '}, height=400)
fig.show()

# COMMAND ----------

num_cols = ['DISTANCE', 'CRS_ELAPSED_TIME','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
            'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
            'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
            'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
            'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
            'AVG_SLP_DEST']

# COMMAND ----------

pr_to_del = data_pd.loc[:,num_cols]
pr_to_del.head()

# COMMAND ----------

corrMatrix = pr_to_del.corr()


print(corrMatrix)

# COMMAND ----------

import seaborn as sn
import matplotlib.pyplot as plt

df_lt = corrMatrix.where(np.tril(np.ones(corrMatrix.shape)).astype(np.bool))

fig, ax = plt.subplots(figsize=(15,10))         # Sample figsize in inches
sn.heatmap(df_lt, annot=True, linewidths=.5, ax=ax)
plt.show()

# COMMAND ----------


