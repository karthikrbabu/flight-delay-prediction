# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC Station Metadata:
# MAGIC * usaf = Air Force station ID.
# MAGIC * wban = NCDC WBAN number
# MAGIC * name = Station Name
# MAGIC * country = FIPS country ID
# MAGIC * state = State for US stations
# MAGIC * ICAO = ICAO ID
# MAGIC * LAT = Latitude in thousandths of decimal degrees
# MAGIC * LON = Longitude in thousandths of decimal degrees
# MAGIC * ELEV = Elevation in meters
# MAGIC * BEGIN = Beginning Period Of Record (YYYYMMDD). There may be reporting gaps within the P.O.R.
# MAGIC * END = Ending Period Of Record (YYYYMMDD). There may be reporting gaps within the P.O.R.

# COMMAND ----------

pip install haversine

# COMMAND ----------

pip install timezonefinder

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.functions import concat, col
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext

from haversine import haversine, Unit
from timezonefinder import TimezoneFinder

sqlContext = SQLContext(sc)


# COMMAND ----------

stations = spark.read.option("header", "true").csv("dbfs:/mnt/mids-w261/DEMO8/gsod/stations.csv.gz")

# COMMAND ----------

stations.printSchema()

# COMMAND ----------

# How many stations are there?
stations.count()

# COMMAND ----------

# How many stations in the US?
us_stations = stations.where('end > "20150101"')
us_stations.count()

# COMMAND ----------

# descriptive summary
display(us_stations.describe())

# COMMAND ----------

# How many US stations active during time period (2015-01-01 to 2015-06-30)?
us_stations.where('(begin <= 20150630 OR end >= 20150101)').count()

# COMMAND ----------

# How many US stations were active for less than the range (started and ended within the period) (2015-01-01 to 2015-06-30)?
us_stations.where('begin >= 20150101 AND end <= 20150630').count()

# COMMAND ----------

# Which US stations deactivated during the range (2015-01-01 to 2015-06-30)?
display(us_stations.where('end >= 20150101 AND end <= 20150630'))

# COMMAND ----------

# Which US stations activating during the range (2015-01-01 to 2015-06-30)?
display(us_stations.where('begin >= 20150101 AND begin <= 20150630'))

# COMMAND ----------

# Get the weather data
weather = spark.read.option("header", "true")\
                    .parquet(f"dbfs:/mnt/mids-w261/datasets_final_project/weather_data/*.parquet")
f'{weather.count():,}'

# COMMAND ----------

# dataframe for stations activated during date range
stations_us_activated = us_stations.where('country == "US" AND begin >= 20150101 AND begin <= 20150630').withColumn('station_id', f.concat(f.col('usaf'), f.col('wban')))
# dataframe for stations deactivated during date range
stations_us_deactivated = us_stations.where('country == "US" AND end >= 20150101 AND end <= 20150630').withColumn('station_id', f.concat(f.col('usaf'), f.col('wban')))
# dataframe for stations active at all during date range
stations_us_active = us_stations.where('country == "US" AND (begin <= 20150630 OR end >= 20150101)').withColumn('station_id', f.concat(f.col('usaf'), f.col('wban')))
# weather within date range
weather_in_range = weather.where('DATE >= "2015-01-01T00:00:00" AND DATE <= "2015-06-30T23:59:59"').withColumn('station_date', f.date_format('DATE','yyyyMMdd'))

# COMMAND ----------

# looking for mistakes in the weather data.  Are there any weather values from before the station begin date?
stations_us_activated.join(weather_in_range, [weather_in_range.STATION == stations_us_activated.station_id, stations_us_activated.begin > weather_in_range.station_date]).count()

# COMMAND ----------

# looking for mistakes in the weather data.  Are there any weather values that end after the station end date?
stations_us_deactivated.join(weather_in_range, [weather_in_range.STATION == stations_us_deactivated.station_id, stations_us_deactivated.end < weather_in_range.station_date]).count()

# COMMAND ----------

# How many weather measurements does each station have? If measurements are hourly it should be 180x24 = 4320
weather_measurements_per_station = stations_us_active.join(weather_in_range, [weather_in_range.STATION == stations_us_active.station_id]).groupBy('station_id').count()
wmps_df = weather_measurements_per_station.toPandas()

# COMMAND ----------

# Trying to plot the histogram.  Not sure about labeling in databricks
ax = wmps_df.hist(figsize=(16,8),bins=50)
ax.set_xlabel='Measurements'
ax.set_ylabel='Station Count'

# COMMAND ----------

# tried using databrick plotting, but not 100% sure how this works
display(weather_measurements_per_station)

# COMMAND ----------

# save out the low and high count stations
low_count_stations = weather_measurements_per_station.where('count < 3500').withColumnRenamed("station_id", "station_count_id")   
high_count_stations = weather_measurements_per_station.where('count > 13000').withColumnRenamed("station_id", "station_count_id")   
low_count_stations.join(stations_us_active, [low_count_stations.station_count_id == stations_us_active.station_id]).write.format('com.databricks.spark.csv').option('header', 'true').save('dbfs:/mnt/mids-w261/team20SSDK/data/station/low_weather_measurement_stations.csv')
high_count_stations.join(stations_us_active, [high_count_stations.station_count_id == stations_us_active.station_id]).write.format('com.databricks.spark.csv').option('header', 'true').save('dbfs:/mnt/mids-w261/team20SSDK/data/station/high_weather_measurement_stations.csv')

# COMMAND ----------

# Details on the stations lowest counts of weather metrics
display(low_count_stations.join(stations_us_active, [low_count_stations.station_count_id == stations_us_active.station_id]))

# COMMAND ----------

# Details on the stations highest counts of weather metrics
display(high_count_stations.join(stations_us_active, [high_count_stations.station_count_id == stations_us_active.station_id]))

# COMMAND ----------

# MAGIC %md
# MAGIC # Now with full dataset

# COMMAND ----------

us_stations.registerTempTable('us_stations_table')
us_stations_df = sqlContext.sql('select *, if(begin < "20150101","20150101",begin) as begin_dataset from us_stations_table')
us_stations_df.show()

# COMMAND ----------

def begin_dataset(value):
  if value < '20150101':
    return '20150101'
  else:
    return value
    
udf_begin_dataset = f.udf(begin_dataset, StringType())

us_stations_df = us_stations.withColumn("begin_dataset", udf_begin_dataset("begin"))


# COMMAND ----------

display(us_stations_df)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC # Working with station nearest neighbors
# MAGIC ## Let's reduce the station list to the ones that are within 50 miles of an airport

# COMMAND ----------

# Code from Sanjay's notebook:
locations = stations.where('country == "US" OR country == "GQ" OR country == "PR"').select(concat(col("usaf"), col("wban")).alias("station_id"), col("lat"), col("lon")).distinct().where(col("lat").isNotNull()).where(col("lon").isNotNull())
display(locations)

###

locations = locations.toPandas()
locations

###
coords = []

for long, lat, station_id in zip(locations['lat'], locations['lon'], locations['station_id']):
    coords.append((float(lat),float(long), station_id))

print(coords)

###
from itertools import permutations

coords_list = []

for combo in permutations(coords, 2): 
    coords_list.append(combo)
    
###

coords_rdd = sc.parallelize(coords_list)
coords_rdd.count()

###

def calcHaversine(x):
    origin, dest = x[0], x[1]
    dest_dict = {}
    dist = haversine(origin[:2], dest[:2], unit=Unit.MILES)
    dest_dict[dest] = dist
    return (origin, dest_dict)
  
def updateDict(x, y):
    x.update(y)
    return x

result = coords_rdd.map(lambda x: calcHaversine(x)) \
                   .reduceByKey(lambda x, y: updateDict(x, y)).cache()

result.collect()

###

def getStationNeighbors(x):
    origin, dest = x[0], x[1]
    yield (origin[2], origin[2])
    sorted_list = [str(i[0][2]) for i in filter(lambda x: x[1] <= 50.0, sorted(dest.items(), key=lambda x: x[1])[:5])]
    for i in sorted_list:
        yield(origin[2], i)

clusters = result.flatMap(lambda x: getStationNeighbors(x)).cache()

clusters.collect()

###

station_neighbors = spark.createDataFrame(clusters).toDF("station_id", "neighbor_id")
display(station_neighbors)
station_neighbors.count()

###

# COMMAND ----------

# Get Karthik's US Stations list
us_stations_all = spark.sql("select * from us_stations_all")
display(us_stations_all.select("*"))
# Join with the supplied stations list to get the station ids
stations_final = us_stations.join(us_stations_all.alias('uss'), us_stations.call == col('uss.ICAO')).select(*us_stations, col('uss.IATA').alias('IATA'), concat(col('usaf'),col('wban')).alias('station_id'))
# get all the flights
airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc/part-00*.parquet")
# get all the unique airport codes from both origins and destinations
all_airport_codes = airlines.select(col('origin').alias('IATA')).distinct().union(airlines.select('DEST').distinct()).distinct()
# join the unique airport list to stations
airport_stations = stations_final.join(all_airport_codes, ['IATA'])
# join the airport stations with the station neighbors list
airport_stations_neighbors = airport_stations.join(station_neighbors, ['station_id'])
# get the unique list of airport stations and neighbors
airport_and_neighbor_stations = airport_stations_neighbors.select('station_id').distinct().union(airport_stations_neighbors.select('neighbor_id').distinct())

# COMMAND ----------

# see if the counts of airport codes match
print(all_airport_codes.count())
print(airport_stations.count())

# COMMAND ----------

# They don't.  Which airports are missing?
display(all_airport_codes.join(stations_final, ['IATA'], 'left_anti'))

# COMMAND ----------

# join the airport codes to the stations so we can associate IATA codes
airport_and_neighbor_stations_expanded = airport_and_neighbor_stations.join(stations_final, ['station_id'])#.where('end > 20150101')
stations_minimal = airport_and_neighbor_stations_expanded.select(col('station_id'), col('IATA'))

# COMMAND ----------

# write the station neighbors with the IATA Codes
station_neighbors.join(stations_minimal.select('station_id'), ['station_id']).repartition(1).write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_neighbors')

# COMMAND ----------

# add the timezone to each station so we can calculate UTC
def find_tz(lat, lng):
  tf = TimezoneFinder()
  return tf.timezone_at(lat=float(lat), lng=float(lng))

find_tz_udf = f.udf(lambda lat,lng: find_tz(lat, lng), StringType())

airport_and_neighbor_stations_expanded_tz = airport_and_neighbor_stations_expanded.withColumn('station_tz', find_tz_udf(col('lat'), col('lon')))

# COMMAND ----------

display(airport_and_neighbor_stations_expanded_tz)

# COMMAND ----------

# write the airport list with all station info including time zone
airport_and_neighbor_stations_expanded_tz.distinct().write.mode('overwrite').parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_meta')

# COMMAND ----------

weather_measurements_per_station = airport_and_neighbor_stations.join(weather_in_range, [weather_in_range.STATION == airport_and_neighbor_stations.station_id]).groupBy('station_id').count()

# COMMAND ----------

weather_cleaned = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/weather/weather_final/')

# COMMAND ----------

airport_and_neighbor_stations_expanded_tz = spark.read.parquet('dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_meta')
stations_minimal = airport_and_neighbor_stations_expanded_tz.select(col('station_id'), col('IATA'))

# COMMAND ----------

weather_dated = weather_cleaned.select(*weather_cleaned, f.date_format('DATE','yyyyMMdd').alias('the_date'))
weather_station_date_count = stations_minimal.join(weather_dated, weather_dated.STATION == stations_minimal.station_id).groupBy('the_date','station_id').count()

# COMMAND ----------

display(weather_station_date_count.select('count'))

# COMMAND ----------

weather_station_date_count.select(col('count').alias('metrics_per_day')).groupBy('metrics_per_day').count().display()

# COMMAND ----------

weather_metrics_count_by_day = weather_station_date_count.select(col('count').alias('metrics_per_day')).filter('metrics_per_day < 25').groupBy('metrics_per_day').count().toPandas()

# COMMAND ----------

import plotly.express as px


# COMMAND ----------

fig = px.bar(weather_metrics_count_by_day, x='metrics_per_day', y='count',
             hover_data=['metrics_per_day', 'count'], color='count',
             labels={'pop':'Number of metrics reported per day '}, height=400)
fig.show()

# COMMAND ----------


