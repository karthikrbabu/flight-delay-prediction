# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext, Window
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr, count, when
import numpy as np

import pandas as pd, matplotlib.pyplot as plt
import matplotlib.cm as cm, matplotlib.font_manager as fm
from datetime import datetime as dt
# from sklearn.cluster import DBSCAN

# from haversine import haversine, Unit

sqlContext = SQLContext(sc)

# COMMAND ----------

w15nn = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/weather/15nn_weather_metrics")
display(w15nn)
w15nn.count()

# COMMAND ----------

w30nn = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/weather/30nn_weather_metrics")
display(w30nn)
w15nn.count()

# COMMAND ----------

display(w30nn.filter("STATION == '78520300398' AND YEAR == 2018 AND MONTH == 2 AND DAY_OF_MONTH == 9"))

# COMMAND ----------

weather_metrics_imputed = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_imputed")
display(weather_metrics_imputed)

# COMMAND ----------

display(weather_metrics_imputed.filter("STATION == '78520300398' AND YEAR == 2018 AND MONTH == 2 AND DAY_OF_MONTH == 9"))

# COMMAND ----------

weather_trimmed = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_trimmed")
display(weather_trimmed)

# COMMAND ----------

display(weather_trimmed.filter("STATION == '78520300398' AND YEAR == 2018 AND MONTH == 2 AND DAY_OF_MONTH == 9"))

# COMMAND ----------

station_neighbors = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_neighbors")
display(station_neighbors)

# COMMAND ----------

display(station_neighbors.filter("station_id == '78520300398'"))

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final")
display(data)

# COMMAND ----------

display(data.filter("ORIGIN_STATION == '78520300398' AND YEAR == 2018 AND MONTH == 2 AND DAY_OF_MONTH == 9"))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Ensuring Test Data Uses Raw Weather Metrics

# COMMAND ----------

test_data = data.filter("Year == 2019")
display(test_data)
test_data.count()

# COMMAND ----------

weather_imputed = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_imputed")
display(weather_imputed)
weather_imputed.count()

# COMMAND ----------

weather_imputed.select("STATION", "DATE", "SOURCE").distinct().count()

# COMMAND ----------

weather_imputed.columns

# COMMAND ----------

airlines_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/airlines_final")

display(airlines_final)

# COMMAND ----------

airlines_final.registerTempTable('airlines_final')
weather_imputed.registerTempTable('weather_imputed')

# COMMAND ----------

data_2019 = spark.sql("""
SELECT a.*, avg(wmo.WND_SPEED) as AVG_WND_SPEED_ORIGIN, avg(wmo.CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, 
       min(wmo.CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, avg(wmo.VIS_DIS) as AVG_VIS_DIS_ORIGIN, 
       min(wmo.VIS_DIS) as MIN_VIS_DIS_ORIGIN, avg(wmo.TMP_DEGREE) as AVG_TMP_DEG_ORIGIN,   
       avg(wmo.DEW_DEGREE) as AVG_DEW_DEG_ORIGIN, avg(wmo.SLP_PRESSURE) as AVG_SLP_ORIGIN, 
       avg(wmd.WND_SPEED) as AVG_WND_SPEED_DEST, avg(wmd.CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       min(wmd.CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, avg(wmd.VIS_DIS) as AVG_VIS_DIS_DEST, 
       min(wmd.VIS_DIS) as MIN_VIS_DIS_DEST, avg(wmd.TMP_DEGREE) as AVG_TMP_DEG_DEST, 
       avg(wmd.DEW_DEGREE) as AVG_DEW_DEG_DEST, avg(wmd.SLP_PRESSURE) as AVG_SLP_DEST
FROM airlines_final as a 
  LEFT JOIN weather_imputed as wmo 
    ON a.ORIGIN_STATION == wmo.STATION AND wmo.DATE == a.ORIGIN_MAX_DATE
  LEFT JOIN weather_imputed as wmd 
    ON a.DEST_STATION == wmd.STATION AND wmd.DATE == a.DEST_MAX_DATE
WHERE EXTRACT(YEAR FROM a.ORIGIN_UTC) >= 2019
GROUP BY a.YEAR, a.QUARTER, a.MONTH, a.DAY_OF_MONTH, a.DAY_OF_WEEK, a.FL_DATE, a.OP_UNIQUE_CARRIER,
         a.OP_CARRIER_AIRLINE_ID, a.OP_CARRIER, a.TAIL_NUM, a.OP_CARRIER_FL_NUM, a.ORIGIN_AIRPORT_ID, 
         a.ORIGIN_AIRPORT_SEQ_ID, a.ORIGIN_CITY_MARKET_ID, a.ORIGIN, a.ORIGIN_CITY_NAME, a.ORIGIN_STATE_ABR,
         a.ORIGIN_STATE_FIPS, a.ORIGIN_STATE_NM, a.ORIGIN_WAC, a.DEST_AIRPORT_ID, a.DEST_AIRPORT_SEQ_ID,
         a.DEST_CITY_MARKET_ID, a.DEST, a.DEST_CITY_NAME, a.DEST_STATE_ABR, a.DEST_STATE_FIPS, a.DEST_STATE_NM, 
         a.DEST_WAC, a.CRS_DEP_TIME, a.DEP_TIME, a.DEP_DELAY, a.DEP_DELAY_NEW, a.DEP_DEL15, a.DEP_DELAY_GROUP,
         a.DEP_TIME_BLK, a.TAXI_OUT, a.WHEELS_OFF, a.WHEELS_ON, a.TAXI_IN, a.CRS_ARR_TIME, a.ARR_TIME,
         a.ARR_DELAY, a.ARR_DELAY_NEW, a.ARR_DEL15, a.ARR_DELAY_GROUP, a.ARR_TIME_BLK, a.CANCELLED, a.DIVERTED,
         a.CRS_ELAPSED_TIME, a.ACTUAL_ELAPSED_TIME, a.AIR_TIME, a.FLIGHTS, a.DISTANCE, a.DISTANCE_GROUP,
         a.DIV_AIRPORT_LANDINGS, a.ORIGIN_TZ, a.DEST_TZ, a.DEP_MIN, a.DEP_HOUR, a.ARR_MIN, a.ARR_HOUR, a.ORIGIN_TS,
         a.ORIGIN_UTC, a.DEST_TS, a.DEST_UTC, a.ORIGIN_FLIGHT_COUNT, a.DEST_FLIGHT_COUNT, a.ORIGIN_STATION, 
         a.ORIGIN_STATION_NAME, a.PAGERANK, a.DEST_STATION, a.DEST_STATION_NAME, a.ORIGIN_UTC_ADJ_MIN,
         a.ORIGIN_UTC_ADJ_MAX, a.ORIGIN_MAX_DATE, a.DEST_MAX_DATE
""")

display(data_2019)

# COMMAND ----------

data_2019.count()

# COMMAND ----------

data_2019.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

data_2019.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

data_2019.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

train_data = data.filter("Year != 2019")
display(train_data)
train_data.count()

# COMMAND ----------

data.registerTempTable('data')

# COMMAND ----------

train_data = spark.sql("""
SELECT *
FROM data
WHERE EXTRACT(YEAR FROM ORIGIN_UTC) < 2019
""")

display(train_data)
train_data.count()

# COMMAND ----------

train_data.select("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST").count()

# COMMAND ----------

display(train_data.groupBy("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST", "OP_CARRIER_FL_NUM").count().where("count > 1"))

# COMMAND ----------

display(train_data.filter("YEAR == 2015 AND MONTH == 10 AND DAY_OF_MONTH == 12 AND ORIGIN == 'DEN' AND TAIL_NUM == 'N13110' AND DEST =='IAH'"))

# COMMAND ----------

23900414 + 7270785

# COMMAND ----------

data.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/data_train_final", True)
train_data.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/data_train_final")

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/data_test_final", True)
data_2019.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/data_test_final")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Adding new feature columns

# COMMAND ----------

train = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_train_final")

display(train)

# COMMAND ----------

test = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_test_final")

display(test)

# COMMAND ----------

flightsPerDay = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/flights_per_day")

display(flightsPerDay)

# COMMAND ----------

train = train.drop(*["ORIGIN_FLIGHT_COUNT", "DEST_FLIGHT_COUNT"])
display(train)

# COMMAND ----------

train.select("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST").distinct().count()

# COMMAND ----------

test = test.drop(*["ORIGIN_FLIGHT_COUNT", "DEST_FLIGHT_COUNT"])
display(test)

# COMMAND ----------

train.registerTempTable('train')
test.registerTempTable('test')
flightsPerDay.registerTempTable('flightsPerDay')

# COMMAND ----------

train_flights = spark.sql("""
SELECT t.*, fo.flight_count as ORIGIN_FLIGHT_COUNT, fd.flight_count as DEST_FLIGHT_COUNT
FROM train as t
  LEFT JOIN flightsPerDay as fo
    ON t.ORIGIN == fo.IATA AND CAST(t.ORIGIN_UTC AS DATE) == fo.date
  LEFT JOIN flightsPerDay as fd
    ON t.DEST == fd.IATA AND CAST(t.DEST_UTC AS DATE) == fd.date
""")

display(train_flights)

# COMMAND ----------

train_flights.select("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST").distinct().count()

# COMMAND ----------

test_flights = spark.sql("""
SELECT t.*, fo.flight_count as ORIGIN_FLIGHT_COUNT, fd.flight_count as DEST_FLIGHT_COUNT
FROM test as t
  LEFT JOIN flightsPerDay as fo
    ON t.ORIGIN == fo.IATA AND CAST(t.ORIGIN_UTC AS DATE) == fo.date
  LEFT JOIN flightsPerDay as fd
    ON t.DEST == fd.IATA AND CAST(t.DEST_UTC AS DATE) == fd.date
""")

display(test_flights)

# COMMAND ----------

delays_so_far = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/delays_so_far")

display(delays_so_far)

# COMMAND ----------

train_flights.registerTempTable('train_flights')
test_flights.registerTempTable('test_flights')
delays_so_far.registerTempTable('delays_so_far')

# COMMAND ----------

train_final = spark.sql("""
SELECT t.*, fo.delays_so_far as DELAYS_SO_FAR
FROM train_flights as t
  LEFT JOIN delays_so_far as fo
    ON t.TAIL_NUM == fo.TAIL_NUM AND t.ORIGIN_UTC == fo.ORIGIN_UTC
""")

display(train_final)

# COMMAND ----------

train_final.count()

# COMMAND ----------

#Verifying if any issues arise here 
miss = train_final.where((col("DELAYS_SO_FAR").isNull()))
print(miss.count())
display(miss)

# COMMAND ----------

train_final = train_final.fillna(0, 'DELAYS_SO_FAR')
display(train_final)

# COMMAND ----------

test_final = spark.sql("""
SELECT t.*, fo.delays_so_far as DELAYS_SO_FAR
FROM test_flights as t
  LEFT JOIN delays_so_far as fo
    ON t.TAIL_NUM == fo.TAIL_NUM AND t.ORIGIN_UTC == fo.ORIGIN_UTC
""")

display(test_final)

# COMMAND ----------

test_final.count()

# COMMAND ----------

#Verifying if any issues arise here 
miss = test_final.where((col("DELAYS_SO_FAR").isNull()))
print(miss.count())
display(miss)

# COMMAND ----------

test_final = test_final.fillna(0, 'DELAYS_SO_FAR')
display(test_final)

# COMMAND ----------

avg_time_we = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airline/airlines_avg_time_west_east")

display(avg_time_we)
avg_time_we.count()

# COMMAND ----------

avg_time_we.select("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST").distinct().count()

# COMMAND ----------

display(avg_time_we.filter("YEAR == 2015 AND MONTH == 10 AND DAY_OF_MONTH == 12 AND ORIGIN == 'DEN' AND TAIL_NUM == 'N13110' AND DEST =='IAH'"))

# COMMAND ----------

train_final.select("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST").distinct().count()

# COMMAND ----------

train_final.registerTempTable('train_final')
test_final.registerTempTable('test_final')
avg_time_we.registerTempTable('avg_time_we')

# COMMAND ----------

train_final_new = spark.sql("""
SELECT t.*, awe.CRS_ELAPSED_TIME_AVG_DIFF, awe.WEST_TO_EAST
FROM train_final as t, avg_time_we as awe
WHERE t.ORIGIN == awe.ORIGIN AND t.TAIL_NUM == awe.TAIL_NUM AND t.ORIGIN_UTC == awe.ORIGIN_UTC AND t.DEST == awe.DEST AND t.OP_CARRIER_FL_NUM == awe.OP_CARRIER_FL_NUM
""")

display(train_final_new)
train_final_new.count()

# COMMAND ----------

train_final_new.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/train_final_pre_station_avg_imp")

# COMMAND ----------

test_final_new = spark.sql("""
SELECT t.*, awe.CRS_ELAPSED_TIME_AVG_DIFF, awe.WEST_TO_EAST
FROM test_final as t, avg_time_we as awe
WHERE t.ORIGIN == awe.ORIGIN AND t.TAIL_NUM == awe.TAIL_NUM AND t.ORIGIN_UTC == awe.ORIGIN_UTC AND t.DEST == awe.DEST AND t.OP_CARRIER_FL_NUM == awe.OP_CARRIER_FL_NUM
""")

display(test_final_new)
test_final_new.count()

# COMMAND ----------

test_final_new.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/test_final_pre_station_avg_imp")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Time Rank On Train

# COMMAND ----------

train_final_pre_station_avg_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/train_final_pre_station_avg_imp")

display(train_final_pre_station_avg_imp)
train_final_pre_station_avg_imp.count()

# COMMAND ----------

test_final_pre_station_avg_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/test_final_pre_station_avg_imp")

display(test_final_pre_station_avg_imp)
test_final_pre_station_avg_imp.count()

# COMMAND ----------

weather_imputed.registerTempTable('weather_imputed')

# COMMAND ----------

station_average_helper = spark.sql("""
SELECT STATION, avg(WND_SPEED) as AVG_WND_SPEED, avg(CIG_HEIGHT) as AVG_CIG_HEIGHT, min(CIG_HEIGHT) as MIN_CIG_HEIGHT,
       avg(VIS_DIS) as AVG_VIS_DIS, min(VIS_DIS) as MIN_VIS_DIS, avg(TMP_DEGREE) as AVG_TMP_DEG, avg(DEW_DEGREE) as AVG_DEW_DEG,
       avg(SLP_PRESSURE) as AVG_SLP
FROM weather_imputed
GROUP BY STATION
""")

display(station_average_helper)
station_average_helper.count()

# COMMAND ----------

station_average_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/station_average_helper")

# COMMAND ----------

station_average_helper = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/station_average_helper")

display(station_average_helper)
station_average_helper.count()

# COMMAND ----------

train_final_pre_station_avg_imp.registerTempTable('train_final_pre_station_avg_imp')
test_final_pre_station_avg_imp.registerTempTable('test_final_pre_station_avg_imp')
station_average_helper.registerTempTable('station_average_helper')

# COMMAND ----------

train_final_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC,
       t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.PAGERANK, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE,
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, coalesce(t.AVG_WND_SPEED_ORIGIN, saho.AVG_WND_SPEED) as AVG_WND_SPEED_ORIGIN, 
       coalesce(t.AVG_CIG_HEIGHT_ORIGIN, saho.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, coalesce(t.MIN_CIG_HEIGHT_ORIGIN, saho.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, 
       coalesce(t.AVG_VIS_DIS_ORIGIN, saho.AVG_VIS_DIS) as AVG_VIS_DIS_ORIGIN, coalesce(t.MIN_VIS_DIS_ORIGIN, saho.MIN_VIS_DIS) as MIN_VIS_DIS_ORIGIN, 
       coalesce(t.AVG_TMP_DEG_ORIGIN, saho.AVG_TMP_DEG) as AVG_TMP_DEG_ORIGIN, coalesce(t.AVG_DEW_DEG_ORIGIN, saho.AVG_DEW_DEG) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, saho.AVG_SLP) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, sahd.AVG_WND_SPEED) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, sahd.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, sahd.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, sahd.AVG_VIS_DIS) as AVG_VIS_DIS_DEST, coalesce(t.MIN_VIS_DIS_DEST, sahd.MIN_VIS_DIS) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, sahd.AVG_TMP_DEG) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, sahd.AVG_DEW_DEG) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, sahd.AVG_SLP) as AVG_SLP_DEST
FROM train_final_pre_station_avg_imp as t 
  LEFT JOIN station_average_helper as saho
    ON t.ORIGIN_STATION == saho.STATION
  LEFT JOIN station_average_helper as sahd
    ON t.DEST_STATION == sahd.STATION
""")

display(train_final_imp)
train_final_imp.count()

# COMMAND ----------

test_final_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC,
       t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.PAGERANK, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE,
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, coalesce(t.AVG_WND_SPEED_ORIGIN, saho.AVG_WND_SPEED) as AVG_WND_SPEED_ORIGIN, 
       coalesce(t.AVG_CIG_HEIGHT_ORIGIN, saho.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, coalesce(t.MIN_CIG_HEIGHT_ORIGIN, saho.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, 
       coalesce(t.AVG_VIS_DIS_ORIGIN, saho.AVG_VIS_DIS) as AVG_VIS_DIS_ORIGIN, coalesce(t.MIN_VIS_DIS_ORIGIN, saho.MIN_VIS_DIS) as MIN_VIS_DIS_ORIGIN, 
       coalesce(t.AVG_TMP_DEG_ORIGIN, saho.AVG_TMP_DEG) as AVG_TMP_DEG_ORIGIN, coalesce(t.AVG_DEW_DEG_ORIGIN, saho.AVG_DEW_DEG) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, saho.AVG_SLP) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, sahd.AVG_WND_SPEED) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, sahd.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, sahd.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, sahd.AVG_VIS_DIS) as AVG_VIS_DIS_DEST, coalesce(t.MIN_VIS_DIS_DEST, sahd.MIN_VIS_DIS) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, sahd.AVG_TMP_DEG) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, sahd.AVG_DEW_DEG) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, sahd.AVG_SLP) as AVG_SLP_DEST
FROM test_final_pre_station_avg_imp as t 
  LEFT JOIN station_average_helper as saho
    ON t.ORIGIN_STATION == saho.STATION
  LEFT JOIN station_average_helper as sahd
    ON t.DEST_STATION == sahd.STATION
""")

display(test_final_imp)
test_final_imp.count()

# COMMAND ----------

train_final_imp.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

train_final_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

train_final_imp.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

test_final_imp.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

test_final_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

test_final_imp.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Train/Validation/Test

# COMMAND ----------

train_final_imp.registerTempTable('train_final_imp')

# COMMAND ----------

train_15_to_17 = spark.sql("""
SELECT *
FROM train_final_imp
WHERE EXTRACT(YEAR FROM ORIGIN_UTC) < 2018
""")

display(train_15_to_17)
train_15_to_17.count()

# COMMAND ----------

train_18 = spark.sql("""
SELECT *
FROM train_final_imp
WHERE EXTRACT(YEAR FROM ORIGIN_UTC) == 2018
""")

display(train_18)
train_18.count()

# COMMAND ----------

16828952 + 7071462

# COMMAND ----------

train_15_to_17.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count() 

# COMMAND ----------

train_15_to_17.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

train_15_to_17.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

train_18.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

train_18.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

train_18.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

train_15_to_17.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train")

# COMMAND ----------

train_18.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation")

# COMMAND ----------

test_final_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test")

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets"))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Remove all nulls from each dataset

# COMMAND ----------

train_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train/")

display(train_data)
train_data.count()

# COMMAND ----------

display(train_data.select([count(when(col(c).isNull(), c)).alias(c) for c in train_data.columns]))

# COMMAND ----------

train_data_clean = train_data.na.drop(subset=["AVG_WND_SPEED_ORIGIN", "AVG_CIG_HEIGHT_ORIGIN", "MIN_CIG_HEIGHT_ORIGIN", "AVG_VIS_DIS_ORIGIN", "MIN_VIS_DIS_ORIGIN", "AVG_TMP_DEG_ORIGIN", "AVG_DEW_DEG_ORIGIN", "AVG_SLP_ORIGIN", "AVG_WND_SPEED_DEST", "AVG_CIG_HEIGHT_DEST", "MIN_CIG_HEIGHT_DEST", "AVG_VIS_DIS_DEST", "MIN_VIS_DIS_DEST", "AVG_TMP_DEG_DEST", "AVG_DEW_DEG_DEST", "AVG_SLP_DEST"])
display(train_data_clean)
train_data_clean.count()

# COMMAND ----------

train_data_clean.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

train_data_clean.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

train_data_clean.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

train_data_clean.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_clean")

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_clean", True)

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_cleaned", True)

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_final", True)

# COMMAND ----------

train_data_clean.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_clean")

# COMMAND ----------

validation_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation/")

display(validation_data)
validation_data.count()

# COMMAND ----------

validation_data_clean = validation_data.na.drop(subset=["AVG_WND_SPEED_ORIGIN", "AVG_CIG_HEIGHT_ORIGIN", "MIN_CIG_HEIGHT_ORIGIN", "AVG_VIS_DIS_ORIGIN", "MIN_VIS_DIS_ORIGIN", "AVG_TMP_DEG_ORIGIN", "AVG_DEW_DEG_ORIGIN", "AVG_SLP_ORIGIN", "AVG_WND_SPEED_DEST", "AVG_CIG_HEIGHT_DEST", "MIN_CIG_HEIGHT_DEST", "AVG_VIS_DIS_DEST", "MIN_VIS_DIS_DEST", "AVG_TMP_DEG_DEST", "AVG_DEW_DEG_DEST", "AVG_SLP_DEST"])
display(validation_data_clean)
validation_data_clean.count()

# COMMAND ----------

validation_data_clean.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

validation_data_clean.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

validation_data_clean.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

validation_data_clean.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation_clean")

# COMMAND ----------

test_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test/")

display(test_data)
test_data.count()

# COMMAND ----------

test_data_clean = test_data.na.drop(subset=["AVG_WND_SPEED_ORIGIN", "AVG_CIG_HEIGHT_ORIGIN", "MIN_CIG_HEIGHT_ORIGIN", "AVG_VIS_DIS_ORIGIN", "MIN_VIS_DIS_ORIGIN", "AVG_TMP_DEG_ORIGIN", "AVG_DEW_DEG_ORIGIN", "AVG_SLP_ORIGIN", "AVG_WND_SPEED_DEST", "AVG_CIG_HEIGHT_DEST", "MIN_CIG_HEIGHT_DEST", "AVG_VIS_DIS_DEST", "MIN_VIS_DIS_DEST", "AVG_TMP_DEG_DEST", "AVG_DEW_DEG_DEST", "AVG_SLP_DEST"])
display(test_data_clean)
test_data_clean.count()

# COMMAND ----------

test_data_clean.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

test_data_clean.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

test_data_clean.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

test_data_clean.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test_clean")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Creating minutes after midnight feature

# COMMAND ----------

train_clean = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_clean/")

display(train_clean)
train_clean.count()

# COMMAND ----------

train_clean.registerTempTable('train_clean')

# COMMAND ----------

train_times = spark.sql("""
SELECT train_clean.*, EXTRACT(HOUR FROM ORIGIN_UTC) * 60 + EXTRACT(MINUTE FROM ORIGIN_UTC) as MINUTES_AFTER_MIDNIGHT_ORIGIN, EXTRACT(HOUR FROM DEST_UTC) * 60 + EXTRACT(MINUTE FROM DEST_UTC) as MINUTES_AFTER_MIDNIGHT_DEST
FROM train_clean
""")

display(train_times)
train_times.count()

# COMMAND ----------

train_times.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_final")

# COMMAND ----------

validation_clean = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation_clean/")

display(validation_clean)
validation_clean.count()

# COMMAND ----------

validation_clean.registerTempTable('validation_clean')

# COMMAND ----------

validation_times = spark.sql("""
SELECT validation_clean.*, EXTRACT(HOUR FROM ORIGIN_UTC) * 60 + EXTRACT(MINUTE FROM ORIGIN_UTC) as MINUTES_AFTER_MIDNIGHT_ORIGIN, EXTRACT(HOUR FROM DEST_UTC) * 60 + EXTRACT(MINUTE FROM DEST_UTC) as MINUTES_AFTER_MIDNIGHT_DEST
FROM validation_clean
""")

display(validation_times)
validation_times.count()

# COMMAND ----------

validation_times.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation_final")

# COMMAND ----------

test_clean = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test_clean/")

display(test_clean)
test_clean.count()

# COMMAND ----------

test_clean.registerTempTable('test_clean')

# COMMAND ----------

test_times = spark.sql("""
SELECT test_clean.*, EXTRACT(HOUR FROM ORIGIN_UTC) * 60 + EXTRACT(MINUTE FROM ORIGIN_UTC) as MINUTES_AFTER_MIDNIGHT_ORIGIN, EXTRACT(HOUR FROM DEST_UTC) * 60 + EXTRACT(MINUTE FROM DEST_UTC) as MINUTES_AFTER_MIDNIGHT_DEST
FROM test_clean
""")

display(test_times)
test_times.count()

# COMMAND ----------

test_times.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/test_final")

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/mids-w261/team20SSDK/strategy/final_datasets"))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # More Feature Engineering
# MAGIC > Holiday Week
# MAGIC 
# MAGIC > Count Delays Per Origin Airport
# MAGIC 
# MAGIC > Average Delay Per Origin Airport
# MAGIC 
# MAGIC > Departure Hour Bins
# MAGIC 
# MAGIC > Add MINUTES_AFTER_MIDNIGHT To Test Data + Above Features
# MAGIC 
# MAGIC > Impute Test Data Via MLLib Imputer (Column Impute)

# COMMAND ----------

train_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train_final")

display(train_final)
train_final.count()

# COMMAND ----------

holiday_week_beg = ['2014-12-26', '2015-01-16', '2015-05-22', '2015-07-02', '2015-09-04', '2015-11-06', '2015-11-20', '2015-12-18', '2015-12-31', '2016-01-15', '2016-05-27', '2016-07-01',
                    '2016-09-02', '2016-11-10', '2016-11-18', '2016-12-23', '2017-01-13', '2017-05-26', '2017-06-30', '2017-09-01', '2017-11-03', '2017-11-17', '2017-12-22',
                    '2018-01-12', '2018-05-25', '2018-06-29', '2018-08-31', '2018-11-09', '2018-11-30', '2018-12-21', '2019-01-18', '2019-05-24',
                    '2019-06-28', '2019-08-30', '2019-11-08', '2019-11-22', '2019-12-20']

holiday_week_end = ['2015-01-04', '2015-01-25', '2015-05-31', '2015-07-05', '2015-09-13', '2015-11-15', '2015-11-29', '2015-12-27', '2016-01-03', '2016-01-24', '2016-06-05', '2016-07-10',
                    '2016-09-11', '2016-11-13', '2016-11-27', '2017-01-08', '2017-01-22', '2017-06-04', '2017-07-09', '2017-09-10', '2017-11-12', '2017-11-26', '2018-01-07', 
                    '2018-01-21', '2018-06-03', '2018-07-08', '2018-09-09', '2018-11-25', '2018-12-09', '2019-01-06', '2019-01-27', '2019-06-02',
                    '2019-07-07', '2019-09-08', '2019-11-17', '2019-12-01', '2019-12-31']

holiday_week_beg_end = sqlContext.createDataFrame(zip(holiday_week_beg, holiday_week_end), schema=['HOLIDAY_WEEK_BEGIN', 'HOLIDAY_WEEK_END'])
display(holiday_week_beg_end)

# COMMAND ----------

train_final.registerTempTable('train_final')
holiday_week_beg_end.registerTempTable('holiday_week_beg_end')

# COMMAND ----------

holiday_week_beg_end = spark.sql("""
SELECT CAST(HOLIDAY_WEEK_BEGIN as TIMESTAMP) as HOLIDAY_WEEK_BEGIN, CAST(HOLIDAY_WEEK_END as TIMESTAMP) + INTERVAL 24 HOURS as HOLIDAY_WEEK_END
FROM holiday_week_beg_end
""")

display(holiday_week_beg_end)

# COMMAND ----------

holiday_week_beg_end.registerTempTable('holiday_week_beg_end')

# COMMAND ----------

train_holiday_week = spark.sql("""
SELECT t.*, CASE WHEN hw.HOLIDAY_WEEK_BEGIN is not null THEN 1 ELSE 0 END as HOLIDAY_WEEK
FROM train_final as t
  LEFT JOIN holiday_week_beg_end as hw
    ON t.ORIGIN_UTC BETWEEN hw.HOLIDAY_WEEK_BEGIN AND hw.HOLIDAY_WEEK_END
""")

display(train_holiday_week)
train_holiday_week.count()

# COMMAND ----------

train_holiday_week = train_holiday_week.withColumn("BEG_OF_DAY", f.date_trunc("day", "ORIGIN_UTC"))
display(train_holiday_week)

# COMMAND ----------

train_holiday_week.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/train_holiday_week")

# COMMAND ----------

train_holiday = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/train_holiday_week")

display(train_holiday)
train_holiday.count()

# COMMAND ----------

train_holiday.registerTempTable('train_holiday')

# COMMAND ----------

train_holiday_week.registerTempTable('train_holiday_week')

# COMMAND ----------

train_dep_bins = spark.sql("""
SELECT train_holiday_week.*, CASE WHEN DEP_HOUR < 6 THEN 0
                             WHEN DEP_HOUR >= 6 AND DEP_HOUR <= 9 THEN 1
                             WHEN DEP_HOUR >= 10 AND DEP_HOUR <= 14 THEN 2
                             WHEN DEP_HOUR >= 15 AND DEP_HOUR <= 20 THEN 3
                             WHEN DEP_HOUR > 20 THEN 4 
                             END AS DEP_HOUR_BIN
FROM train_holiday_week
""")

display(train_dep_bins)
train_dep_bins.count()

# COMMAND ----------

train_dep_bins.registerTempTable('train_dep_bins')

train_arr_bins = spark.sql("""
SELECT train_dep_bins.*, CASE WHEN ARR_HOUR < 6 THEN 0
                             WHEN ARR_HOUR >= 6 AND ARR_HOUR <= 9 THEN 1
                             WHEN ARR_HOUR >= 10 AND ARR_HOUR <= 14 THEN 2
                             WHEN ARR_HOUR >= 15 AND ARR_HOUR <= 20 THEN 3
                             WHEN ARR_HOUR > 20 THEN 4 
                             END AS ARR_HOUR_BIN
FROM train_dep_bins
""")

display(train_arr_bins)
train_arr_bins.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/final_datasets/train", True)

# COMMAND ----------

train_arr_bins.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/final_datasets/train")

# COMMAND ----------

validation_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation_final")

display(validation_final)
validation_final.count()

# COMMAND ----------

validation_final.registerTempTable('validation_final')

# COMMAND ----------

validation_holiday_week = spark.sql("""
SELECT t.*, CASE WHEN hw.HOLIDAY_WEEK_BEGIN is not null THEN 1 ELSE 0 END as HOLIDAY_WEEK
FROM validation_final as t
  LEFT JOIN holiday_week_beg_end as hw
    ON t.ORIGIN_UTC BETWEEN hw.HOLIDAY_WEEK_BEGIN AND hw.HOLIDAY_WEEK_END
""")

display(validation_holiday_week)
validation_holiday_week.count()

# COMMAND ----------

validation_holiday_week.registerTempTable('validation_holiday_week')

# COMMAND ----------

validation_dep_bins = spark.sql("""
SELECT validation_holiday_week.*, CASE WHEN DEP_HOUR < 6 THEN 0
                             WHEN DEP_HOUR >= 6 AND DEP_HOUR <= 9 THEN 1
                             WHEN DEP_HOUR >= 10 AND DEP_HOUR <= 14 THEN 2
                             WHEN DEP_HOUR >= 15 AND DEP_HOUR <= 20 THEN 3
                             WHEN DEP_HOUR > 20 THEN 4 
                             END AS DEP_HOUR_BIN
FROM validation_holiday_week
""")

display(validation_dep_bins)
validation_dep_bins.count()

# COMMAND ----------

validation_dep_bins.registerTempTable('validation_dep_bins')

validation_arr_bins = spark.sql("""
SELECT validation_dep_bins.*, CASE WHEN ARR_HOUR < 6 THEN 0
                             WHEN ARR_HOUR >= 6 AND ARR_HOUR <= 9 THEN 1
                             WHEN ARR_HOUR >= 10 AND ARR_HOUR <= 14 THEN 2
                             WHEN ARR_HOUR >= 15 AND ARR_HOUR <= 20 THEN 3
                             WHEN ARR_HOUR > 20 THEN 4 
                             END AS ARR_HOUR_BIN
FROM validation_dep_bins
""")

display(validation_arr_bins)
validation_arr_bins.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/final_datasets/validation", True)

# COMMAND ----------

validation_arr_bins.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/final_datasets/validation")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Scratch work for Incoming Delays

# COMMAND ----------

train_incoming_delay_helper = spark.sql("""
SELECT t.DEST as AIRPORT, t.DEST_UTC as ARRIVAL_TIME, t.ARR_DEL15, t.ARR_DELAY
FROM train_holiday_week as t
""")

display(train_incoming_delay_helper)
train_incoming_delay_helper.count()

# COMMAND ----------

train_incoming_delay_helper.registerTempTable('train_incoming_delay_helper')

train_incoming_delay = spark.sql("""
SELECT t1.*, sum(t2.ARR_DEL15) as CNT_INCOMING_DELAYS, avg(t2.ARR_DELAY) as AVG_INCOMING_DELAY
FROM train_holiday_week as t1
LEFT JOIN train_incoming_delay_helper as t2
  ON t2.AIRPORT == t1.ORIGIN AND t2.ARRIVAL_TIME BETWEEN t1.BEG_OF_DAY AND t1.ORIGIN_UTC_ADJ_MAX
GROUP BY t1.YEAR, t1.QUARTER, t1.MONTH, t1.DAY_OF_MONTH, t1.DAY_OF_WEEK, t1.FL_DATE, t1.OP_UNIQUE_CARRIER,
         t1.OP_CARRIER_AIRLINE_ID, t1.OP_CARRIER, t1.TAIL_NUM, t1.OP_CARRIER_FL_NUM, t1.ORIGIN_AIRPORT_ID, 
         t1.ORIGIN_AIRPORT_SEQ_ID, t1.ORIGIN_CITY_MARKET_ID, t1.ORIGIN, t1.ORIGIN_CITY_NAME, t1.ORIGIN_STATE_ABR,
         t1.ORIGIN_STATE_FIPS, t1.ORIGIN_STATE_NM, t1.ORIGIN_WAC, t1.DEST_AIRPORT_ID, t1.DEST_AIRPORT_SEQ_ID,
         t1.DEST_CITY_MARKET_ID, t1.DEST, t1.DEST_CITY_NAME, t1.DEST_STATE_ABR, t1.DEST_STATE_FIPS, t1.DEST_STATE_NM, 
         t1.DEST_WAC, t1.CRS_DEP_TIME, t1.DEP_TIME, t1.DEP_DELAY, t1.DEP_DELAY_NEW, t1.DEP_DEL15, t1.DEP_DELAY_GROUP,
         t1.DEP_TIME_BLK, t1.TAXI_OUT, t1.WHEELS_OFF, t1.WHEELS_ON, t1.TAXI_IN, t1.CRS_ARR_TIME, t1.ARR_TIME,
         t1.ARR_DELAY, t1.ARR_DELAY_NEW, t1.ARR_DEL15, t1.ARR_DELAY_GROUP, t1.ARR_TIME_BLK, t1.CANCELLED, t1.DIVERTED,
         t1.CRS_ELAPSED_TIME, t1.ACTUAL_ELAPSED_TIME, t1.AIR_TIME, t1.FLIGHTS, t1.DISTANCE, t1.DISTANCE_GROUP,
         t1.DIV_AIRPORT_LANDINGS, t1.ORIGIN_TZ, t1.DEST_TZ, t1.DEP_MIN, t1.DEP_HOUR, t1.ARR_MIN, t1.ARR_HOUR, t1.ORIGIN_TS,
         t1.ORIGIN_UTC, t1.DEST_TS, t1.DEST_UTC, t1.ORIGIN_FLIGHT_COUNT, t1.DEST_FLIGHT_COUNT, t1.ORIGIN_STATION, 
         t1.ORIGIN_STATION_NAME, t1.PAGERANK, t1.DEST_STATION, t1.DEST_STATION_NAME, t1.ORIGIN_UTC_ADJ_MIN,
         t1.ORIGIN_UTC_ADJ_MAX, t1.ORIGIN_MAX_DATE, t1.DEST_MAX_DATE, t1.DELAYS_SO_FAR, t1.CRS_ELAPSED_TIME_AVG_DIFF,
         t1.WEST_TO_EAST, t1.AVG_WND_SPEED_ORIGIN, t1.AVG_CIG_HEIGHT_ORIGIN, t1.MIN_CIG_HEIGHT_ORIGIN, t1.AVG_VIS_DIS_ORIGIN,
         t1.MIN_VIS_DIS_ORIGIN, t1.AVG_TMP_DEG_ORIGIN, t1.AVG_DEW_DEG_ORIGIN, t1.AVG_SLP_ORIGIN, t1.AVG_WND_SPEED_DEST,
         t1.AVG_CIG_HEIGHT_DEST, t1.MIN_CIG_HEIGHT_DEST, t1.AVG_VIS_DIS_DEST, t1.MIN_VIS_DIS_DEST, t1.AVG_TMP_DEG_DEST,
         t1.AVG_DEW_DEG_DEST, t1.AVG_SLP_DEST, t1.MINUTES_AFTER_MIDNIGHT_ORIGIN, t1.MINUTES_AFTER_MIDNIGHT_DEST,
         t1.HOLIDAY_WEEK, t1.BEG_OF_DAY
""")

display(train_incoming_delay)
train_incoming_delay.count()

# COMMAND ----------

train_incoming_delay = spark.sql("""
SELECT t1.*, coalesce(sum(t2.ARR_DEL15), 0) as CNT_INCOMING_DELAYS, coalesce(avg(t2.ARR_DELAY),0) as AVG_INCOMING_DELAY
FROM train_holiday as t1
LEFT JOIN train_holiday as t2
  ON t2.DEST == t1.ORIGIN AND t2.DEST_UTC BETWEEN t1.BEG_OF_DAY AND t1.ORIGIN_UTC_ADJ_MAX
GROUP BY t1.YEAR, t1.QUARTER, t1.MONTH, t1.DAY_OF_MONTH, t1.DAY_OF_WEEK, t1.FL_DATE, t1.OP_UNIQUE_CARRIER,
         t1.OP_CARRIER_AIRLINE_ID, t1.OP_CARRIER, t1.TAIL_NUM, t1.OP_CARRIER_FL_NUM, t1.ORIGIN_AIRPORT_ID, 
         t1.ORIGIN_AIRPORT_SEQ_ID, t1.ORIGIN_CITY_MARKET_ID, t1.ORIGIN, t1.ORIGIN_CITY_NAME, t1.ORIGIN_STATE_ABR,
         t1.ORIGIN_STATE_FIPS, t1.ORIGIN_STATE_NM, t1.ORIGIN_WAC, t1.DEST_AIRPORT_ID, t1.DEST_AIRPORT_SEQ_ID,
         t1.DEST_CITY_MARKET_ID, t1.DEST, t1.DEST_CITY_NAME, t1.DEST_STATE_ABR, t1.DEST_STATE_FIPS, t1.DEST_STATE_NM, 
         t1.DEST_WAC, t1.CRS_DEP_TIME, t1.DEP_TIME, t1.DEP_DELAY, t1.DEP_DELAY_NEW, t1.DEP_DEL15, t1.DEP_DELAY_GROUP,
         t1.DEP_TIME_BLK, t1.TAXI_OUT, t1.WHEELS_OFF, t1.WHEELS_ON, t1.TAXI_IN, t1.CRS_ARR_TIME, t1.ARR_TIME,
         t1.ARR_DELAY, t1.ARR_DELAY_NEW, t1.ARR_DEL15, t1.ARR_DELAY_GROUP, t1.ARR_TIME_BLK, t1.CANCELLED, t1.DIVERTED,
         t1.CRS_ELAPSED_TIME, t1.ACTUAL_ELAPSED_TIME, t1.AIR_TIME, t1.FLIGHTS, t1.DISTANCE, t1.DISTANCE_GROUP,
         t1.DIV_AIRPORT_LANDINGS, t1.ORIGIN_TZ, t1.DEST_TZ, t1.DEP_MIN, t1.DEP_HOUR, t1.ARR_MIN, t1.ARR_HOUR, t1.ORIGIN_TS,
         t1.ORIGIN_UTC, t1.DEST_TS, t1.DEST_UTC, t1.ORIGIN_FLIGHT_COUNT, t1.DEST_FLIGHT_COUNT, t1.ORIGIN_STATION, 
         t1.ORIGIN_STATION_NAME, t1.PAGERANK, t1.DEST_STATION, t1.DEST_STATION_NAME, t1.ORIGIN_UTC_ADJ_MIN,
         t1.ORIGIN_UTC_ADJ_MAX, t1.ORIGIN_MAX_DATE, t1.DEST_MAX_DATE, t1.DELAYS_SO_FAR, t1.CRS_ELAPSED_TIME_AVG_DIFF,
         t1.WEST_TO_EAST, t1.AVG_WND_SPEED_ORIGIN, t1.AVG_CIG_HEIGHT_ORIGIN, t1.MIN_CIG_HEIGHT_ORIGIN, t1.AVG_VIS_DIS_ORIGIN,
         t1.MIN_VIS_DIS_ORIGIN, t1.AVG_TMP_DEG_ORIGIN, t1.AVG_DEW_DEG_ORIGIN, t1.AVG_SLP_ORIGIN, t1.AVG_WND_SPEED_DEST,
         t1.AVG_CIG_HEIGHT_DEST, t1.MIN_CIG_HEIGHT_DEST, t1.AVG_VIS_DIS_DEST, t1.MIN_VIS_DIS_DEST, t1.AVG_TMP_DEG_DEST,
         t1.AVG_DEW_DEG_DEST, t1.AVG_SLP_DEST, t1.MINUTES_AFTER_MIDNIGHT_ORIGIN, t1.MINUTES_AFTER_MIDNIGHT_DEST,
         t1.HOLIDAY_WEEK, t1.BEG_OF_DAY
""")

display(train_incoming_delay)
train_incoming_delay.count()

# COMMAND ----------

train_incoming_delay = spark.sql("""
SELECT t1.*, coalesce(sum(t2.ARR_DEL15), 0) as CNT_INCOMING_DELAYS, coalesce(avg(t2.ARR_DELAY),0) as AVG_INCOMING_DELAY
FROM train_holiday as t1
LEFT JOIN train_holiday as t2
  ON t2.DEST == t1.ORIGIN AND t2.DEST_UTC BETWEEN t1.BEG_OF_DAY AND t1.ORIGIN_UTC_ADJ_MAX
WHERE t2.ARR_DEL15 == 1
GROUP BY t1.YEAR, t1.QUARTER, t1.MONTH, t1.DAY_OF_MONTH, t1.DAY_OF_WEEK, t1.FL_DATE, t1.OP_UNIQUE_CARRIER,
         t1.OP_CARRIER_AIRLINE_ID, t1.OP_CARRIER, t1.TAIL_NUM, t1.OP_CARRIER_FL_NUM, t1.ORIGIN_AIRPORT_ID, 
         t1.ORIGIN_AIRPORT_SEQ_ID, t1.ORIGIN_CITY_MARKET_ID, t1.ORIGIN, t1.ORIGIN_CITY_NAME, t1.ORIGIN_STATE_ABR,
         t1.ORIGIN_STATE_FIPS, t1.ORIGIN_STATE_NM, t1.ORIGIN_WAC, t1.DEST_AIRPORT_ID, t1.DEST_AIRPORT_SEQ_ID,
         t1.DEST_CITY_MARKET_ID, t1.DEST, t1.DEST_CITY_NAME, t1.DEST_STATE_ABR, t1.DEST_STATE_FIPS, t1.DEST_STATE_NM, 
         t1.DEST_WAC, t1.CRS_DEP_TIME, t1.DEP_TIME, t1.DEP_DELAY, t1.DEP_DELAY_NEW, t1.DEP_DEL15, t1.DEP_DELAY_GROUP,
         t1.DEP_TIME_BLK, t1.TAXI_OUT, t1.WHEELS_OFF, t1.WHEELS_ON, t1.TAXI_IN, t1.CRS_ARR_TIME, t1.ARR_TIME,
         t1.ARR_DELAY, t1.ARR_DELAY_NEW, t1.ARR_DEL15, t1.ARR_DELAY_GROUP, t1.ARR_TIME_BLK, t1.CANCELLED, t1.DIVERTED,
         t1.CRS_ELAPSED_TIME, t1.ACTUAL_ELAPSED_TIME, t1.AIR_TIME, t1.FLIGHTS, t1.DISTANCE, t1.DISTANCE_GROUP,
         t1.DIV_AIRPORT_LANDINGS, t1.ORIGIN_TZ, t1.DEST_TZ, t1.DEP_MIN, t1.DEP_HOUR, t1.ARR_MIN, t1.ARR_HOUR, t1.ORIGIN_TS,
         t1.ORIGIN_UTC, t1.DEST_TS, t1.DEST_UTC, t1.ORIGIN_FLIGHT_COUNT, t1.DEST_FLIGHT_COUNT, t1.ORIGIN_STATION, 
         t1.ORIGIN_STATION_NAME, t1.PAGERANK, t1.DEST_STATION, t1.DEST_STATION_NAME, t1.ORIGIN_UTC_ADJ_MIN,
         t1.ORIGIN_UTC_ADJ_MAX, t1.ORIGIN_MAX_DATE, t1.DEST_MAX_DATE, t1.DELAYS_SO_FAR, t1.CRS_ELAPSED_TIME_AVG_DIFF,
         t1.WEST_TO_EAST, t1.AVG_WND_SPEED_ORIGIN, t1.AVG_CIG_HEIGHT_ORIGIN, t1.MIN_CIG_HEIGHT_ORIGIN, t1.AVG_VIS_DIS_ORIGIN,
         t1.MIN_VIS_DIS_ORIGIN, t1.AVG_TMP_DEG_ORIGIN, t1.AVG_DEW_DEG_ORIGIN, t1.AVG_SLP_ORIGIN, t1.AVG_WND_SPEED_DEST,
         t1.AVG_CIG_HEIGHT_DEST, t1.MIN_CIG_HEIGHT_DEST, t1.AVG_VIS_DIS_DEST, t1.MIN_VIS_DIS_DEST, t1.AVG_TMP_DEG_DEST,
         t1.AVG_DEW_DEG_DEST, t1.AVG_SLP_DEST, t1.MINUTES_AFTER_MIDNIGHT_ORIGIN, t1.MINUTES_AFTER_MIDNIGHT_DEST,
         t1.HOLIDAY_WEEK, t1.BEG_OF_DAY
""")

display(train_incoming_delay)
train_incoming_delay.count()

# COMMAND ----------

train_incoming_delay.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/train_incoming_delay_debug")

# COMMAND ----------

train_holiday.filter("ARR_DEL15 == 1").count()

# COMMAND ----------

train_incoming_del = spark.sql("""
SELECT t1.*, coalesce(sum(t2.ARR_DEL15), 0) as CNT_INCOMING_DELAYS, coalesce(avg(t2.ARR_DELAY),0) as AVG_INCOMING_DELAY
FROM train_holiday as t1
LEFT JOIN (SELECT * FROM train_holiday WHERE ARR_DEL15 == 1) as t2
  ON t2.DEST == t1.ORIGIN AND t2.DEST_UTC BETWEEN t1.BEG_OF_DAY AND t1.ORIGIN_UTC_ADJ_MAX
GROUP BY t1.YEAR, t1.QUARTER, t1.MONTH, t1.DAY_OF_MONTH, t1.DAY_OF_WEEK, t1.FL_DATE, t1.OP_UNIQUE_CARRIER,
         t1.OP_CARRIER_AIRLINE_ID, t1.OP_CARRIER, t1.TAIL_NUM, t1.OP_CARRIER_FL_NUM, t1.ORIGIN_AIRPORT_ID, 
         t1.ORIGIN_AIRPORT_SEQ_ID, t1.ORIGIN_CITY_MARKET_ID, t1.ORIGIN, t1.ORIGIN_CITY_NAME, t1.ORIGIN_STATE_ABR,
         t1.ORIGIN_STATE_FIPS, t1.ORIGIN_STATE_NM, t1.ORIGIN_WAC, t1.DEST_AIRPORT_ID, t1.DEST_AIRPORT_SEQ_ID,
         t1.DEST_CITY_MARKET_ID, t1.DEST, t1.DEST_CITY_NAME, t1.DEST_STATE_ABR, t1.DEST_STATE_FIPS, t1.DEST_STATE_NM, 
         t1.DEST_WAC, t1.CRS_DEP_TIME, t1.DEP_TIME, t1.DEP_DELAY, t1.DEP_DELAY_NEW, t1.DEP_DEL15, t1.DEP_DELAY_GROUP,
         t1.DEP_TIME_BLK, t1.TAXI_OUT, t1.WHEELS_OFF, t1.WHEELS_ON, t1.TAXI_IN, t1.CRS_ARR_TIME, t1.ARR_TIME,
         t1.ARR_DELAY, t1.ARR_DELAY_NEW, t1.ARR_DEL15, t1.ARR_DELAY_GROUP, t1.ARR_TIME_BLK, t1.CANCELLED, t1.DIVERTED,
         t1.CRS_ELAPSED_TIME, t1.ACTUAL_ELAPSED_TIME, t1.AIR_TIME, t1.FLIGHTS, t1.DISTANCE, t1.DISTANCE_GROUP,
         t1.DIV_AIRPORT_LANDINGS, t1.ORIGIN_TZ, t1.DEST_TZ, t1.DEP_MIN, t1.DEP_HOUR, t1.ARR_MIN, t1.ARR_HOUR, t1.ORIGIN_TS,
         t1.ORIGIN_UTC, t1.DEST_TS, t1.DEST_UTC, t1.ORIGIN_FLIGHT_COUNT, t1.DEST_FLIGHT_COUNT, t1.ORIGIN_STATION, 
         t1.ORIGIN_STATION_NAME, t1.PAGERANK, t1.DEST_STATION, t1.DEST_STATION_NAME, t1.ORIGIN_UTC_ADJ_MIN,
         t1.ORIGIN_UTC_ADJ_MAX, t1.ORIGIN_MAX_DATE, t1.DEST_MAX_DATE, t1.DELAYS_SO_FAR, t1.CRS_ELAPSED_TIME_AVG_DIFF,
         t1.WEST_TO_EAST, t1.AVG_WND_SPEED_ORIGIN, t1.AVG_CIG_HEIGHT_ORIGIN, t1.MIN_CIG_HEIGHT_ORIGIN, t1.AVG_VIS_DIS_ORIGIN,
         t1.MIN_VIS_DIS_ORIGIN, t1.AVG_TMP_DEG_ORIGIN, t1.AVG_DEW_DEG_ORIGIN, t1.AVG_SLP_ORIGIN, t1.AVG_WND_SPEED_DEST,
         t1.AVG_CIG_HEIGHT_DEST, t1.MIN_CIG_HEIGHT_DEST, t1.AVG_VIS_DIS_DEST, t1.MIN_VIS_DIS_DEST, t1.AVG_TMP_DEG_DEST,
         t1.AVG_DEW_DEG_DEST, t1.AVG_SLP_DEST, t1.MINUTES_AFTER_MIDNIGHT_ORIGIN, t1.MINUTES_AFTER_MIDNIGHT_DEST,
         t1.HOLIDAY_WEEK, t1.BEG_OF_DAY
""")

display(train_incoming_del)
train_incoming_del.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Figuring out optimal query for incoming delays

# COMMAND ----------

train_set = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/final_datasets/train/")

display(train_set)
train_set.count()

# COMMAND ----------

train_set = train_set.withColumn("BEG_OF_DAY", f.date_trunc("day", "ORIGIN_UTC"))
display(train_set)

# COMMAND ----------

train_set.registerTempTable('train_set')

# COMMAND ----------

train_set_delays = train_set.filter("ARR_DEL15 == 1")
train_set_delays.count()

# COMMAND ----------

train_set_delays.registerTempTable('train_set_delays')

# COMMAND ----------

train_incoming_delay = spark.sql("""
SELECT t1.*, coalesce(t2.ARR_DEL15, 0) as INCOMING_DELAY, coalesce(t2.ARR_DELAY, 0) as INCOMING_DELAY_MINUTES
FROM train_set as t1
LEFT JOIN train_set_delays as t2
  ON t2.DEST == t1.ORIGIN AND t2.DEST_UTC BETWEEN t1.BEG_OF_DAY AND t1.ORIGIN_UTC_ADJ_MAX
""")

display(train_incoming_delay)

# COMMAND ----------

train_incoming_delay.count()

# COMMAND ----------

train_incoming_delay = spark.sql("""
SELECT t1.*, coalesce(sum(t2.ARR_DEL15), 0) as CNT_INCOMING_DELAYS, coalesce(avg(t2.ARR_DELAY),0) as AVG_INCOMING_DELAY
FROM train_holiday as t1
LEFT JOIN train_set_delays as t2
  ON t2.DEST == t1.ORIGIN AND t2.DEST_UTC BETWEEN t1.BEG_OF_DAY AND t1.ORIGIN_UTC_ADJ_MAX
GROUP BY t1.YEAR, t1.QUARTER, t1.MONTH, t1.DAY_OF_MONTH, t1.DAY_OF_WEEK, t1.FL_DATE, t1.OP_UNIQUE_CARRIER,
         t1.OP_CARRIER_AIRLINE_ID, t1.OP_CARRIER, t1.TAIL_NUM, t1.OP_CARRIER_FL_NUM, t1.ORIGIN_AIRPORT_ID, 
         t1.ORIGIN_AIRPORT_SEQ_ID, t1.ORIGIN_CITY_MARKET_ID, t1.ORIGIN, t1.ORIGIN_CITY_NAME, t1.ORIGIN_STATE_ABR,
         t1.ORIGIN_STATE_FIPS, t1.ORIGIN_STATE_NM, t1.ORIGIN_WAC, t1.DEST_AIRPORT_ID, t1.DEST_AIRPORT_SEQ_ID,
         t1.DEST_CITY_MARKET_ID, t1.DEST, t1.DEST_CITY_NAME, t1.DEST_STATE_ABR, t1.DEST_STATE_FIPS, t1.DEST_STATE_NM, 
         t1.DEST_WAC, t1.CRS_DEP_TIME, t1.DEP_TIME, t1.DEP_DELAY, t1.DEP_DELAY_NEW, t1.DEP_DEL15, t1.DEP_DELAY_GROUP,
         t1.DEP_TIME_BLK, t1.TAXI_OUT, t1.WHEELS_OFF, t1.WHEELS_ON, t1.TAXI_IN, t1.CRS_ARR_TIME, t1.ARR_TIME,
         t1.ARR_DELAY, t1.ARR_DELAY_NEW, t1.ARR_DEL15, t1.ARR_DELAY_GROUP, t1.ARR_TIME_BLK, t1.CANCELLED, t1.DIVERTED,
         t1.CRS_ELAPSED_TIME, t1.ACTUAL_ELAPSED_TIME, t1.AIR_TIME, t1.FLIGHTS, t1.DISTANCE, t1.DISTANCE_GROUP,
         t1.DIV_AIRPORT_LANDINGS, t1.ORIGIN_TZ, t1.DEST_TZ, t1.DEP_MIN, t1.DEP_HOUR, t1.ARR_MIN, t1.ARR_HOUR, t1.ORIGIN_TS,
         t1.ORIGIN_UTC, t1.DEST_TS, t1.DEST_UTC, t1.ORIGIN_FLIGHT_COUNT, t1.DEST_FLIGHT_COUNT, t1.ORIGIN_STATION, 
         t1.ORIGIN_STATION_NAME, t1.PAGERANK, t1.DEST_STATION, t1.DEST_STATION_NAME, t1.ORIGIN_UTC_ADJ_MIN,
         t1.ORIGIN_UTC_ADJ_MAX, t1.ORIGIN_MAX_DATE, t1.DEST_MAX_DATE, t1.DELAYS_SO_FAR, t1.CRS_ELAPSED_TIME_AVG_DIFF,
         t1.WEST_TO_EAST, t1.AVG_WND_SPEED_ORIGIN, t1.AVG_CIG_HEIGHT_ORIGIN, t1.MIN_CIG_HEIGHT_ORIGIN, t1.AVG_VIS_DIS_ORIGIN,
         t1.MIN_VIS_DIS_ORIGIN, t1.AVG_TMP_DEG_ORIGIN, t1.AVG_DEW_DEG_ORIGIN, t1.AVG_SLP_ORIGIN, t1.AVG_WND_SPEED_DEST,
         t1.AVG_CIG_HEIGHT_DEST, t1.MIN_CIG_HEIGHT_DEST, t1.AVG_VIS_DIS_DEST, t1.MIN_VIS_DIS_DEST, t1.AVG_TMP_DEG_DEST,
         t1.AVG_DEW_DEG_DEST, t1.AVG_SLP_DEST, t1.MINUTES_AFTER_MIDNIGHT_ORIGIN, t1.MINUTES_AFTER_MIDNIGHT_DEST,
         t1.HOLIDAY_WEEK, t1.BEG_OF_DAY
""")

display(train_incoming_delay)

# COMMAND ----------

train_incoming_delay.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/train_incoming_delay_testing")

# COMMAND ----------

train_inc_del_testing = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/train_incoming_delay_testing")

display(train_inc_del_testing)
train_inc_del_testing.count()
