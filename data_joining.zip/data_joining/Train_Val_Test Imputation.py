# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext, Window
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr, count, when
import numpy as np

import pandas as pd, matplotlib.pyplot as plt
import matplotlib.cm as cm, matplotlib.font_manager as fm
from datetime import datetime as dt

sqlContext = SQLContext(sc)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Load Imputed Data Tables

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final")

display(data)
data.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Drop 2019 Data

# COMMAND ----------

data.registerTempTable('data')

data_15_to_18 = spark.sql("""
SELECT *
FROM data
WHERE EXTRACT(YEAR FROM ORIGIN_UTC) < 2019
""")

display(data_15_to_18)
data_15_to_18.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Load 2019 Data (Corrected To Include Weather Observations From The Full Length Of The Year)

# COMMAND ----------

data_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final_19")

display(data_19)
data_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Feature Engineering

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### ORIGIN_FLIGHT_COUNT, DEST_FLIGHT_COUNT

# COMMAND ----------

data_15_to_18 = data_15_to_18.drop(*["ORIGIN_FLIGHT_COUNT", "DEST_FLIGHT_COUNT"])
display(data_15_to_18)

# COMMAND ----------

data_19 = data_19.drop(*["ORIGIN_FLIGHT_COUNT", "DEST_FLIGHT_COUNT"])
display(data_19)

# COMMAND ----------

flightsPerDay = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/flights_per_day")

display(flightsPerDay)

# COMMAND ----------

data_15_to_18.registerTempTable('data_15_to_18')
data_19.registerTempTable('data_19')
flightsPerDay.registerTempTable('flightsPerDay')

# COMMAND ----------

data_flights_15_to_18 = spark.sql("""
SELECT t.*, fo.flight_count as ORIGIN_FLIGHT_COUNT, fd.flight_count as DEST_FLIGHT_COUNT
FROM data_15_to_18 as t
  LEFT JOIN flightsPerDay as fo
    ON t.ORIGIN == fo.IATA AND CAST(t.ORIGIN_UTC AS DATE) == fo.date
  LEFT JOIN flightsPerDay as fd
    ON t.DEST == fd.IATA AND CAST(t.DEST_UTC AS DATE) == fd.date
""")

display(data_flights_15_to_18)

# COMMAND ----------

data_flights_19 = spark.sql("""
SELECT t.*, fo.flight_count as ORIGIN_FLIGHT_COUNT, fd.flight_count as DEST_FLIGHT_COUNT
FROM data_19 as t
  LEFT JOIN flightsPerDay as fo
    ON t.ORIGIN == fo.IATA AND CAST(t.ORIGIN_UTC AS DATE) == fo.date
  LEFT JOIN flightsPerDay as fd
    ON t.DEST == fd.IATA AND CAST(t.DEST_UTC AS DATE) == fd.date
""")

display(data_flights_19)

# COMMAND ----------

data_flights_15_to_18.select("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST", "OP_CARRIER_FL_NUM").distinct().count()

# COMMAND ----------

data_flights_19.select("ORIGIN_UTC", "ORIGIN", "TAIL_NUM", "DEST", "OP_CARRIER_FL_NUM").distinct().count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### DELAYS_SO_FAR

# COMMAND ----------

delays_so_far = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/delays_so_far")

display(delays_so_far)

# COMMAND ----------

data_flights_15_to_18.registerTempTable('data_flights_15_to_18')
data_flights_19.registerTempTable('data_flights_19')
delays_so_far.registerTempTable('delays_so_far')

# COMMAND ----------

data_dels_so_far_15_to_18 = spark.sql("""
SELECT t.*, fo.delays_so_far as DELAYS_SO_FAR
FROM data_flights_15_to_18 as t
  LEFT JOIN delays_so_far as fo
    ON t.TAIL_NUM == fo.TAIL_NUM AND t.ORIGIN_UTC == fo.ORIGIN_UTC
""")

display(data_dels_so_far_15_to_18)
data_dels_so_far_15_to_18.count()

# COMMAND ----------

data_dels_so_far_19 = spark.sql("""
SELECT t.*, fo.delays_so_far as DELAYS_SO_FAR
FROM data_flights_19 as t
  LEFT JOIN delays_so_far as fo
    ON t.TAIL_NUM == fo.TAIL_NUM AND t.ORIGIN_UTC == fo.ORIGIN_UTC
""")

display(data_dels_so_far_19)
data_dels_so_far_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### WEST_TO_EAST, CRS_ELAPSED_TIME_AVG_DIFF

# COMMAND ----------

avg_time_west_east = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airline/airlines_avg_time_west_east")

display(avg_time_west_east)
avg_time_west_east.count()

# COMMAND ----------

data_dels_so_far_15_to_18.registerTempTable('data_dels_so_far_15_to_18')
data_dels_so_far_19.registerTempTable('data_dels_so_far_19')
avg_time_west_east.registerTempTable('avg_time_west_east')

# COMMAND ----------

data_avg_time_we_15_to_18 = spark.sql("""
SELECT t.*, awe.CRS_ELAPSED_TIME_AVG_DIFF, awe.WEST_TO_EAST
FROM data_dels_so_far_15_to_18 as t, avg_time_west_east as awe
WHERE t.ORIGIN == awe.ORIGIN AND t.TAIL_NUM == awe.TAIL_NUM AND t.ORIGIN_UTC == awe.ORIGIN_UTC AND t.DEST == awe.DEST AND t.OP_CARRIER_FL_NUM == awe.OP_CARRIER_FL_NUM
""")

display(data_avg_time_we_15_to_18)
data_avg_time_we_15_to_18.count()

# COMMAND ----------

data_avg_time_we_19 = spark.sql("""
SELECT t.*, awe.CRS_ELAPSED_TIME_AVG_DIFF, awe.WEST_TO_EAST
FROM data_dels_so_far_19 as t, avg_time_west_east as awe
WHERE t.ORIGIN == awe.ORIGIN AND t.TAIL_NUM == awe.TAIL_NUM AND t.ORIGIN_UTC == awe.ORIGIN_UTC AND t.DEST == awe.DEST AND t.OP_CARRIER_FL_NUM == awe.OP_CARRIER_FL_NUM
""")

display(data_avg_time_we_19)
data_avg_time_we_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### MINUTES_AFTER_MIDNIGHT_ORIGIN, MINUTES_AFTER_MIDNIGHT_DEST

# COMMAND ----------

data_avg_time_we_15_to_18.registerTempTable('data_avg_time_we_15_to_18')
data_avg_time_we_19.registerTempTable('data_avg_time_we_19')

# COMMAND ----------

data_mam_15_to_18 = spark.sql("""
SELECT data_avg_time_we_15_to_18.*, EXTRACT(HOUR FROM ORIGIN_UTC) * 60 + EXTRACT(MINUTE FROM ORIGIN_UTC) as MINUTES_AFTER_MIDNIGHT_ORIGIN, EXTRACT(HOUR FROM DEST_UTC) * 60 + EXTRACT(MINUTE FROM DEST_UTC) as MINUTES_AFTER_MIDNIGHT_DEST
FROM data_avg_time_we_15_to_18
""")

display(data_mam_15_to_18)
data_mam_15_to_18.count()

# COMMAND ----------

data_mam_19 = spark.sql("""
SELECT data_avg_time_we_19.*, EXTRACT(HOUR FROM ORIGIN_UTC) * 60 + EXTRACT(MINUTE FROM ORIGIN_UTC) as MINUTES_AFTER_MIDNIGHT_ORIGIN, EXTRACT(HOUR FROM DEST_UTC) * 60 + EXTRACT(MINUTE FROM DEST_UTC) as MINUTES_AFTER_MIDNIGHT_DEST
FROM data_avg_time_we_19
""")

display(data_mam_19)
data_mam_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### HOLIDAY_WEEK

# COMMAND ----------

data_mam_15_to_18.registerTempTable('data_mam_15_to_18')
data_mam_19.registerTempTable('data_mam_19')

# COMMAND ----------

holiday_week_beg_end = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/holiday_week_beg_end")

display(holiday_week_beg_end)

# COMMAND ----------

holiday_week_beg_end.registerTempTable('holiday_week_beg_end')

data_holiday_week_15_to_18 = spark.sql("""
SELECT t.*, CASE WHEN hw.HOLIDAY_WEEK_BEGIN is not null THEN 1 ELSE 0 END as HOLIDAY_WEEK
FROM data_mam_15_to_18 as t
  LEFT JOIN holiday_week_beg_end as hw
    ON t.ORIGIN_UTC BETWEEN hw.HOLIDAY_WEEK_BEGIN AND hw.HOLIDAY_WEEK_END
""")

display(data_holiday_week_15_to_18)
data_holiday_week_15_to_18.count()

# COMMAND ----------

data_holiday_week_19 = spark.sql("""
SELECT t.*, CASE WHEN hw.HOLIDAY_WEEK_BEGIN is not null THEN 1 ELSE 0 END as HOLIDAY_WEEK
FROM data_mam_19 as t
  LEFT JOIN holiday_week_beg_end as hw
    ON t.ORIGIN_UTC BETWEEN hw.HOLIDAY_WEEK_BEGIN AND hw.HOLIDAY_WEEK_END
""")

display(data_holiday_week_19)
data_holiday_week_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### DEP_HOUR_BIN, ARR_HOUR_BIN

# COMMAND ----------

data_holiday_week_15_to_18.registerTempTable('data_holiday_week_15_to_18')
data_holiday_week_19.registerTempTable('data_holiday_week_19')

# COMMAND ----------

data_dep_bins_15_to_18 = spark.sql("""
SELECT data_holiday_week_15_to_18.*, CASE WHEN DEP_HOUR < 6 THEN 0
                             WHEN DEP_HOUR >= 6 AND DEP_HOUR <= 9 THEN 1
                             WHEN DEP_HOUR >= 10 AND DEP_HOUR <= 14 THEN 2
                             WHEN DEP_HOUR >= 15 AND DEP_HOUR <= 20 THEN 3
                             WHEN DEP_HOUR > 20 THEN 4 
                             END AS DEP_HOUR_BIN
FROM data_holiday_week_15_to_18
""")

display(data_dep_bins_15_to_18)
data_dep_bins_15_to_18.count()

# COMMAND ----------

data_dep_bins_15_to_18.registerTempTable('data_dep_bins_15_to_18')

data_arr_bins_15_to_18 = spark.sql("""
SELECT data_dep_bins_15_to_18.*, CASE WHEN ARR_HOUR < 6 THEN 0
                             WHEN ARR_HOUR >= 6 AND ARR_HOUR <= 9 THEN 1
                             WHEN ARR_HOUR >= 10 AND ARR_HOUR <= 14 THEN 2
                             WHEN ARR_HOUR >= 15 AND ARR_HOUR <= 20 THEN 3
                             WHEN ARR_HOUR > 20 THEN 4 
                             END AS ARR_HOUR_BIN
FROM data_dep_bins_15_to_18
""")

display(data_arr_bins_15_to_18)
data_arr_bins_15_to_18.count()

# COMMAND ----------

data_dep_bins_19 = spark.sql("""
SELECT data_holiday_week_19.*, CASE WHEN DEP_HOUR < 6 THEN 0
                             WHEN DEP_HOUR >= 6 AND DEP_HOUR <= 9 THEN 1
                             WHEN DEP_HOUR >= 10 AND DEP_HOUR <= 14 THEN 2
                             WHEN DEP_HOUR >= 15 AND DEP_HOUR <= 20 THEN 3
                             WHEN DEP_HOUR > 20 THEN 4 
                             END AS DEP_HOUR_BIN
FROM data_holiday_week_19
""")

display(data_dep_bins_19)
data_dep_bins_19.count()

# COMMAND ----------

data_dep_bins_19.registerTempTable('data_dep_bins_19')

data_arr_bins_19 = spark.sql("""
SELECT data_dep_bins_19.*, CASE WHEN ARR_HOUR < 6 THEN 0
                             WHEN ARR_HOUR >= 6 AND ARR_HOUR <= 9 THEN 1
                             WHEN ARR_HOUR >= 10 AND ARR_HOUR <= 14 THEN 2
                             WHEN ARR_HOUR >= 15 AND ARR_HOUR <= 20 THEN 3
                             WHEN ARR_HOUR > 20 THEN 4 
                             END AS ARR_HOUR_BIN
FROM data_dep_bins_19
""")

display(data_arr_bins_19)
data_arr_bins_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### NETWORK_CONGESTION

# COMMAND ----------

network_congestion_train = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/train")

display(network_congestion_train)
network_congestion_train.count()

# COMMAND ----------

network_congestion_train.select("ORIGIN_UTC_ADJ_MAX").distinct().count()

# COMMAND ----------

network_congestion_validation = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/validation")

display(network_congestion_validation)
network_congestion_validation.count()

# COMMAND ----------

network_congestion_validation.select("ORIGIN_UTC_ADJ_MAX").distinct().count()

# COMMAND ----------

network_congestion_test = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/data/airline/network_congestion/test")

display(network_congestion_test)
network_congestion_test.count()

# COMMAND ----------

network_congestion_test.select("ORIGIN_UTC_ADJ_MAX").distinct().count()

# COMMAND ----------

network_congestion_train.registerTempTable('network_congestion_train')
network_congestion_validation.registerTempTable('network_congestion_validation')
network_congestion_test.registerTempTable('network_congestion_test')

network_congestion_all = spark.sql("""
SELECT ORIGIN_UTC_ADJ_MAX, sum(NETWORK_CONGESTION) as NETWORK_CONGESTION FROM network_congestion_train 
  GROUP BY ORIGIN_UTC_ADJ_MAX
UNION ALL
SELECT ORIGIN_UTC_ADJ_MAX, sum(NETWORK_CONGESTION) as NETWORK_CONGESTION FROM network_congestion_validation 
  GROUP BY ORIGIN_UTC_ADJ_MAX
UNION ALL
SELECT ORIGIN_UTC_ADJ_MAX, sum(NETWORK_CONGESTION) as NETWORK_CONGESTION FROM network_congestion_test 
  GROUP BY ORIGIN_UTC_ADJ_MAX
""")

display(network_congestion_all)
network_congestion_all.count()

# COMMAND ----------

data_arr_bins_15_to_18.registerTempTable('data_arr_bins_15_to_18')
network_congestion_all.registerTempTable('network_congestion_all')

data_nc_15_to_18 = spark.sql("""
SELECT dab.*, nca.NETWORK_CONGESTION
FROM data_arr_bins_15_to_18 as dab, network_congestion_all as nca
WHERE dab.ORIGIN_UTC_ADJ_MAX == nca.ORIGIN_UTC_ADJ_MAX
""")

display(data_nc_15_to_18)
data_nc_15_to_18.count()

# COMMAND ----------

data_arr_bins_19.registerTempTable('data_arr_bins_19')

data_nc_19 = spark.sql("""
SELECT dab.*, nca.NETWORK_CONGESTION
FROM data_arr_bins_19 as dab, network_congestion_all as nca
WHERE dab.ORIGIN_UTC_ADJ_MAX == nca.ORIGIN_UTC_ADJ_MAX
""")

display(data_nc_19)
data_nc_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### ORIGIN_PR, DEST_PR

# COMMAND ----------

airport_meta = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta")

display(airport_meta)
airport_meta.count()

# COMMAND ----------

data_pr_origin_15_to_18 = data_nc_15_to_18.join(airport_meta.alias('AM'), data_nc_15_to_18.ORIGIN == col('AM.IATA')).select(*data_nc_15_to_18, col('AM.pagerank').alias('ORIGIN_PR'))

display(data_pr_origin_15_to_18)
data_pr_origin_15_to_18.count()

# COMMAND ----------

data_pr_dest_15_to_18 = data_pr_origin_15_to_18.join(airport_meta.alias('AM'), data_pr_origin_15_to_18.DEST == col('AM.IATA')).select(*data_pr_origin_15_to_18, col('AM.pagerank').alias('DEST_PR'))

display(data_pr_dest_15_to_18)
data_pr_dest_15_to_18.count()

# COMMAND ----------

data_pr_origin_19 = data_nc_19.join(airport_meta.alias('AM'), data_nc_19.ORIGIN == col('AM.IATA')).select(*data_nc_19, col('AM.pagerank').alias('ORIGIN_PR'))

display(data_pr_origin_19)
data_pr_origin_19.count()

# COMMAND ----------

data_pr_dest_19 = data_pr_origin_19.join(airport_meta.alias('AM'), data_pr_origin_19.DEST == col('AM.IATA')).select(*data_pr_origin_19, col('AM.pagerank').alias('DEST_PR'))

display(data_pr_dest_19)
data_pr_dest_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ###### Drop Old PAGERANK Column

# COMMAND ----------

data_pr_dest_15_to_18 = data_pr_dest_15_to_18.drop(*["PAGERANK"])

display(data_pr_dest_15_to_18)
data_pr_dest_15_to_18.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### IS_MORNING_FLIGHT, IS_EVENING_FLIGHT

# COMMAND ----------

data_pr_dest_15_to_18.registerTempTable('data_pr_dest_15_to_18')
data_pr_dest_19.registerTempTable('data_pr_dest_19')

# COMMAND ----------

data_morning_15_to_18 = spark.sql("""
SELECT data_pr_dest_15_to_18.*, CASE WHEN DEP_HOUR_BIN == 1 THEN 1 ELSE 0 END AS IS_MORNING_FLIGHT
FROM data_pr_dest_15_to_18
""")

display(data_morning_15_to_18)
data_morning_15_to_18.count()

# COMMAND ----------

data_morning_15_to_18.registerTempTable('data_morning_15_to_18')

data_evening_15_to_18 = spark.sql("""
SELECT data_morning_15_to_18.*, CASE WHEN DEP_HOUR_BIN == 3 THEN 1 ELSE 0 END AS IS_EVENING_FLIGHT
FROM data_morning_15_to_18
""")

display(data_evening_15_to_18)
data_evening_15_to_18.count()

# COMMAND ----------

data_morning_19 = spark.sql("""
SELECT data_pr_dest_19.*, CASE WHEN DEP_HOUR_BIN == 1 THEN 1 ELSE 0 END AS IS_MORNING_FLIGHT
FROM data_pr_dest_19
""")

display(data_morning_19)
data_morning_19.count()

# COMMAND ----------

data_morning_19.registerTempTable('data_morning_19')

data_evening_19 = spark.sql("""
SELECT data_morning_19.*, CASE WHEN DEP_HOUR_BIN == 3 THEN 1 ELSE 0 END AS IS_EVENING_FLIGHT
FROM data_morning_19
""")

display(data_evening_19)
data_evening_19.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Write table to DBFS

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/mids-w261/team20SSDK/project_data"))

# COMMAND ----------

data_evening_15_to_18.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/project_data/data_15_to_18")

# COMMAND ----------

data_evening_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/project_data/data_19")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Splitting The Data

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ###### Next Steps
# MAGIC 
# MAGIC Train Data
# MAGIC - Split data into Train, Validation, and Test
# MAGIC - Create station_average_metrics table with only train data
# MAGIC - Impute train data with the above average metrics
# MAGIC - If some metric cells are still null, perform column imputation on train data and save metric averages
# MAGIC 
# MAGIC Validation Data
# MAGIC - Replace all weather metric columns with raw data
# MAGIC - Use train average metrics grouped by station to impute nulls
# MAGIC - Use overall train metric averages to perform column imputation
# MAGIC 
# MAGIC Test Data
# MAGIC - Use train average metrics grouped by station to impute nulls
# MAGIC - Use overall train metric averages to perform column imputation

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Weather Imputation

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Load Weather Imputed Table

# COMMAND ----------

weather_imputed = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_imputed")

display(weather_imputed)
weather_imputed.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Split Weather Imputed Table To Use 2015-2017 Data

# COMMAND ----------

weather_imputed.registerTempTable('weather_imputed')

train_weather_imputed = spark.sql("""
SELECT *
FROM weather_imputed
WHERE YEAR < 2018
""")

display(train_weather_imputed)
train_weather_imputed.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Create Helper Table For Average Metrics Grouped By Stations Using Train Data

# COMMAND ----------

train_weather_imputed.registerTempTable('train_weather_imputed')

station_average_helper = spark.sql("""
SELECT STATION, avg(WND_SPEED) as AVG_WND_SPEED, avg(CIG_HEIGHT) as AVG_CIG_HEIGHT, min(CIG_HEIGHT) as MIN_CIG_HEIGHT,
       avg(VIS_DIS) as AVG_VIS_DIS, min(VIS_DIS) as MIN_VIS_DIS, avg(TMP_DEGREE) as AVG_TMP_DEG, avg(DEW_DEGREE) as AVG_DEW_DEG,
       avg(SLP_PRESSURE) as AVG_SLP
FROM train_weather_imputed
GROUP BY STATION
""")

display(station_average_helper)
station_average_helper.count()

# COMMAND ----------

station_average_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/project_data/helpers/station_average_helper")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Load Data

# COMMAND ----------

data_15_to_18 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/data_15_to_18")

display(data_15_to_18)
data_15_to_18.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### TRAIN

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Filter Table To Just Use Training Data Years (2015 - 2017)

# COMMAND ----------

data_15_to_18.registerTempTable('data_15_to_18')

train_data = spark.sql("""
SELECT *
FROM data_15_to_18
WHERE EXTRACT(YEAR FROM ORIGIN_UTC) < 2018
""")

display(train_data)
train_data.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Impute Weather Nulls With Station Average Helper Table

# COMMAND ----------

train_data.registerTempTable('train_data')
station_average_helper.registerTempTable('station_average_helper')

train_avg_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT,
       coalesce(t.AVG_WND_SPEED_ORIGIN, saho.AVG_WND_SPEED) as AVG_WND_SPEED_ORIGIN, coalesce(t.AVG_CIG_HEIGHT_ORIGIN, saho.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, 
       coalesce(t.MIN_CIG_HEIGHT_ORIGIN, saho.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, coalesce(t.AVG_VIS_DIS_ORIGIN, saho.AVG_VIS_DIS) as AVG_VIS_DIS_ORIGIN, 
       coalesce(t.MIN_VIS_DIS_ORIGIN, saho.MIN_VIS_DIS) as MIN_VIS_DIS_ORIGIN, coalesce(t.AVG_TMP_DEG_ORIGIN, saho.AVG_TMP_DEG) as AVG_TMP_DEG_ORIGIN, 
       coalesce(t.AVG_DEW_DEG_ORIGIN, saho.AVG_DEW_DEG) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, saho.AVG_SLP) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, sahd.AVG_WND_SPEED) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, sahd.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, sahd.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, sahd.AVG_VIS_DIS) as AVG_VIS_DIS_DEST, coalesce(t.MIN_VIS_DIS_DEST, sahd.MIN_VIS_DIS) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, sahd.AVG_TMP_DEG) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, sahd.AVG_DEW_DEG) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, sahd.AVG_SLP) as AVG_SLP_DEST
FROM train_data as t 
  LEFT JOIN station_average_helper as saho
    ON t.ORIGIN_STATION == saho.STATION
  LEFT JOIN station_average_helper as sahd
    ON t.DEST_STATION == sahd.STATION
""")

display(train_avg_imp)
train_avg_imp.count()

# COMMAND ----------

train_avg_imp.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

train_avg_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

train_avg_imp.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Create Helper Table To Store Train Weather Metrics Averages

# COMMAND ----------

train_avg_imp.registerTempTable('train_avg_imp')

train_averages = spark.sql("""
SELECT avg(AVG_WND_SPEED_ORIGIN) as AVG_WND_SPEED_ORIGIN, avg(AVG_CIG_HEIGHT_ORIGIN) as AVG_CIG_HEIGHT_ORIGIN, avg(MIN_CIG_HEIGHT_ORIGIN) as MIN_CIG_HEIGHT_ORIGIN, avg(AVG_VIS_DIS_ORIGIN) as AVG_VIS_DIS_ORIGIN,
       avg(MIN_VIS_DIS_ORIGIN) as MIN_VIS_DIS_ORIGIN, avg(AVG_TMP_DEG_ORIGIN) as AVG_TMP_DEG_ORIGIN, avg(AVG_DEW_DEG_ORIGIN) as AVG_DEW_DEG_ORIGIN, avg(AVG_SLP_ORIGIN) as AVG_SLP_ORIGIN, 
       avg(AVG_WND_SPEED_DEST) as AVG_WND_SPEED_DEST, avg(AVG_CIG_HEIGHT_DEST) as AVG_CIG_HEIGHT_DEST, avg(MIN_CIG_HEIGHT_DEST) as MIN_CIG_HEIGHT_DEST, avg(AVG_VIS_DIS_DEST) as AVG_VIS_DIS_DEST, 
       avg(MIN_VIS_DIS_DEST) as MIN_VIS_DIS_DEST, avg(AVG_TMP_DEG_DEST) as AVG_TMP_DEG_DEST, avg(AVG_DEW_DEG_DEST) as AVG_DEW_DEG_DEST, avg(AVG_SLP_DEST) as AVG_SLP_DEST
FROM train_avg_imp
""")

display(train_averages)

# COMMAND ----------

train_averages.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/project_data/helpers/train_averages")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Perform Column Imputation On Train Data Using Above Helper Table

# COMMAND ----------

train_averages.registerTempTable('train_averages')

train_column_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT,
       coalesce(t.AVG_WND_SPEED_ORIGIN, ta.AVG_WND_SPEED_ORIGIN) as AVG_WND_SPEED_ORIGIN, coalesce(t.AVG_CIG_HEIGHT_ORIGIN, ta.AVG_CIG_HEIGHT_ORIGIN) as AVG_CIG_HEIGHT_ORIGIN, 
       coalesce(t.MIN_CIG_HEIGHT_ORIGIN, ta.MIN_CIG_HEIGHT_ORIGIN) as MIN_CIG_HEIGHT_ORIGIN, coalesce(t.AVG_VIS_DIS_ORIGIN, ta.AVG_VIS_DIS_ORIGIN) as AVG_VIS_DIS_ORIGIN, 
       coalesce(t.MIN_VIS_DIS_ORIGIN, ta.MIN_VIS_DIS_ORIGIN) as MIN_VIS_DIS_ORIGIN, coalesce(t.AVG_TMP_DEG_ORIGIN, ta.AVG_TMP_DEG_ORIGIN) as AVG_TMP_DEG_ORIGIN, 
       coalesce(t.AVG_DEW_DEG_ORIGIN, ta.AVG_DEW_DEG_ORIGIN) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, ta.AVG_SLP_ORIGIN) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, ta.AVG_WND_SPEED_DEST) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, ta.AVG_CIG_HEIGHT_DEST) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, ta.MIN_CIG_HEIGHT_DEST) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, ta.AVG_VIS_DIS_DEST) as AVG_VIS_DIS_DEST, 
       coalesce(t.MIN_VIS_DIS_DEST, ta.MIN_VIS_DIS_DEST) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, ta.AVG_TMP_DEG_DEST) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, ta.AVG_DEW_DEG_DEST) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, ta.AVG_SLP_DEST) as AVG_SLP_DEST
FROM train_avg_imp as t, train_averages as ta
""")

display(train_column_imp)
train_column_imp.count()

# COMMAND ----------

train_column_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Write Train Data To DBFS

# COMMAND ----------

train_column_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/project_data/train")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Validation

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Filter Full Dataset To Create Validation Data

# COMMAND ----------

validation_data = spark.sql("""
SELECT *
FROM data_15_to_18
WHERE EXTRACT(YEAR FROM ORIGIN_UTC) == 2018
""")

display(validation_data)
validation_data.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Replace Validation (2018) Data Weather Metrics With Imputed Weather Data (Based On Station Nearest Neighbors)

# COMMAND ----------

validation_weather_imputed = spark.sql("""
SELECT *
FROM weather_imputed
WHERE YEAR == 2018
""")

display(validation_weather_imputed)
validation_weather_imputed.count()

# COMMAND ----------

validation_data.registerTempTable('validation_data')
validation_weather_imputed.registerTempTable('validation_weather_imputed')

validation_data = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT, avg(wmo.WND_SPEED) as AVG_WND_SPEED_ORIGIN, avg(wmo.CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, 
       min(wmo.CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, avg(wmo.VIS_DIS) as AVG_VIS_DIS_ORIGIN, 
       min(wmo.VIS_DIS) as MIN_VIS_DIS_ORIGIN, avg(wmo.TMP_DEGREE) as AVG_TMP_DEG_ORIGIN,   
       avg(wmo.DEW_DEGREE) as AVG_DEW_DEG_ORIGIN, avg(wmo.SLP_PRESSURE) as AVG_SLP_ORIGIN, 
       avg(wmd.WND_SPEED) as AVG_WND_SPEED_DEST, avg(wmd.CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       min(wmd.CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, avg(wmd.VIS_DIS) as AVG_VIS_DIS_DEST, 
       min(wmd.VIS_DIS) as MIN_VIS_DIS_DEST, avg(wmd.TMP_DEGREE) as AVG_TMP_DEG_DEST, 
       avg(wmd.DEW_DEGREE) as AVG_DEW_DEG_DEST, avg(wmd.SLP_PRESSURE) as AVG_SLP_DEST
FROM validation_data as t
  LEFT JOIN validation_weather_imputed as wmo 
    ON t.ORIGIN_STATION == wmo.STATION AND wmo.DATE == t.ORIGIN_MAX_DATE
  LEFT JOIN validation_weather_imputed as wmd 
    ON t.DEST_STATION == wmd.STATION AND wmd.DATE == t.DEST_MAX_DATE
WHERE EXTRACT(YEAR FROM t.ORIGIN_UTC) == 2018
GROUP BY t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT
""")

display(validation_data)
validation_data.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Impute Validation Weather Metrics Using Station Average Helper Table (Created From Train Data)

# COMMAND ----------

validation_data.registerTempTable('validation_data')

validation_avg_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT,
       coalesce(t.AVG_WND_SPEED_ORIGIN, saho.AVG_WND_SPEED) as AVG_WND_SPEED_ORIGIN, coalesce(t.AVG_CIG_HEIGHT_ORIGIN, saho.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, 
       coalesce(t.MIN_CIG_HEIGHT_ORIGIN, saho.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, coalesce(t.AVG_VIS_DIS_ORIGIN, saho.AVG_VIS_DIS) as AVG_VIS_DIS_ORIGIN, 
       coalesce(t.MIN_VIS_DIS_ORIGIN, saho.MIN_VIS_DIS) as MIN_VIS_DIS_ORIGIN, coalesce(t.AVG_TMP_DEG_ORIGIN, saho.AVG_TMP_DEG) as AVG_TMP_DEG_ORIGIN, 
       coalesce(t.AVG_DEW_DEG_ORIGIN, saho.AVG_DEW_DEG) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, saho.AVG_SLP) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, sahd.AVG_WND_SPEED) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, sahd.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, sahd.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, sahd.AVG_VIS_DIS) as AVG_VIS_DIS_DEST, coalesce(t.MIN_VIS_DIS_DEST, sahd.MIN_VIS_DIS) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, sahd.AVG_TMP_DEG) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, sahd.AVG_DEW_DEG) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, sahd.AVG_SLP) as AVG_SLP_DEST
FROM validation_data as t 
  LEFT JOIN station_average_helper as saho
    ON t.ORIGIN_STATION == saho.STATION
  LEFT JOIN station_average_helper as sahd
    ON t.DEST_STATION == sahd.STATION
""")

display(validation_avg_imp)
validation_avg_imp.count()

# COMMAND ----------

validation_avg_imp.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

validation_avg_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

validation_avg_imp.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Perform Column Imputation On Validation Data Using Train Averages Helper Table

# COMMAND ----------

validation_avg_imp.registerTempTable('validation_avg_imp')

validation_column_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT,
       coalesce(t.AVG_WND_SPEED_ORIGIN, ta.AVG_WND_SPEED_ORIGIN) as AVG_WND_SPEED_ORIGIN, coalesce(t.AVG_CIG_HEIGHT_ORIGIN, ta.AVG_CIG_HEIGHT_ORIGIN) as AVG_CIG_HEIGHT_ORIGIN, 
       coalesce(t.MIN_CIG_HEIGHT_ORIGIN, ta.MIN_CIG_HEIGHT_ORIGIN) as MIN_CIG_HEIGHT_ORIGIN, coalesce(t.AVG_VIS_DIS_ORIGIN, ta.AVG_VIS_DIS_ORIGIN) as AVG_VIS_DIS_ORIGIN, 
       coalesce(t.MIN_VIS_DIS_ORIGIN, ta.MIN_VIS_DIS_ORIGIN) as MIN_VIS_DIS_ORIGIN, coalesce(t.AVG_TMP_DEG_ORIGIN, ta.AVG_TMP_DEG_ORIGIN) as AVG_TMP_DEG_ORIGIN, 
       coalesce(t.AVG_DEW_DEG_ORIGIN, ta.AVG_DEW_DEG_ORIGIN) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, ta.AVG_SLP_ORIGIN) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, ta.AVG_WND_SPEED_DEST) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, ta.AVG_CIG_HEIGHT_DEST) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, ta.MIN_CIG_HEIGHT_DEST) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, ta.AVG_VIS_DIS_DEST) as AVG_VIS_DIS_DEST, 
       coalesce(t.MIN_VIS_DIS_DEST, ta.MIN_VIS_DIS_DEST) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, ta.AVG_TMP_DEG_DEST) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, ta.AVG_DEW_DEG_DEST) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, ta.AVG_SLP_DEST) as AVG_SLP_DEST
FROM validation_avg_imp as t, train_averages as ta
""")

display(validation_column_imp)
validation_column_imp.count()

# COMMAND ----------

validation_column_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Write Validation Data To DBFS

# COMMAND ----------

validation_column_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/project_data/validation")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Test

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Load Test Data (2019)

# COMMAND ----------

test_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/data_19")

display(test_data)
test_data.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Impute Test Weather Metrics Using Station Average Helper Table (Created From Train Data)

# COMMAND ----------

test_data.registerTempTable('test_data')

test_avg_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT,
       coalesce(t.AVG_WND_SPEED_ORIGIN, saho.AVG_WND_SPEED) as AVG_WND_SPEED_ORIGIN, coalesce(t.AVG_CIG_HEIGHT_ORIGIN, saho.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, 
       coalesce(t.MIN_CIG_HEIGHT_ORIGIN, saho.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, coalesce(t.AVG_VIS_DIS_ORIGIN, saho.AVG_VIS_DIS) as AVG_VIS_DIS_ORIGIN, 
       coalesce(t.MIN_VIS_DIS_ORIGIN, saho.MIN_VIS_DIS) as MIN_VIS_DIS_ORIGIN, coalesce(t.AVG_TMP_DEG_ORIGIN, saho.AVG_TMP_DEG) as AVG_TMP_DEG_ORIGIN, 
       coalesce(t.AVG_DEW_DEG_ORIGIN, saho.AVG_DEW_DEG) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, saho.AVG_SLP) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, sahd.AVG_WND_SPEED) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, sahd.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, sahd.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, sahd.AVG_VIS_DIS) as AVG_VIS_DIS_DEST, coalesce(t.MIN_VIS_DIS_DEST, sahd.MIN_VIS_DIS) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, sahd.AVG_TMP_DEG) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, sahd.AVG_DEW_DEG) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, sahd.AVG_SLP) as AVG_SLP_DEST
FROM test_data as t 
  LEFT JOIN station_average_helper as saho
    ON t.ORIGIN_STATION == saho.STATION
  LEFT JOIN station_average_helper as sahd
    ON t.DEST_STATION == sahd.STATION
""")

display(test_avg_imp)
test_avg_imp.count()

# COMMAND ----------

test_avg_imp.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

test_avg_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

test_avg_imp.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Perform Column Imputation On Test Data Using Train Averages Helper Table

# COMMAND ----------

train_averages.registerTempTable('train_averages')

# COMMAND ----------

test_avg_imp.registerTempTable('test_avg_imp')

test_column_imp = spark.sql("""
SELECT t.YEAR, t.QUARTER, t.MONTH, t.DAY_OF_MONTH, t.DAY_OF_WEEK, t.FL_DATE, t.OP_UNIQUE_CARRIER, t.OP_CARRIER_AIRLINE_ID, t.OP_CARRIER, t.TAIL_NUM, t.OP_CARRIER_FL_NUM, t.ORIGIN_AIRPORT_ID, t.ORIGIN_AIRPORT_SEQ_ID,
       t.ORIGIN_CITY_MARKET_ID, t.ORIGIN, t.ORIGIN_CITY_NAME, t.ORIGIN_STATE_ABR, t.ORIGIN_STATE_FIPS, t.ORIGIN_STATE_NM, t.ORIGIN_WAC, t.DEST_AIRPORT_ID, t.DEST_AIRPORT_SEQ_ID, t.DEST_CITY_MARKET_ID, t.DEST,
       t.DEST_CITY_NAME, t.DEST_STATE_ABR, t.DEST_STATE_FIPS, t.DEST_STATE_NM, t.DEST_WAC, t.CRS_DEP_TIME, t.DEP_TIME, t.DEP_DELAY, t.DEP_DELAY_NEW, t.DEP_DEL15, t.DEP_DELAY_GROUP, t.DEP_TIME_BLK, t.TAXI_OUT,
       t.WHEELS_OFF, t.WHEELS_ON, t.TAXI_IN, t.CRS_ARR_TIME, t.ARR_TIME, t.ARR_DELAY, t.ARR_DELAY_NEW, t.ARR_DEL15, t.ARR_DELAY_GROUP, t.ARR_TIME_BLK, t.CANCELLED, t.DIVERTED, t.CRS_ELAPSED_TIME, t.ACTUAL_ELAPSED_TIME,
       t.AIR_TIME, t.FLIGHTS, t.DISTANCE, t.DISTANCE_GROUP, t.DIV_AIRPORT_LANDINGS, t.ORIGIN_TZ, t.DEST_TZ, t.DEP_MIN, t.DEP_HOUR, t.ARR_MIN, t.ARR_HOUR, t.ORIGIN_TS, t.ORIGIN_UTC, t.DEST_TS, t.DEST_UTC, 
       t.ORIGIN_STATION, t.ORIGIN_STATION_NAME, t.DEST_STATION, t.DEST_STATION_NAME, t.ORIGIN_UTC_ADJ_MIN, t.ORIGIN_UTC_ADJ_MAX, t.ORIGIN_MAX_DATE, t.DEST_MAX_DATE, t.ORIGIN_FLIGHT_COUNT, t.DEST_FLIGHT_COUNT, 
       t.DELAYS_SO_FAR, t.CRS_ELAPSED_TIME_AVG_DIFF, t.WEST_TO_EAST, t.MINUTES_AFTER_MIDNIGHT_ORIGIN, t.MINUTES_AFTER_MIDNIGHT_DEST, t.HOLIDAY_WEEK, t.DEP_HOUR_BIN, t.ARR_HOUR_BIN, t.NETWORK_CONGESTION, 
       t.ORIGIN_PR, t.DEST_PR, t.IS_MORNING_FLIGHT, t.IS_EVENING_FLIGHT,
       coalesce(t.AVG_WND_SPEED_ORIGIN, ta.AVG_WND_SPEED_ORIGIN) as AVG_WND_SPEED_ORIGIN, coalesce(t.AVG_CIG_HEIGHT_ORIGIN, ta.AVG_CIG_HEIGHT_ORIGIN) as AVG_CIG_HEIGHT_ORIGIN, 
       coalesce(t.MIN_CIG_HEIGHT_ORIGIN, ta.MIN_CIG_HEIGHT_ORIGIN) as MIN_CIG_HEIGHT_ORIGIN, coalesce(t.AVG_VIS_DIS_ORIGIN, ta.AVG_VIS_DIS_ORIGIN) as AVG_VIS_DIS_ORIGIN, 
       coalesce(t.MIN_VIS_DIS_ORIGIN, ta.MIN_VIS_DIS_ORIGIN) as MIN_VIS_DIS_ORIGIN, coalesce(t.AVG_TMP_DEG_ORIGIN, ta.AVG_TMP_DEG_ORIGIN) as AVG_TMP_DEG_ORIGIN, 
       coalesce(t.AVG_DEW_DEG_ORIGIN, ta.AVG_DEW_DEG_ORIGIN) as AVG_DEW_DEG_ORIGIN, coalesce(t.AVG_SLP_ORIGIN, ta.AVG_SLP_ORIGIN) as AVG_SLP_ORIGIN, 
       coalesce(t.AVG_WND_SPEED_DEST, ta.AVG_WND_SPEED_DEST) as AVG_WND_SPEED_DEST, coalesce(t.AVG_CIG_HEIGHT_DEST, ta.AVG_CIG_HEIGHT_DEST) as AVG_CIG_HEIGHT_DEST, 
       coalesce(t.MIN_CIG_HEIGHT_DEST, ta.MIN_CIG_HEIGHT_DEST) as MIN_CIG_HEIGHT_DEST, coalesce(t.AVG_VIS_DIS_DEST, ta.AVG_VIS_DIS_DEST) as AVG_VIS_DIS_DEST, 
       coalesce(t.MIN_VIS_DIS_DEST, ta.MIN_VIS_DIS_DEST) as MIN_VIS_DIS_DEST, 
       coalesce(t.AVG_TMP_DEG_DEST, ta.AVG_TMP_DEG_DEST) as AVG_TMP_DEG_DEST, coalesce(t.AVG_DEW_DEG_DEST, ta.AVG_DEW_DEG_DEST) as AVG_DEW_DEG_DEST, coalesce(t.AVG_SLP_DEST, ta.AVG_SLP_DEST) as AVG_SLP_DEST
FROM test_avg_imp as t, train_averages as ta
""")

display(test_column_imp)
test_column_imp.count()

# COMMAND ----------

test_column_imp.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Write Test Data To DBFS

# COMMAND ----------

test_column_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/project_data/test")

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/mids-w261/team20SSDK/project_data/"))

# COMMAND ----------

train = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/train/")

display(train)
train.count()

# COMMAND ----------

val = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/validation/")

display(val)
val.count()

# COMMAND ----------

test = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/test/")

display(test)
test.count()

# COMMAND ----------


