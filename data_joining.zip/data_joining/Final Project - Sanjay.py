# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np

import pandas as pd, matplotlib.pyplot as plt
import matplotlib.cm as cm, matplotlib.font_manager as fm
from datetime import datetime as dt
# from sklearn.cluster import DBSCAN

# from haversine import haversine, Unit

sqlContext = SQLContext(sc)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Load Datasets

# COMMAND ----------

# Airlines Table
airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_range_final")
display(airlines)
airlines.count()

# COMMAND ----------

# Weather Table (All columns)
weather_final_all = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_all_columns")
display(weather_final_all)

# COMMAND ----------

# Remove unnecessary colums from Weather table
weather = weather_final_all.select("YEAR", "MONTH", "DAY_OF_MONTH", "HOUR_BLOCK", 
                                   "STATION", "DATE", "SOURCE", "LATITUDE", "LONGITUDE", 
                                   "ELEVATION", "NAME", "REPORT_TYPE", "CALL_SIGN", "QUALITY_CONTROL", 
                                   "country", "WND_Speed", "WND_Speed_Qlty", "CIG_HEIGHT", "CIG_Qlty",
                                   "VIS_Dis", "VIS_Qlty", "TMP_Degree", "TMP_Qlty", "DEW_Degree",
                                   "DEW_Qlty", "SLP_Pressure", "SLP_Qlty")

display(weather)

# COMMAND ----------

weather.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_trimmed")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Going Back To Existing Work

# COMMAND ----------

weather_metrics_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_metrics_final")

display(weather_metrics_final)

# COMMAND ----------

weather_origin_helper = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/woh_range")

display(weather_origin_helper)

# COMMAND ----------

weather_dest_helper = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wdh_range")

display(weather_dest_helper)

# COMMAND ----------

airlines = airlines.join(weather_origin_helper, [airlines.ORIGIN_STATION == weather_origin_helper.ORIGIN_STATION, airlines.ORIGIN_UTC == weather_origin_helper.ORIGIN_UTC], 'left').select(*airlines, weather_origin_helper.ORIGIN_MAX_DATE)

display(airlines)

# COMMAND ----------

airlines.count()

# COMMAND ----------

airlines = airlines.join(weather_dest_helper, [airlines.DEST_STATION == weather_dest_helper.DEST_STATION, airlines.ORIGIN_UTC == weather_dest_helper.ORIGIN_UTC], 'left').select(*airlines, weather_dest_helper.DEST_MAX_DATE)

display(airlines)

# COMMAND ----------

airlines.count()

# COMMAND ----------

airlines.registerTempTable('airlines')

# COMMAND ----------

display(spark.sql("""
SELECT YEAR, count(1)
FROM airlines
WHERE ORIGIN_MAX_DATE is null OR DEST_MAX_DATE is null
GROUP BY YEAR
"""))

# COMMAND ----------

airlines.filter("YEAR == 2019").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Imputation for Weather Columns

# COMMAND ----------

station_neighbors = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_neighbors")
display(station_neighbors)

# COMMAND ----------

station_neighbors.registerTempTable('station_neighbors')

# COMMAND ----------

weather.columns

# COMMAND ----------

weather_wnd_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.WND_Speed) as WND_SPEED
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.WND_Speed_Qlty NOT IN ('2', '3', '6', '7') AND (w1.WND_Speed = 9999 OR w1.WND_Speed is null) AND (w2.WND_Speed != 9999 AND w2.WND_Speed is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.WND_Speed
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.WND_Speed != 9999 AND w1.WND_Speed is not null AND w1.WND_Speed_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_wnd_imp)

# COMMAND ----------

weather_wnd_imp.count()

# COMMAND ----------

weather_wnd_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_wnd_imp")

# COMMAND ----------

weather_cig_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.CIG_Height) as CIG_HEIGHT
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.CIG_Qlty NOT IN ('2', '3', '6', '7') AND (w1.CIG_HEIGHT = 99999 OR w1.CIG_HEIGHT is null) AND (w2.CIG_HEIGHT != 99999 AND w2.CIG_HEIGHT is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.CIG_HEIGHT
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.CIG_HEIGHT != 99999 AND w1.CIG_HEIGHT is not null AND w1.CIG_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_cig_imp)

# COMMAND ----------

weather_cig_imp.count()

# COMMAND ----------

weather_cig_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_cig_imp")

# COMMAND ----------

weather_vis_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.VIS_Dis) as VIS_DIS
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.VIS_Qlty NOT IN ('2', '3', '6', '7') AND (w1.VIS_DIS = 999999 OR w1.VIS_DIS is null) AND (w2.VIS_DIS != 999999 AND w2.VIS_DIS is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.VIS_DIS
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.VIS_DIS != 999999 AND w1.VIS_DIS is not null AND w1.VIS_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_vis_imp)

# COMMAND ----------

weather_vis_imp.count()

# COMMAND ----------

weather_vis_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_vis_imp")

# COMMAND ----------

weather_tmp_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.TMP_Degree) as TMP_DEGREE
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.TMP_Qlty NOT IN ('2', '3', '6', '7') AND (w1.TMP_Degree = 9999 OR w1.TMP_Degree is null) AND (w2.TMP_Degree != 9999 AND w2.TMP_Degree is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.TMP_Degree
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.TMP_Degree != 9999 AND w1.TMP_Degree is not null AND w1.TMP_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_tmp_imp)

# COMMAND ----------

weather_tmp_imp.count()

# COMMAND ----------

weather_tmp_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp")

# COMMAND ----------

weather_dew_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.DEW_Degree) as DEW_DEGREE
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.DEW_Qlty NOT IN ('2', '3', '6', '7') AND (w1.DEW_Degree = 9999 OR w1.DEW_Degree is null) AND (w2.DEW_Degree != 9999 AND w2.DEW_Degree is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.DEW_DEGREE
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.DEW_Degree != 9999 AND w1.DEW_Degree is not null AND w1.DEW_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_dew_imp)

# COMMAND ----------

weather_dew_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_dew_imp")

# COMMAND ----------

weather_slp_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.SLP_Pressure) as SLP_PRESSURE
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.SLP_Qlty NOT IN ('2', '3', '6', '7') AND (w1.SLP_Pressure = 99999 OR w1.SLP_Pressure is null) AND (w2.SLP_Pressure != 99999 AND w2.SLP_Pressure is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.SLP_Pressure
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.SLP_Pressure != 99999 AND w1.SLP_Pressure is not null AND w1.SLP_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_slp_imp)

# COMMAND ----------

weather_slp_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_slp_imp")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Calculate Weather Averages/Mins

# COMMAND ----------

weather_wnd_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_wnd_imp")
display(weather_wnd_imp)

# COMMAND ----------

weather_cig_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_cig_imp")
display(weather_cig_imp)

# COMMAND ----------

weather_vis_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_vis_imp")
display(weather_vis_imp)

# COMMAND ----------

weather_tmp_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp")
display(weather_tmp_imp)

# COMMAND ----------

weather_dew_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_dew_imp")
display(weather_dew_imp)

# COMMAND ----------

weather_slp_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_slp_imp")
display(weather_slp_imp)

# COMMAND ----------

weather_wnd_imp.registerTempTable('weather_wnd_imp')
weather_cig_imp.registerTempTable('weather_cig_imp')
weather_vis_imp.registerTempTable('weather_vis_imp')
weather_tmp_imp.registerTempTable('weather_tmp_imp')
weather_dew_imp.registerTempTable('weather_dew_imp')
weather_slp_imp.registerTempTable('weather_slp_imp')

# COMMAND ----------

weather_wnd_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.WND_Speed) as AVG_WND_SPEED
                        FROM weather_wnd_imp as w1, station_neighbors as sn, weather_wnd_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_wnd_avg)

# COMMAND ----------

weather_wnd_avg.count()

# COMMAND ----------

weather_cig_avg_min = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.CIG_HEIGHT) as AVG_CIG_HEIGHT, min(w2.CIG_HEIGHT) as MIN_CIG_HEIGHT
                        FROM weather_cig_imp as w1, station_neighbors as sn, weather_cig_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_cig_avg_min)

# COMMAND ----------

weather_vis_avg_min = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.VIS_DIS) as AVG_VIS_DIS, min(w2.VIS_DIS) as MIN_VIS_DIS
                        FROM weather_vis_imp as w1, station_neighbors as sn, weather_vis_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_vis_avg_min)

# COMMAND ----------

weather_tmp_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.TMP_DEGREE) as AVG_TMP_DEG
                        FROM weather_tmp_imp as w1, station_neighbors as sn, weather_tmp_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_tmp_avg)

# COMMAND ----------

weather_dew_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.DEW_DEGREE) as AVG_DEW_DEG
                        FROM weather_dew_imp as w1, station_neighbors as sn, weather_dew_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_dew_avg)

# COMMAND ----------

weather_slp_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.SLP_PRESSURE) as AVG_SLP
                        FROM weather_slp_imp as w1, station_neighbors as sn, weather_slp_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_slp_avg)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Join All Weather Metrics

# COMMAND ----------

weather_wnd_avg.registerTempTable('weather_wnd_avg')
weather_cig_avg_min.registerTempTable('weather_cig_avg_min')
weather_vis_avg_min.registerTempTable('weather_vis_avg_min')
weather_tmp_avg.registerTempTable('weather_tmp_avg')
weather_dew_avg.registerTempTable('weather_dew_avg')
weather_slp_avg.registerTempTable('weather_slp_avg')

# COMMAND ----------

wnd_height = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.AVG_WND_SPEED, w2.AVG_CIG_HEIGHT, w2.MIN_CIG_HEIGHT
FROM weather_wnd_avg as w1 FULL JOIN weather_cig_avg_min as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_height)
