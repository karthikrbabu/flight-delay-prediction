# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np

import pandas as pd, matplotlib.pyplot as plt
import matplotlib.cm as cm, matplotlib.font_manager as fm
from datetime import datetime as dt

sqlContext = SQLContext(sc)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Load Datasets

# COMMAND ----------

# Airlines Table
airlines = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_final")

display(airlines)
airlines.count()

# COMMAND ----------

# Weather Table (All columns)
weather_final_all = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_all_columns")
display(weather_final_all)

# COMMAND ----------

# Remove unnecessary colums from Weather table
weather = weather_final_all.select("YEAR", "MONTH", "DAY_OF_MONTH", "HOUR_BLOCK", 
                                   "STATION", "DATE", "SOURCE", "LATITUDE", "LONGITUDE", 
                                   "ELEVATION", "NAME", "REPORT_TYPE", "CALL_SIGN", "QUALITY_CONTROL", 
                                   "country", "WND_Speed", "WND_Speed_Qlty", "CIG_HEIGHT", "CIG_Qlty",
                                   "VIS_Dis", "VIS_Qlty", "TMP_Degree", "TMP_Qlty", "DEW_Degree",
                                   "DEW_Qlty", "SLP_Pressure", "SLP_Qlty")

display(weather)

# COMMAND ----------

weather.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_trimmed")

# COMMAND ----------

# Weather Table (Trimmed)
weather = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_trimmed")
display(weather)
weather.count()

# COMMAND ----------

station_neighbors = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_neighbors")
display(station_neighbors)
station_neighbors.count()

# COMMAND ----------

station_neighbors.select("station_id").distinct().count()

# COMMAND ----------

airport_meta = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta")

display(airport_meta)
airport_meta.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Imputation for Weather Columns

# COMMAND ----------

weather.registerTempTable('weather')
station_neighbors.registerTempTable('station_neighbors')

# COMMAND ----------

weather_wnd_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.WND_Speed) as WND_SPEED
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.WND_Speed_Qlty NOT IN ('2', '3', '6', '7') AND (w1.WND_Speed = 9999 OR w1.WND_Speed is null) AND (w2.WND_Speed != 9999 AND w2.WND_Speed is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.WND_Speed
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.WND_Speed != 9999 AND w1.WND_Speed is not null AND w1.WND_Speed_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_wnd_imp)

# COMMAND ----------

weather_wnd_imp.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_wnd_imp", True)
weather_wnd_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_wnd_imp")

# COMMAND ----------

weather_cig_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.CIG_Height) as CIG_HEIGHT
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.CIG_Qlty NOT IN ('2', '3', '6', '7') AND (w1.CIG_HEIGHT = 99999 OR w1.CIG_HEIGHT is null) AND (w2.CIG_HEIGHT != 99999 AND w2.CIG_HEIGHT is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.CIG_HEIGHT
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.CIG_HEIGHT != 99999 AND w1.CIG_HEIGHT is not null AND w1.CIG_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_cig_imp)

# COMMAND ----------

weather_cig_imp.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_cig_imp", True)
weather_cig_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_cig_imp")

# COMMAND ----------

weather_vis_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.VIS_Dis) as VIS_DIS
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.VIS_Qlty NOT IN ('2', '3', '6', '7') AND (w1.VIS_DIS = 999999 OR w1.VIS_DIS is null) AND (w2.VIS_DIS != 999999 AND w2.VIS_DIS is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.VIS_DIS
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.VIS_DIS != 999999 AND w1.VIS_DIS is not null AND w1.VIS_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_vis_imp)

# COMMAND ----------

weather_vis_imp.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_vis_imp", True)
weather_vis_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_vis_imp")

# COMMAND ----------

weather_tmp_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.TMP_Degree) as TMP_DEGREE
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.TMP_Qlty NOT IN ('2', '3', '6', '7') AND (w1.TMP_Degree = 9999 OR w1.TMP_Degree is null) AND (w2.TMP_Degree != 9999 AND w2.TMP_Degree is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.TMP_Degree
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.TMP_Degree != 9999 AND w1.TMP_Degree is not null AND w1.TMP_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_tmp_imp)

# COMMAND ----------

weather_tmp_imp.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp", True)
weather_tmp_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp")

# COMMAND ----------

weather_dew_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.DEW_Degree) as DEW_DEGREE
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.DEW_Qlty NOT IN ('2', '3', '6', '7') AND (w1.DEW_Degree = 9999 OR w1.DEW_Degree is null) AND (w2.DEW_Degree != 9999 AND w2.DEW_Degree is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.DEW_DEGREE
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.DEW_Degree != 9999 AND w1.DEW_Degree is not null AND w1.DEW_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_dew_imp)

# COMMAND ----------

weather_dew_imp.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_dew_imp", True)
weather_dew_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_dew_imp")

# COMMAND ----------

weather_slp_imp = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.SLP_Pressure) as SLP_PRESSURE
                        FROM weather as w1, station_neighbors as sn, weather as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.SLP_Qlty NOT IN ('2', '3', '6', '7') AND (w1.SLP_Pressure = 99999 OR w1.SLP_Pressure is null) AND (w2.SLP_Pressure != 99999 AND w2.SLP_Pressure is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.SLP_Pressure
                        FROM weather as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.SLP_Pressure != 99999 AND w1.SLP_Pressure is not null AND w1.SLP_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_slp_imp)

# COMMAND ----------

weather_slp_imp.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_slp_imp", True)
weather_slp_imp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_slp_imp")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Create Final Imputed Weather Table

# COMMAND ----------

weather_wnd_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_wnd_imp")
display(weather_wnd_imp)

# COMMAND ----------

weather_cig_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_cig_imp")
display(weather_cig_imp)

# COMMAND ----------

weather_vis_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_vis_imp")
display(weather_vis_imp)

# COMMAND ----------

weather_tmp_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp")
display(weather_tmp_imp)

# COMMAND ----------

weather_dew_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_dew_imp")
display(weather_dew_imp)

# COMMAND ----------

weather_slp_imp = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_slp_imp")
display(weather_slp_imp)

# COMMAND ----------

weather_wnd_imp.registerTempTable('weather_wnd_imp')
weather_cig_imp.registerTempTable('weather_cig_imp')
weather_vis_imp.registerTempTable('weather_vis_imp')
weather_tmp_imp.registerTempTable('weather_tmp_imp')
weather_dew_imp.registerTempTable('weather_dew_imp')
weather_slp_imp.registerTempTable('weather_slp_imp')

# COMMAND ----------

wnd_cig_imp = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w2.CIG_HEIGHT
FROM weather_wnd_imp as w1 FULL JOIN weather_cig_imp as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_imp)

# COMMAND ----------

wnd_cig_imp.registerTempTable('wnd_cig_imp')

wnd_cig_vis_imp = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w2.VIS_DIS
FROM wnd_cig_imp as w1 FULL JOIN weather_vis_imp as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_imp)

# COMMAND ----------

wnd_cig_vis_imp.registerTempTable('wnd_cig_vis_imp')

wnd_cig_vis_tmp_imp = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w1.VIS_DIS, w2.TMP_DEGREE
FROM wnd_cig_vis_imp as w1 FULL JOIN weather_tmp_imp as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_tmp_imp)

# COMMAND ----------

wnd_cig_vis_tmp_imp.registerTempTable('wnd_cig_vis_tmp_imp')

wnd_cig_vis_tmp_dew_imp = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w1.VIS_DIS, 
  w1.TMP_DEGREE, w2.DEW_DEGREE
FROM wnd_cig_vis_tmp_imp as w1 FULL JOIN weather_dew_imp as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_tmp_dew_imp)

# COMMAND ----------

wnd_cig_vis_tmp_dew_imp.registerTempTable('wnd_cig_vis_tmp_dew_imp')

weather_imputed = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w1.VIS_DIS, w1.TMP_DEGREE, 
  w1.DEW_DEGREE, w2.SLP_PRESSURE
FROM wnd_cig_vis_tmp_dew_imp as w1 FULL JOIN weather_slp_imp as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(weather_imputed)

# COMMAND ----------

weather_imputed.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_imputed")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Calculate Weather Averages/Mins

# COMMAND ----------

weather_wnd_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.WND_Speed) as AVG_WND_SPEED
                        FROM weather_wnd_imp as w1, station_neighbors as sn, weather_wnd_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_wnd_avg)

# COMMAND ----------

weather_wnd_avg.count()

# COMMAND ----------

weather_wnd_avg.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_wnd_avg")

# COMMAND ----------

weather_cig_avg_min = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.CIG_HEIGHT) as AVG_CIG_HEIGHT, min(w2.CIG_HEIGHT) as MIN_CIG_HEIGHT
                        FROM weather_cig_imp as w1, station_neighbors as sn, weather_cig_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_cig_avg_min)

# COMMAND ----------

weather_cig_avg_min.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_cig_avg_min")

# COMMAND ----------

weather_vis_avg_min = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.VIS_DIS) as AVG_VIS_DIS, min(w2.VIS_DIS) as MIN_VIS_DIS
                        FROM weather_vis_imp as w1, station_neighbors as sn, weather_vis_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_vis_avg_min)

# COMMAND ----------

weather_vis_avg_min.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_vis_avg_min")

# COMMAND ----------

weather_tmp_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.TMP_DEGREE) as AVG_TMP_DEG
                        FROM weather_tmp_imp as w1, station_neighbors as sn, weather_tmp_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_tmp_avg)

# COMMAND ----------

weather_tmp_avg.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_tmp_avg")

# COMMAND ----------

weather_dew_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.DEW_DEGREE) as AVG_DEW_DEG
                        FROM weather_dew_imp as w1, station_neighbors as sn, weather_dew_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_dew_avg)

# COMMAND ----------

weather_dew_avg.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_dew_avg")

# COMMAND ----------

weather_slp_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.SLP_PRESSURE) as AVG_SLP
                        FROM weather_slp_imp as w1, station_neighbors as sn, weather_slp_imp as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country""")

display(weather_slp_avg)

# COMMAND ----------

weather_slp_avg.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_slp_avg")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Join All Weather Metrics

# COMMAND ----------

weather_wnd_avg = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_wnd_avg")
display(weather_wnd_avg)

# COMMAND ----------

weather_cig_avg_min = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_cig_avg_min")
display(weather_cig_avg_min)

# COMMAND ----------

weather_vis_avg_min = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_vis_avg_min")
display(weather_vis_avg_min)

# COMMAND ----------

weather_tmp_avg = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_tmp_avg")
display(weather_tmp_avg)

# COMMAND ----------

weather_dew_avg = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_dew_avg")
display(weather_dew_avg)

# COMMAND ----------

weather_slp_avg = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_helpers/weather_slp_avg")
display(weather_slp_avg)

# COMMAND ----------

weather_wnd_avg.registerTempTable('weather_wnd_avg')
weather_cig_avg_min.registerTempTable('weather_cig_avg_min')
weather_vis_avg_min.registerTempTable('weather_vis_avg_min')
weather_tmp_avg.registerTempTable('weather_tmp_avg')
weather_dew_avg.registerTempTable('weather_dew_avg')
weather_slp_avg.registerTempTable('weather_slp_avg')

# COMMAND ----------

wnd_cig = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.AVG_WND_SPEED, w2.AVG_CIG_HEIGHT, w2.MIN_CIG_HEIGHT
FROM weather_wnd_avg as w1 FULL JOIN weather_cig_avg_min as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig)

# COMMAND ----------

wnd_cig.count()

# COMMAND ----------

wnd_cig.registerTempTable('wnd_cig')

wnd_cig_vis = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.AVG_WND_SPEED, w1.AVG_CIG_HEIGHT, w1.MIN_CIG_HEIGHT, w2.AVG_VIS_DIS, w2.MIN_VIS_DIS
FROM wnd_cig as w1 FULL JOIN weather_vis_avg_min as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis)

# COMMAND ----------

wnd_cig_vis.registerTempTable('wnd_cig_vis')

wnd_cig_vis_tmp = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.AVG_WND_SPEED, 
  w1.AVG_CIG_HEIGHT, w1.MIN_CIG_HEIGHT, w1.AVG_VIS_DIS, w1.MIN_VIS_DIS, w2.AVG_TMP_DEG
FROM wnd_cig_vis as w1 FULL JOIN weather_tmp_avg as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_tmp)

# COMMAND ----------

wnd_cig_vis_tmp.registerTempTable('wnd_cig_vis_tmp')

wnd_cig_vis_tmp_dew = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.AVG_WND_SPEED, 
  w1.AVG_CIG_HEIGHT, w1.MIN_CIG_HEIGHT, w1.AVG_VIS_DIS, w1.MIN_VIS_DIS, w1.AVG_TMP_DEG, w2.AVG_DEW_DEG
FROM wnd_cig_vis_tmp as w1 FULL JOIN weather_dew_avg as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_tmp_dew)

# COMMAND ----------

wnd_cig_vis_tmp_dew.registerTempTable('wnd_cig_vis_tmp_dew')

weather_metrics_imputed = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.AVG_WND_SPEED, 
  w1.AVG_CIG_HEIGHT, w1.MIN_CIG_HEIGHT, w1.AVG_VIS_DIS, w1.MIN_VIS_DIS, w1.AVG_TMP_DEG, w1.AVG_DEW_DEG, w2.AVG_SLP
FROM wnd_cig_vis_tmp_dew as w1 FULL JOIN weather_slp_avg as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(weather_metrics_imputed)

# COMMAND ----------

weather_metrics_imputed.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_imputed")

# COMMAND ----------

weather_metrics_imputed = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_metrics_imputed")
display(weather_metrics_imputed)

# COMMAND ----------

weather_metrics_imputed.count()

# COMMAND ----------

weather_metrics_imputed.registerTempTable('weather_metrics_imputed')

# COMMAND ----------

weather_metrics_imputed.columns

# COMMAND ----------

weather_metrics_imputed_agg = spark.sql("""
SELECT YEAR, MONTH, DAY_OF_MONTH, STATION, DATE, LATITUDE, LONGITUDE, ELEVATION,
       CALL_SIGN, QUALITY_CONTROL, COUNTRY, avg(AVG_WND_SPEED) as AVG_WND_SPEED,
       avg(AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT, min(MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT,
       avg(AVG_VIS_DIS) as AVG_VIS_DIS, min(MIN_VIS_DIS) as MIN_VIS_DIS,
       avg(AVG_TMP_DEG) as AVG_TMP_DEG, avg(AVG_DEW_DEG) as AVG_DEW_DEG, avg(AVG_SLP) as AVG_SLP
FROM weather_metrics_imputed
GROUP BY YEAR, MONTH, DAY_OF_MONTH, STATION, DATE, LATITUDE, LONGITUDE, ELEVATION,
         CALL_SIGN, QUALITY_CONTROL, COUNTRY
""")

display(weather_metrics_imputed_agg)

# COMMAND ----------

weather_metrics_imputed_agg.count()

# COMMAND ----------

weather_metrics_imputed_agg.registerTempTable('weather_metrics_imputed_agg')

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Create The Final Dataset

# COMMAND ----------

# Join airlines with stations to get origin station
airlines = airlines.join(airport_meta.alias('AM'), airlines.ORIGIN == col('AM.IATA')).select(*airlines, col('AM.STATION').alias('ORIGIN_STATION'), col('AM.NAME').alias('ORIGIN_STATION_NAME'), col('AM.pagerank').alias('PAGERANK'))

display(airlines)

# COMMAND ----------

# Join previous with stations to get destination station
airlines = airlines.join(airport_meta.alias('AM'), airlines.DEST == col('AM.IATA')).select(*airlines, col('AM.STATION').alias('DEST_STATION'), col('AM.NAME').alias('DEST_STATION_NAME'))

display(airlines)

# COMMAND ----------

airlines.registerTempTable('airlines')

# COMMAND ----------

airlines = spark.sql("""
SELECT a.*, a.ORIGIN_UTC - INTERVAL 50 HOURS as ORIGIN_UTC_ADJ_MIN, a.ORIGIN_UTC - INTERVAL 2 HOURS as ORIGIN_UTC_ADJ_MAX
FROM airlines as a
""")

display(airlines)

# COMMAND ----------

airlines.registerTempTable('airlines')

# COMMAND ----------

weather_origin_helper = spark.sql("""
SELECT a.ORIGIN_STATION, a.ORIGIN_UTC, max(wo.DATE) as ORIGIN_MAX_DATE
        FROM airlines as a, weather_metrics_imputed as wo
        WHERE wo.STATION == a.ORIGIN_STATION AND wo.DATE BETWEEN a.ORIGIN_UTC_ADJ_MIN AND a.ORIGIN_UTC_ADJ_MAX
        GROUP BY a.ORIGIN_STATION, a.ORIGIN_UTC
""")

display(weather_origin_helper)

# COMMAND ----------

weather_origin_helper.count()

# COMMAND ----------

weather_origin_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_origin_helper")

# COMMAND ----------

weather_origin_helper = spark.sql("""
SELECT a.ORIGIN_STATION, a.ORIGIN_UTC, max(wo.DATE) as ORIGIN_MAX_DATE
        FROM airlines as a, weather_metrics_imputed_agg as wo
        WHERE wo.STATION == a.ORIGIN_STATION AND wo.DATE BETWEEN a.ORIGIN_UTC_ADJ_MIN AND a.ORIGIN_UTC_ADJ_MAX
        GROUP BY a.ORIGIN_STATION, a.ORIGIN_UTC
""")

display(weather_origin_helper)

# COMMAND ----------

weather_origin_helper.count()

# COMMAND ----------

weather_dest_helper = spark.sql("""
SELECT a.DEST_STATION, a.ORIGIN_UTC, max(wd.DATE) as DEST_MAX_DATE
        FROM airlines as a, weather_metrics_imputed as wd
        WHERE wd.STATION == a.DEST_STATION AND wd.DATE BETWEEN a.ORIGIN_UTC_ADJ_MIN AND a.ORIGIN_UTC_ADJ_MAX
        GROUP BY a.DEST_STATION, a.ORIGIN_UTC
""")

display(weather_dest_helper)

# COMMAND ----------

weather_dest_helper.count()

# COMMAND ----------

weather_dest_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_dest_helper") 

# COMMAND ----------

weather_dest_helper = spark.sql("""
SELECT a.DEST_STATION, a.ORIGIN_UTC, max(wd.DATE) as DEST_MAX_DATE
        FROM airlines as a, weather_metrics_imputed_agg as wd
        WHERE wd.STATION == a.DEST_STATION AND wd.DATE BETWEEN a.ORIGIN_UTC_ADJ_MIN AND a.ORIGIN_UTC_ADJ_MAX
        GROUP BY a.DEST_STATION, a.ORIGIN_UTC
""")

display(weather_dest_helper)

# COMMAND ----------

weather_origin_helper = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_origin_helper")

display(weather_origin_helper)

# COMMAND ----------

weather_dest_helper = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_dest_helper")

display(weather_dest_helper)

# COMMAND ----------

weather_origin_helper.registerTempTable('weather_origin_helper')
weather_dest_helper.registerTempTable('weather_dest_helper')

# COMMAND ----------

airlines_final = airlines.join(weather_origin_helper, [airlines.ORIGIN_STATION == weather_origin_helper.ORIGIN_STATION, airlines.ORIGIN_UTC == weather_origin_helper.ORIGIN_UTC], 'left').select(*airlines, weather_origin_helper.ORIGIN_MAX_DATE)

display(airlines_final)

# COMMAND ----------

airlines_final = airlines_final.join(weather_dest_helper, [airlines_final.DEST_STATION == weather_dest_helper.DEST_STATION, airlines_final.ORIGIN_UTC == weather_dest_helper.ORIGIN_UTC], 'left').select(*airlines_final, weather_dest_helper.DEST_MAX_DATE)

display(airlines_final)

# COMMAND ----------

airlines_final.count()

# COMMAND ----------

airlines_final.filter("ORIGIN_MAX_DATE is null OR DEST_MAX_DATE is null").count()

# COMMAND ----------

31171199 - 6293165

# COMMAND ----------

airlines_final.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/airlines_final") 

# COMMAND ----------

airlines_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/airlines_final")

display(airlines_final)

# COMMAND ----------

airlines_final.registerTempTable('airlines_final')

# COMMAND ----------

data_final = spark.sql("""
SELECT a.*, wmo.AVG_WND_SPEED as AVG_WND_SPEED_ORIGIN, wmo.AVG_CIG_HEIGHT as AVG_CIG_HEIGHT_ORIGIN, 
       wmo.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_ORIGIN, wmo.AVG_VIS_DIS as AVG_VIS_DIS_ORIGIN, 
       wmo.MIN_VIS_DIS as MIN_VIS_DIS_ORIGIN, wmo.AVG_TMP_DEG as AVG_TMP_DEG_ORIGIN,   
       wmo.AVG_DEW_DEG as AVG_DEW_DEG_ORIGIN, wmo.AVG_SLP as AVG_SLP_ORIGIN, 
       wmd.AVG_WND_SPEED as AVG_WND_SPEED_DEST, wmd.AVG_CIG_HEIGHT as AVG_CIG_HEIGHT_DEST, 
       wmd.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_DEST, wmd.AVG_VIS_DIS as AVG_VIS_DIS_DEST, 
       wmd.MIN_VIS_DIS as MIN_VIS_DIS_DEST, wmd.AVG_TMP_DEG as AVG_TMP_DEG_DEST, 
       wmd.AVG_DEW_DEG as AVG_DEW_DEG_DEST, wmd.AVG_SLP as AVG_SLP_DEST
FROM airlines_final as a 
  LEFT JOIN weather_metrics_imputed as wmo 
    ON a.ORIGIN_STATION == wmo.STATION AND wmo.DATE == a.ORIGIN_MAX_DATE
  LEFT JOIN weather_metrics_imputed as wmd 
    ON a.DEST_STATION == wmd.STATION AND wmd.DATE == a.DEST_MAX_DATE
""")

display(data_final)

# COMMAND ----------

data_final.count()

# COMMAND ----------

31225507 - 31171199

# COMMAND ----------

data_final = spark.sql("""
SELECT a.*, avg(wmo.AVG_WND_SPEED) as AVG_WND_SPEED_ORIGIN, avg(wmo.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, 
       min(wmo.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, avg(wmo.AVG_VIS_DIS) as AVG_VIS_DIS_ORIGIN, 
       min(wmo.MIN_VIS_DIS) as MIN_VIS_DIS_ORIGIN, avg(wmo.AVG_TMP_DEG) as AVG_TMP_DEG_ORIGIN,   
       avg(wmo.AVG_DEW_DEG) as AVG_DEW_DEG_ORIGIN, avg(wmo.AVG_SLP) as AVG_SLP_ORIGIN, 
       avg(wmd.AVG_WND_SPEED) as AVG_WND_SPEED_DEST, avg(wmd.AVG_CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       min(wmd.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, avg(wmd.AVG_VIS_DIS) as AVG_VIS_DIS_DEST, 
       min(wmd.MIN_VIS_DIS) as MIN_VIS_DIS_DEST, avg(wmd.AVG_TMP_DEG) as AVG_TMP_DEG_DEST, 
       avg(wmd.AVG_DEW_DEG) as AVG_DEW_DEG_DEST, avg(wmd.AVG_SLP) as AVG_SLP_DEST
FROM airlines_final as a 
  LEFT JOIN weather_metrics_imputed as wmo 
    ON a.ORIGIN_STATION == wmo.STATION AND wmo.DATE == a.ORIGIN_MAX_DATE
  LEFT JOIN weather_metrics_imputed as wmd 
    ON a.DEST_STATION == wmd.STATION AND wmd.DATE == a.DEST_MAX_DATE
GROUP BY a.YEAR, a.QUARTER, a.MONTH, a.DAY_OF_MONTH, a.DAY_OF_WEEK, a.FL_DATE, a.OP_UNIQUE_CARRIER,
         a.OP_CARRIER_AIRLINE_ID, a.OP_CARRIER, a.TAIL_NUM, a.OP_CARRIER_FL_NUM, a.ORIGIN_AIRPORT_ID, 
         a.ORIGIN_AIRPORT_SEQ_ID, a.ORIGIN_CITY_MARKET_ID, a.ORIGIN, a.ORIGIN_CITY_NAME, a.ORIGIN_STATE_ABR,
         a.ORIGIN_STATE_FIPS, a.ORIGIN_STATE_NM, a.ORIGIN_WAC, a.DEST_AIRPORT_ID, a.DEST_AIRPORT_SEQ_ID,
         a.DEST_CITY_MARKET_ID, a.DEST, a.DEST_CITY_NAME, a.DEST_STATE_ABR, a.DEST_STATE_FIPS, a.DEST_STATE_NM, 
         a.DEST_WAC, a.CRS_DEP_TIME, a.DEP_TIME, a.DEP_DELAY, a.DEP_DELAY_NEW, a.DEP_DEL15, a.DEP_DELAY_GROUP,
         a.DEP_TIME_BLK, a.TAXI_OUT, a.WHEELS_OFF, a.WHEELS_ON, a.TAXI_IN, a.CRS_ARR_TIME, a.ARR_TIME,
         a.ARR_DELAY, a.ARR_DELAY_NEW, a.ARR_DEL15, a.ARR_DELAY_GROUP, a.ARR_TIME_BLK, a.CANCELLED, a.DIVERTED,
         a.CRS_ELAPSED_TIME, a.ACTUAL_ELAPSED_TIME, a.AIR_TIME, a.FLIGHTS, a.DISTANCE, a.DISTANCE_GROUP,
         a.DIV_AIRPORT_LANDINGS, a.ORIGIN_TZ, a.DEST_TZ, a.DEP_MIN, a.DEP_HOUR, a.ARR_MIN, a.ARR_HOUR, a.ORIGIN_TS,
         a.ORIGIN_UTC, a.DEST_TS, a.DEST_UTC, a.ORIGIN_FLIGHT_COUNT, a.DEST_FLIGHT_COUNT, a.ORIGIN_STATION, 
         a.ORIGIN_STATION_NAME, a.PAGERANK, a.DEST_STATION, a.DEST_STATION_NAME, a.ORIGIN_UTC_ADJ_MIN,
         a.ORIGIN_UTC_ADJ_MAX, a.ORIGIN_MAX_DATE, a.DEST_MAX_DATE
""")

display(data_final)

# COMMAND ----------

data_final.count()

# COMMAND ----------

data_final.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final") 

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final")

display(data)
data.count()

# COMMAND ----------

data.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

data.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

data.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Fixing Weather Imputed Table For Test Data (2019)
# MAGIC 
# MAGIC The weather table that was loaded in the beginning is a dataset that consists of the full data for all years (2015 - 2019), yet an issue was noticed where our team was accidentally removing numerous weather observations in 2019 due to the stations table begin and end dates. Specifically, we noticed that the end date for many stations with weather observations in 2019 ended in March 4th, 2019. Due to our Weather EDA initially only capturing weather observations during the active period of each station, we therefore were inadvertently not including weather observations for the full length of 2019. We then made the assumption that this station end data for 2019 data is incorrect and ensure to collect observations throughout the full year. We have since fixed this issue for our test data (2019) within our Weather EDA and will be pulling in a new dataset to rerun the above queries for imputation and final dataset joins.

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Load Raw Weather Table For 2019 Observations

# COMMAND ----------

weather_19_all = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_19_all_columns")

display(weather_19_all)
weather_19_all.count()

# COMMAND ----------

# Remove unnecessary colums from Weather table
weather_19 = weather_19_all.select("YEAR", "MONTH", "DAY_OF_MONTH", "HOUR_BLOCK", 
                                   "STATION", "DATE", "SOURCE", "LATITUDE", "LONGITUDE", 
                                   "ELEVATION", "NAME", "REPORT_TYPE", "CALL_SIGN", "QUALITY_CONTROL", 
                                   "country", "WND_Speed", "WND_Speed_Qlty", "CIG_HEIGHT", "CIG_Qlty",
                                   "VIS_Dis", "VIS_Qlty", "TMP_Degree", "TMP_Qlty", "DEW_Degree",
                                   "DEW_Qlty", "SLP_Pressure", "SLP_Qlty")

display(weather_19)

# COMMAND ----------

weather_19.registerTempTable('weather_19')
station_neighbors.registerTempTable('station_neighbors')

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Impute 2019 Weather Data Using Station Neighbors

# COMMAND ----------

weather_wnd_imp_19 = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.WND_Speed) as WND_SPEED
                        FROM weather_19 as w1, station_neighbors as sn, weather_19 as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.WND_Speed_Qlty NOT IN ('2', '3', '6', '7') AND (w1.WND_Speed = 9999 OR w1.WND_Speed is null) AND (w2.WND_Speed != 9999 AND w2.WND_Speed is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.WND_Speed
                        FROM weather_19 as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.WND_Speed != 9999 AND w1.WND_Speed is not null AND w1.WND_Speed_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_wnd_imp_19)
weather_wnd_imp_19.count()

# COMMAND ----------

weather_wnd_imp_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_wnd_imp_19")

# COMMAND ----------

weather_cig_imp_19 = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.CIG_Height) as CIG_HEIGHT
                        FROM weather_19 as w1, station_neighbors as sn, weather_19 as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.CIG_Qlty NOT IN ('2', '3', '6', '7') AND (w1.CIG_HEIGHT = 99999 OR w1.CIG_HEIGHT is null) AND (w2.CIG_HEIGHT != 99999 AND w2.CIG_HEIGHT is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.CIG_HEIGHT
                        FROM weather_19 as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.CIG_HEIGHT != 99999 AND w1.CIG_HEIGHT is not null AND w1.CIG_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_cig_imp_19)
weather_cig_imp_19.count()

# COMMAND ----------

weather_cig_imp_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_cig_imp_19")

# COMMAND ----------

weather_vis_imp_19 = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.VIS_Dis) as VIS_DIS
                        FROM weather_19 as w1, station_neighbors as sn, weather_19 as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.VIS_Qlty NOT IN ('2', '3', '6', '7') AND (w1.VIS_DIS = 999999 OR w1.VIS_DIS is null) AND (w2.VIS_DIS != 999999 AND w2.VIS_DIS is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.VIS_DIS
                        FROM weather_19 as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.VIS_DIS != 999999 AND w1.VIS_DIS is not null AND w1.VIS_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_vis_imp_19)
weather_vis_imp_19.count()

# COMMAND ----------

weather_vis_imp_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_vis_imp_19")

# COMMAND ----------

weather_tmp_imp_19 = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.TMP_Degree) as TMP_DEGREE
                        FROM weather_19 as w1, station_neighbors as sn, weather_19 as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.TMP_Qlty NOT IN ('2', '3', '6', '7') AND (w1.TMP_Degree = 9999 OR w1.TMP_Degree is null) AND (w2.TMP_Degree != 9999 AND w2.TMP_Degree is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.TMP_Degree
                        FROM weather_19 as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.TMP_Degree != 9999 AND w1.TMP_Degree is not null AND w1.TMP_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_tmp_imp_19)
weather_tmp_imp_19.count()

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp_19", True)

# COMMAND ----------

weather_tmp_imp_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp_19")

# COMMAND ----------

weather_dew_imp_19 = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.DEW_Degree) as DEW_DEGREE
                        FROM weather_19 as w1, station_neighbors as sn, weather_19 as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.DEW_Qlty NOT IN ('2', '3', '6', '7') AND (w1.DEW_Degree = 9999 OR w1.DEW_Degree is null) AND (w2.DEW_Degree != 9999 AND w2.DEW_Degree is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.DEW_DEGREE
                        FROM weather_19 as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.DEW_Degree != 9999 AND w1.DEW_Degree is not null AND w1.DEW_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_dew_imp_19)
weather_dew_imp_19.count()

# COMMAND ----------

weather_dew_imp_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_dew_imp_19")

# COMMAND ----------

weather_slp_imp_19 = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, avg(w2.SLP_Pressure) as SLP_PRESSURE
                        FROM weather_19 as w1, station_neighbors as sn, weather_19 as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.SLP_Qlty NOT IN ('2', '3', '6', '7') AND (w1.SLP_Pressure = 99999 OR w1.SLP_Pressure is null) AND (w2.SLP_Pressure != 99999 AND w2.SLP_Pressure is not null)
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country
                        UNION
                        SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, w1.country, w1.SLP_Pressure
                        FROM weather_19 as w1, (SELECT distinct neighbor_id FROM station_neighbors) as sn
                        WHERE w1.SLP_Pressure != 99999 AND w1.SLP_Pressure is not null AND w1.SLP_Qlty NOT IN ('2', '3', '6', '7') AND w1.STATION == sn.neighbor_id""")

display(weather_slp_imp_19)
weather_slp_imp_19.count()

# COMMAND ----------

weather_slp_imp_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_slp_imp_19")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Combine Above Imputed Tables For 2019 Data

# COMMAND ----------

weather_wnd_imp_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_wnd_imp_19")
display(weather_wnd_imp_19)

# COMMAND ----------

weather_cig_imp_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_cig_imp_19")
display(weather_cig_imp_19)

# COMMAND ----------

weather_vis_imp_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_vis_imp_19")
display(weather_vis_imp_19)

# COMMAND ----------

weather_tmp_imp_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_tmp_imp_19")
display(weather_tmp_imp_19)

# COMMAND ----------

weather_dew_imp_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_dew_imp_19")
display(weather_dew_imp_19)

# COMMAND ----------

weather_slp_imp_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/imputations/weather_slp_imp_19")
display(weather_slp_imp_19)

# COMMAND ----------

weather_wnd_imp_19.registerTempTable('weather_wnd_imp_19')
weather_cig_imp_19.registerTempTable('weather_cig_imp_19')
weather_vis_imp_19.registerTempTable('weather_vis_imp_19')
weather_tmp_imp_19.registerTempTable('weather_tmp_imp_19')
weather_dew_imp_19.registerTempTable('weather_dew_imp_19')
weather_slp_imp_19.registerTempTable('weather_slp_imp_19')

# COMMAND ----------

wnd_cig_imp_19 = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w2.CIG_HEIGHT
FROM weather_wnd_imp_19 as w1 FULL JOIN weather_cig_imp_19 as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_imp_19)
wnd_cig_imp_19.count()

# COMMAND ----------

wnd_cig_imp_19.registerTempTable('wnd_cig_imp_19')

wnd_cig_vis_imp_19 = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w2.VIS_DIS
FROM wnd_cig_imp_19 as w1 FULL JOIN weather_vis_imp_19 as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_imp_19)
wnd_cig_vis_imp_19.count()

# COMMAND ----------

wnd_cig_vis_imp_19.registerTempTable('wnd_cig_vis_imp_19')

wnd_cig_vis_tmp_imp_19 = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w1.VIS_DIS, w2.TMP_DEGREE
FROM wnd_cig_vis_imp_19 as w1 FULL JOIN weather_tmp_imp_19 as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_tmp_imp_19)
wnd_cig_vis_tmp_imp_19.count()

# COMMAND ----------

wnd_cig_vis_tmp_imp_19.registerTempTable('wnd_cig_vis_tmp_imp_19')

wnd_cig_vis_tmp_dew_imp_19 = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w1.VIS_DIS, 
  w1.TMP_DEGREE, w2.DEW_DEGREE
FROM wnd_cig_vis_tmp_imp_19 as w1 FULL JOIN weather_dew_imp_19 as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(wnd_cig_vis_tmp_dew_imp_19)
wnd_cig_vis_tmp_dew_imp_19.count()

# COMMAND ----------

wnd_cig_vis_tmp_dew_imp_19.registerTempTable('wnd_cig_vis_tmp_dew_imp_19')

weather_imputed_19 = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, coalesce(w1.country, w2.country) as COUNTRY, w1.WND_SPEED, w1.CIG_HEIGHT, w1.VIS_DIS, w1.TMP_DEGREE, 
  w1.DEW_DEGREE, w2.SLP_PRESSURE
FROM wnd_cig_vis_tmp_dew_imp_19 as w1 FULL JOIN weather_slp_imp_19 as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL AND w1.country == w2.country
""")

display(weather_imputed_19)
weather_imputed_19.count()

# COMMAND ----------

weather_imputed_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_imputed_19")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC **Next Steps**
# MAGIC - Join airlines with aiport_meta to get ORIGIN_STATION and DEST_STATION
# MAGIC - Compute ORIGIN_WEATHER_HELPER and DEST_WEATHER_HELPER to get max dates
# MAGIC - Join back to airlines to add max dates columns
# MAGIC - Do final join just for test data to map to weather 2 hours prior
# MAGIC - Save dataset to new path and then use in Train_Val_Test Imputation notebook for rest of imputation

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Join Airlines With New Weather Imputed 2019 Data

# COMMAND ----------

weather_imputed_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/weather_imputed_19")

display(weather_imputed_19)
weather_imputed_19.count()

# COMMAND ----------

weather_imputed_19.registerTempTable('weather_imputed_19')

# COMMAND ----------

airlines.registerTempTable('airlines')

airlines_19 = spark.sql("""
SELECT *
FROM airlines
WHERE EXTRACT(YEAR FROM ORIGIN_UTC) > 2018
""")

display(airlines_19)
airlines_19.count()

# COMMAND ----------

# Join airlines with stations to get origin station
airlines_19 = airlines_19.join(airport_meta.alias('AM'), airlines_19.ORIGIN == col('AM.IATA')).select(*airlines_19, col('AM.STATION').alias('ORIGIN_STATION'), col('AM.NAME').alias('ORIGIN_STATION_NAME'))

display(airlines_19)
airlines_19.count()

# COMMAND ----------

# Join previous table with stations to get destination station
airlines_19 = airlines_19.join(airport_meta.alias('AM'), airlines_19.DEST == col('AM.IATA')).select(*airlines_19, col('AM.STATION').alias('DEST_STATION'), col('AM.NAME').alias('DEST_STATION_NAME'))

display(airlines_19)
airlines_19.count()

# COMMAND ----------

airlines_19.registerTempTable('airlines_19')

airlines_19 = spark.sql("""
SELECT a.*, a.ORIGIN_UTC - INTERVAL 50 HOURS as ORIGIN_UTC_ADJ_MIN, a.ORIGIN_UTC - INTERVAL 2 HOURS as ORIGIN_UTC_ADJ_MAX
FROM airlines_19 as a
""")

display(airlines_19)

airlines_19.registerTempTable('airlines_19')

# COMMAND ----------

weather_origin_helper_19 = spark.sql("""
SELECT a.ORIGIN_STATION, a.ORIGIN_UTC, max(wo.DATE) as ORIGIN_MAX_DATE
        FROM airlines_19 as a, weather_imputed_19 as wo
        WHERE wo.STATION == a.ORIGIN_STATION AND wo.DATE BETWEEN a.ORIGIN_UTC_ADJ_MIN AND a.ORIGIN_UTC_ADJ_MAX
        GROUP BY a.ORIGIN_STATION, a.ORIGIN_UTC
""")

display(weather_origin_helper_19)
weather_origin_helper_19.count()

# COMMAND ----------

weather_origin_helper_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_origin_helper_19")

# COMMAND ----------

weather_dest_helper_19 = spark.sql("""
SELECT a.DEST_STATION, a.ORIGIN_UTC, max(wd.DATE) as DEST_MAX_DATE
        FROM airlines_19 as a, weather_imputed_19 as wd
        WHERE wd.STATION == a.DEST_STATION AND wd.DATE BETWEEN a.ORIGIN_UTC_ADJ_MIN AND a.ORIGIN_UTC_ADJ_MAX
        GROUP BY a.DEST_STATION, a.ORIGIN_UTC
""")

display(weather_dest_helper_19)
weather_dest_helper_19.count()

# COMMAND ----------

weather_dest_helper_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_dest_helper_19")

# COMMAND ----------

weather_origin_helper_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_origin_helper_19")

display(weather_origin_helper_19)

# COMMAND ----------

weather_dest_helper_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/helpers/weather_dest_helper_19")

display(weather_dest_helper_19)

# COMMAND ----------

airlines_final_19 = airlines_19.join(weather_origin_helper_19, [airlines_19.ORIGIN_STATION == weather_origin_helper_19.ORIGIN_STATION, airlines_19.ORIGIN_UTC == weather_origin_helper_19.ORIGIN_UTC], 'left').select(*airlines_19, weather_origin_helper_19.ORIGIN_MAX_DATE)

display(airlines_final_19)

# COMMAND ----------

airlines_final_19 = airlines_final_19.join(weather_dest_helper_19, [airlines_final_19.DEST_STATION == weather_dest_helper_19.DEST_STATION, airlines_final_19.ORIGIN_UTC == weather_dest_helper_19.ORIGIN_UTC], 'left').select(*airlines_final_19, weather_dest_helper_19.DEST_MAX_DATE)

display(airlines_final_19)
airlines_final_19.count()

# COMMAND ----------

airlines_final_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/airlines_final_19")

# COMMAND ----------

airlines_final_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/airlines_final_19")

display(airlines_final_19)

# COMMAND ----------

airlines_final_19.registerTempTable('airlines_final_19')

data_final_19 = spark.sql("""
SELECT a.*, avg(wmo.WND_SPEED) as AVG_WND_SPEED_ORIGIN, avg(wmo.CIG_HEIGHT) as AVG_CIG_HEIGHT_ORIGIN, 
       min(wmo.CIG_HEIGHT) as MIN_CIG_HEIGHT_ORIGIN, avg(wmo.VIS_DIS) as AVG_VIS_DIS_ORIGIN, 
       min(wmo.VIS_DIS) as MIN_VIS_DIS_ORIGIN, avg(wmo.TMP_DEGREE) as AVG_TMP_DEG_ORIGIN,   
       avg(wmo.DEW_DEGREE) as AVG_DEW_DEG_ORIGIN, avg(wmo.SLP_PRESSURE) as AVG_SLP_ORIGIN, 
       avg(wmd.WND_SPEED) as AVG_WND_SPEED_DEST, avg(wmd.CIG_HEIGHT) as AVG_CIG_HEIGHT_DEST, 
       min(wmd.CIG_HEIGHT) as MIN_CIG_HEIGHT_DEST, avg(wmd.VIS_DIS) as AVG_VIS_DIS_DEST, 
       min(wmd.VIS_DIS) as MIN_VIS_DIS_DEST, avg(wmd.TMP_DEGREE) as AVG_TMP_DEG_DEST, 
       avg(wmd.DEW_DEGREE) as AVG_DEW_DEG_DEST, avg(wmd.SLP_PRESSURE) as AVG_SLP_DEST
FROM airlines_final_19 as a 
  LEFT JOIN weather_imputed_19 as wmo 
    ON a.ORIGIN_STATION == wmo.STATION AND wmo.DATE == a.ORIGIN_MAX_DATE
  LEFT JOIN weather_imputed_19 as wmd 
    ON a.DEST_STATION == wmd.STATION AND wmd.DATE == a.DEST_MAX_DATE
GROUP BY a.YEAR, a.QUARTER, a.MONTH, a.DAY_OF_MONTH, a.DAY_OF_WEEK, a.FL_DATE, a.OP_UNIQUE_CARRIER,
         a.OP_CARRIER_AIRLINE_ID, a.OP_CARRIER, a.TAIL_NUM, a.OP_CARRIER_FL_NUM, a.ORIGIN_AIRPORT_ID, 
         a.ORIGIN_AIRPORT_SEQ_ID, a.ORIGIN_CITY_MARKET_ID, a.ORIGIN, a.ORIGIN_CITY_NAME, a.ORIGIN_STATE_ABR,
         a.ORIGIN_STATE_FIPS, a.ORIGIN_STATE_NM, a.ORIGIN_WAC, a.DEST_AIRPORT_ID, a.DEST_AIRPORT_SEQ_ID,
         a.DEST_CITY_MARKET_ID, a.DEST, a.DEST_CITY_NAME, a.DEST_STATE_ABR, a.DEST_STATE_FIPS, a.DEST_STATE_NM, 
         a.DEST_WAC, a.CRS_DEP_TIME, a.DEP_TIME, a.DEP_DELAY, a.DEP_DELAY_NEW, a.DEP_DEL15, a.DEP_DELAY_GROUP,
         a.DEP_TIME_BLK, a.TAXI_OUT, a.WHEELS_OFF, a.WHEELS_ON, a.TAXI_IN, a.CRS_ARR_TIME, a.ARR_TIME,
         a.ARR_DELAY, a.ARR_DELAY_NEW, a.ARR_DEL15, a.ARR_DELAY_GROUP, a.ARR_TIME_BLK, a.CANCELLED, a.DIVERTED,
         a.CRS_ELAPSED_TIME, a.ACTUAL_ELAPSED_TIME, a.AIR_TIME, a.FLIGHTS, a.DISTANCE, a.DISTANCE_GROUP,
         a.DIV_AIRPORT_LANDINGS, a.ORIGIN_TZ, a.DEST_TZ, a.DEP_MIN, a.DEP_HOUR, a.ARR_MIN, a.ARR_HOUR, a.ORIGIN_TS,
         a.ORIGIN_UTC, a.DEST_TS, a.DEST_UTC, a.ORIGIN_FLIGHT_COUNT, a.DEST_FLIGHT_COUNT, a.ORIGIN_STATION, 
         a.ORIGIN_STATION_NAME, a.DEST_STATION, a.DEST_STATION_NAME, a.ORIGIN_UTC_ADJ_MIN,
         a.ORIGIN_UTC_ADJ_MAX, a.ORIGIN_MAX_DATE, a.DEST_MAX_DATE
""")

display(data_final_19)
data_final_19.count()

# COMMAND ----------

data_final_19.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final_19")

# COMMAND ----------

data_19 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/data_final_19")

display(data_19)

# COMMAND ----------

data_19.filter("AVG_WND_SPEED_ORIGIN is null AND AVG_CIG_HEIGHT_ORIGIN is null AND MIN_CIG_HEIGHT_ORIGIN is null AND AVG_VIS_DIS_ORIGIN is null AND MIN_VIS_DIS_ORIGIN is null AND AVG_TMP_DEG_ORIGIN is null AND AVG_DEW_DEG_ORIGIN is null AND AVG_SLP_ORIGIN is null AND AVG_WND_SPEED_DEST is null AND AVG_CIG_HEIGHT_DEST is null AND MIN_CIG_HEIGHT_DEST is null AND AVG_VIS_DIS_DEST is null AND MIN_VIS_DIS_DEST is null AND AVG_TMP_DEG_DEST is null AND AVG_DEW_DEG_DEST is null AND AVG_SLP_DEST is null").count()

# COMMAND ----------

data_19.filter("AVG_WND_SPEED_ORIGIN is not null AND AVG_CIG_HEIGHT_ORIGIN is not null AND MIN_CIG_HEIGHT_ORIGIN is not null AND AVG_VIS_DIS_ORIGIN is not null AND MIN_VIS_DIS_ORIGIN is not null AND AVG_TMP_DEG_ORIGIN is not null AND AVG_DEW_DEG_ORIGIN is not null AND AVG_SLP_ORIGIN is not null AND AVG_WND_SPEED_DEST is not null AND AVG_CIG_HEIGHT_DEST is not null AND MIN_CIG_HEIGHT_DEST is not null AND AVG_VIS_DIS_DEST is not null AND MIN_VIS_DIS_DEST is not null AND AVG_TMP_DEG_DEST is not null AND AVG_DEW_DEG_DEST is not null AND AVG_SLP_DEST is not null").count()

# COMMAND ----------

data_19.filter("AVG_WND_SPEED_ORIGIN is null OR AVG_CIG_HEIGHT_ORIGIN is null OR MIN_CIG_HEIGHT_ORIGIN is null OR AVG_VIS_DIS_ORIGIN is null OR MIN_VIS_DIS_ORIGIN is null OR AVG_TMP_DEG_ORIGIN is null OR AVG_DEW_DEG_ORIGIN is null OR AVG_SLP_ORIGIN is null OR AVG_WND_SPEED_DEST is null OR AVG_CIG_HEIGHT_DEST is null OR MIN_CIG_HEIGHT_DEST is null OR AVG_VIS_DIS_DEST is null OR MIN_VIS_DIS_DEST is null OR AVG_TMP_DEG_DEST is null OR AVG_DEW_DEG_DEST is null OR AVG_SLP_DEST is null").count()

# COMMAND ----------


