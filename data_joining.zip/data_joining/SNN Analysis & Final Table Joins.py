# Databricks notebook source
pip install haversine

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np

import pandas as pd, matplotlib.pyplot as plt
import matplotlib.cm as cm, matplotlib.font_manager as fm
from datetime import datetime as dt
from sklearn.cluster import DBSCAN

from haversine import haversine, Unit
import plotly.graph_objects as go
import plotly.express as px

sqlContext = SQLContext(sc)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC <h1>Scratch Code</h1>

# COMMAND ----------

testing1 = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc")

display(testing1)

# COMMAND ----------

stations = spark.read.option("header", "true").csv("dbfs:/mnt/mids-w261/DEMO8/gsod/stations.csv.gz")
display(stations)

# COMMAND ----------

stations = stations.filter("country == 'US'")
display(stations)

# COMMAND ----------

stations_map = stations.select(concat(col("usaf"), col("wban")).alias("station_id"), col("lat"), col("lon"), col("name")).distinct().where(col("lat").isNotNull()).where(col("lon").isNotNull())
display(stations_map)

# COMMAND ----------

stations_map = stations_map.toPandas()
stations_map

# COMMAND ----------

fig = go.Figure(data=go.Scattergeo(
        lon = stations_map['lon'],
        lat = stations_map['lat'],
        text = stations_map['name'],
        mode = 'markers',
#         fillcolor = 'blue',
))

fig.update_layout(
        title = 'US Weather Stations',
        width = 1500,
        height = 1500,
        geo_scope ='usa',
)

fig.show()

# COMMAND ----------

locations = stations.select(concat(col("usaf"), col("wban")).alias("station_id"), col("lat"), col("lon")).distinct().where(col("lat").isNotNull()).where(col("lon").isNotNull())
display(locations)

# COMMAND ----------

locations = locations.toPandas()
locations

# COMMAND ----------

coords = []

for long, lat, station_id in zip(locations['lat'], locations['lon'], locations['station_id']):
    coords.append((float(lat),float(long), station_id))
    
# coords = np.array(coords).astype(float)
print(coords)

# COMMAND ----------

from itertools import combinations

coords_list = []

for combo in combinations(coords, 2):  # 2 for pairs, 3 for triplets, etc
    coords_list.append(combo)

# COMMAND ----------

coords_rdd = sc.parallelize(coords_list)
coords_rdd.count()

# COMMAND ----------

# Calculate havesine distance between origin and destination
def calcHaversine(x):
    origin, dest = x[0], x[1]
    dest_dict = {}
    dist = haversine(origin[:2], dest[:2], unit=Unit.MILES)
    dest_dict[dest] = dist
    return (origin, dest_dict)

# Combine dictionaries
def updateDict(x, y):
    x.update(y)
    return x

# Map each station to every other station and compute distances between each
result = coords_rdd.map(lambda x: calcHaversine(x)) \
                   .reduceByKey(lambda x, y: updateDict(x, y)).cache()

result.collect()

# COMMAND ----------

# Find all neighboring stations within a 50 mile radius
def getStationNeighbors(x):
    origin, dest = x[0], x[1]
    yield (origin[2], origin[2])
    sorted_list = [str(i[0][2]) for i in filter(lambda x: x[1] <= 50.0, sorted(dest.items(), key=lambda x: x[1])[:5])]
    
    for i in sorted_list:
        yield(origin[2], i)

# Map each station to its neighbors including itself
clusters = result.flatMap(lambda x: getStationNeighbors(x)).cache()

clusters.collect()

# COMMAND ----------

station_neighbors = spark.createDataFrame(clusters).toDF("station_id", "neighbor_id")
display(station_neighbors)

# COMMAND ----------

display(station_neighbors.filter("station_id == '99999903755'"))

# COMMAND ----------

station_neighbors.count()

# COMMAND ----------

weather = spark.read.option("header", "true")\
                    .parquet(f"dbfs:/mnt/mids-w261/datasets_final_project/weather_data/*.parquet")

display(weather)

# COMMAND ----------

weather = weather.select(year(col("DATE")).alias("YEAR"), month(col("DATE")).alias("MONTH"), dayofmonth(col("DATE")).alias("DAY_OF_MONTH"), concat(rpad(lpad(hour(col("DATE")), 2, '0'), 4, '0'), lit('-'), lpad(hour(col("DATE")), 2, '0'), lit('59')).alias('HOUR_BLOCK'), *weather)
display(weather)

# COMMAND ----------

cleaned_weather = weather.join(stations, concat(col("usaf"), col("wban")) == weather.STATION).filter(weather.DATE.between(to_timestamp(stations.begin, 'yyyyMMdd'), to_timestamp(stations.end, 'yyyyMMdd') + expr("INTERVAL 24 hours"))).select(*weather)

display(cleaned_weather)

# COMMAND ----------

station_neighbors.registerTempTable('station_neighbors')
cleaned_weather.registerTempTable('cleaned_weather')

# COMMAND ----------

weather_avg = spark.sql("SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, min(w2.WND) FROM cleaned_weather as w1, station_neighbors as sn, cleaned_weather as w2 WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) AND w2.REPORT_TYPE == w1.REPORT_TYPE AND w2.STATION == sn.neighbor_id AND w1.REPORT_TYPE == 'FM-15' GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL")

display(weather_avg)

# COMMAND ----------

test27.count()

# COMMAND ----------

cleaned_weather.filter("REPORT_TYPE == 'FM-15'").count()

# COMMAND ----------

testing1 = spark.sql("SELECT REPORT_TYPE, count(REPORT_TYPE) FROM cleaned_weather GROUP BY REPORT_TYPE")
display(testing1)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC <h1>Finalized Tables</h1>

# COMMAND ----------

airlines_final = weather = spark.read.option("header", "true")\
                    .parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc")

display(airlines_final)

# COMMAND ----------

# 1) Join Station and US_Stations helper table
stations_final = stations.join(us_stations_all.alias('uss'), stations.call == col('uss.ICAO')).select(*stations, col('uss.IATA').alias('IATA'))

# COMMAND ----------

# 2) Get all of the station neighbors
locations = stations.select(concat(col("usaf"), col("wban")).alias("station_id"), col("lat"), col("lon")).distinct().where(col("lat").isNotNull()).where(col("lon").isNotNull())
display(locations)

###

locations = locations.toPandas()
locations

###
coords = []

for long, lat, station_id in zip(locations['lat'], locations['lon'], locations['station_id']):
    coords.append((float(lat),float(long), station_id))
    
# coords = np.array(coords).astype(float)
print(coords)

###
from itertools import combinations

coords_list = []

for combo in combinations(coords, 2):  # 2 for pairs, 3 for triplets, etc
    coords_list.append(combo)
    
###

coords_rdd = sc.parallelize(coords_list)
coords_rdd.count()

###

def calcHaversine(x):
    origin, dest = x[0], x[1]
    dest_dict = {}
    dist = haversine(origin[:2], dest[:2], unit=Unit.MILES)
    dest_dict[dest] = dist
    return (origin, dest_dict)
  
def updateDict(x, y):
    x.update(y)
    return x

result = coords_rdd.map(lambda x: calcHaversine(x)) \
                   .reduceByKey(lambda x, y: updateDict(x, y)).cache()

result.collect()

###

def getStationNeighbors(x):
    origin, dest = x[0], x[1]
    yield (origin[2], origin[2])
    sorted_list = [str(i[0][2]) for i in filter(lambda x: x[1] <= 50.0, sorted(dest.items(), key=lambda x: x[1])[:5])]
#     sorted_list = [str(i[0][2]) for i in sorted(dest.items(), key=lambda x: x[1])[:5]]
    for i in sorted_list:
        yield(origin[2], i)

clusters = result.flatMap(lambda x: getStationNeighbors(x)).cache()

clusters.collect()

###

station_neighbors = spark.createDataFrame(clusters).toDF("station_id", "neighbor_id")
display(station_neighbors)
station_neighbors.count()

###

# COMMAND ----------

# 3) Create the Average Weather Table
station_neighbors.registerTempTable('station_neighbors')
cleaned_weather_final.registerTempTable('cleaned_weather') # Use finalized weather table

weather_avg_final = spark.sql(
  """SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, min(w2.WND) 
     FROM cleaned_weather as w1, station_neighbors as sn, cleaned_weather as w2 
     WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
     AND w2.REPORT_TYPE == w1.REPORT_TYPE AND w2.STATION == sn.neighbor_id AND w1.REPORT_TYPE == 'FM-15' 
     GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""") ## UPDATE to avg() for all necessary metric columns

display(weather_avg_final)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC <h1>Perform ALL Table JOINS</h1>

# COMMAND ----------

# Join airlines with stations to get origin station
airline_stations = airlines_final.join(stations_final.alias('SO'), airlines_final.ORIGIN == col('SO.IATA')).select(*airlines_final, col('SO.STATION').alias('ORIGIN_STATION'))

# COMMAND ----------

# Join previous with stations to get destination station
airline_stations = airline_stations.join(stations_final.alias('SD'), airline_stations.DEST == col('SD.IATA')).select(*airline_stations, col('SD.STATION').alias('DEST_STATION'))

# COMMAND ----------

# Join previous with avg_weather for origin and destination

"SELECT a.*, awo.avg_wind, awd.avg_wind \
   FROM airline_stations a \
       ,avg_weather awo \
       ,avg_weather awd \
  where a.origin_station = awo.station \
    and a.des_station = awd.station \
    and awo.date = (select max(awo1.date) \
                      from avg_weather awo1 \
                     where awo1.station = awo.station \
                       and awo1.date <= a.dep_utc) \
    and awd.date = (select max(awo2.date) \
                      from avg_weather awo2 \
                     where awo2.station = awo.station \
                       and awo2.date <= a.dep_utc)    
"
