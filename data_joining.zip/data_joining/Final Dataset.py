# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC #Final Tables

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr
import numpy as np

import pandas as pd, matplotlib.pyplot as plt
import matplotlib.cm as cm, matplotlib.font_manager as fm
from datetime import datetime as dt
# from sklearn.cluster import DBSCAN

# from haversine import haversine, Unit

sqlContext = SQLContext(sc)

# COMMAND ----------

airlines_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_latest_utc")
display(airlines_final)

# COMMAND ----------

airlines_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/airlines/airlines_final")
display(airlines_final)

# COMMAND ----------

airlines_final.count()

# COMMAND ----------

airlines_final.registerTempTable("airlines_final")

display(spark.sql("SELECT ORIGIN FROM airlines_final UNION SELECT DEST FROM airlines_final"))

# COMMAND ----------

weather_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/weather/weather_final_13_Nov")
display(weather_final)

# COMMAND ----------

display(weather_final.filter("YEAR == 2016 AND MONTH == 6 AND DAY_OF_MONTH == 27 AND EXTRACT(HOUR FROM DATE) == 15 AND STATION == '72645014898'"))

# COMMAND ----------

weather_final.count()

# COMMAND ----------

station_neighbors_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/station_neighbors")
display(station_neighbors_final)

# COMMAND ----------

station_neighbors_final.count()

# COMMAND ----------

station_neighbors_final.select("station_id").distinct().count()

# COMMAND ----------

airport_meta_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/station/airport_meta")
display(airport_meta_final)

# COMMAND ----------

airport_meta_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #Average Weather Table

# COMMAND ----------

station_neighbors_final.registerTempTable('station_neighbors_final')
weather_final.registerTempTable('weather_final')

# COMMAND ----------

weather_final.join(station_neighbors_final, weather_final.STATION == station_neighbors_final.station_id).select(*weather_final).distinct().count() # Total Count

# COMMAND ----------

average_weather = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, avg(w2.WND_Speed) 
                        FROM weather_final as w1, station_neighbors_final as sn, weather_final as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.WND_Speed_Qlty == '5'
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""")

display(average_weather)

# COMMAND ----------

average_weather.count()

# COMMAND ----------

average_weather_wnd = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, avg(w2.WND_Speed) as AVG_WND_SPEED
                        FROM weather_final as w1, station_neighbors_final as sn, weather_final as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.WND_Speed_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""")

display(average_weather_wnd)

# COMMAND ----------

average_weather_wnd.count() # 11 rows missing because none of its neighbors including itself have good quality data

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/mids-w261/team20SSDK/"))

# COMMAND ----------

average_weather_wnd.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/average_weather_wnd")

# COMMAND ----------

weather_height_min = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, min(w2.CIG_Height) as MIN_CIG_HEIGHT
                        FROM weather_final as w1, station_neighbors_final as sn, weather_final as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.CIG_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""")

display(weather_height_min)

# COMMAND ----------

weather_height_min.count() # Missing 94 rows

# COMMAND ----------

weather_height_min.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_height_min")

# COMMAND ----------

weather_vis_min = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, min(w2.VIS_Dis) as MIN_VIS_DIS
                        FROM weather_final as w1, station_neighbors_final as sn, weather_final as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.VIS_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""")

display(weather_vis_min)

# COMMAND ----------

weather_vis_min.count() # Missing 31 rows

# COMMAND ----------

weather_vis_min.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_vis_min")

# COMMAND ----------

weather_tmp_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, avg(w2.TMP_Degree) as AVG_TMP_DEG
                        FROM weather_final as w1, station_neighbors_final as sn, weather_final as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.TMP_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""")

display(weather_tmp_avg)

# COMMAND ----------

weather_tmp_avg.count() # Missing 283 rows

# COMMAND ----------

weather_tmp_avg.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_tmp_avg")

# COMMAND ----------

weather_dew_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, avg(w2.DEW_Degree) as AVG_DEW_DEG
                        FROM weather_final as w1, station_neighbors_final as sn, weather_final as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.DEW_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""")

display(weather_dew_avg)

# COMMAND ----------

weather_dew_avg.count() # Missing 109 rows

# COMMAND ----------

weather_dew_avg.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_dew_avg")

# COMMAND ----------

weather_slp_avg = spark.sql("""SELECT w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, 
                        w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL, avg(w2.SLP_Pressure) as AVG_SLP
                        FROM weather_final as w1, station_neighbors_final as sn, weather_final as w2 
                        WHERE w1.STATION == sn.station_id AND w2.YEAR == w1.YEAR AND w2.MONTH == w1.MONTH AND w2.DAY_OF_MONTH == w1.DAY_OF_MONTH AND EXTRACT(HOUR FROM w2.DATE) == EXTRACT(HOUR FROM w1.DATE) 
                        AND w2.STATION == sn.neighbor_id AND w2.SLP_Qlty NOT IN ('2', '3', '6', '7')
                        GROUP BY w1.YEAR, w1.MONTH, w1.DAY_OF_MONTH, w1.STATION, w1.DATE, w1.SOURCE, w1.LATITUDE, w1.LONGITUDE, w1.ELEVATION, w1.NAME, w1.REPORT_TYPE, w1.CALL_SIGN, w1.QUALITY_CONTROL""")

display(weather_slp_avg)

# COMMAND ----------

weather_slp_avg.count() # Missing 239 rows

# COMMAND ----------

weather_slp_avg.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_slp_avg")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Join All Weather Metrics

# COMMAND ----------

average_weather_wnd.registerTempTable('average_weather_wnd')
weather_height_min.registerTempTable('weather_height_min')
weather_vis_min.registerTempTable('weather_vis_min')
weather_tmp_avg.registerTempTable('weather_tmp_avg')
weather_dew_avg.registerTempTable('weather_dew_avg')
weather_slp_avg.registerTempTable('weather_slp_avg')

# COMMAND ----------

wnd_height = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, w1.AVG_WND_SPEED, w2.MIN_CIG_HEIGHT
FROM average_weather_wnd as w1 FULL JOIN weather_height_min as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL
""")

display(wnd_height)

# COMMAND ----------

wnd_height.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wnd_height")

# COMMAND ----------

wnd_height.registerTempTable('wnd_height')

wnd_height_vis = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, w1.AVG_WND_SPEED, w1.MIN_CIG_HEIGHT, w2.MIN_VIS_DIS
FROM wnd_height as w1 FULL JOIN weather_vis_min as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL
""")

display(wnd_height_vis)

# COMMAND ----------

wnd_height_vis.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wnd_height_vis")

# COMMAND ----------

wnd_height_vis.registerTempTable('wnd_height_vis')

wnd_height_vis_tmp = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, w1.AVG_WND_SPEED, w1.MIN_CIG_HEIGHT, w1.MIN_VIS_DIS, w2.AVG_TMP_DEG
FROM wnd_height_vis as w1 FULL JOIN weather_tmp_avg as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL
""")

display(wnd_height_vis_tmp)

# COMMAND ----------

wnd_height_vis_tmp.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wnd_height_vis_tmp")

# COMMAND ----------

wnd_height_vis_tmp.registerTempTable('wnd_height_vis_tmp')

wnd_height_vis_tmp_dew = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, w1.AVG_WND_SPEED, w1.MIN_CIG_HEIGHT, w1.MIN_VIS_DIS, 
  w1.AVG_TMP_DEG, w2.AVG_DEW_DEG
FROM wnd_height_vis_tmp as w1 FULL JOIN weather_dew_avg as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL
""")

display(wnd_height_vis_tmp_dew)

# COMMAND ----------

wnd_height_vis_tmp_dew.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wnd_height_vis_tmp_dew")

# COMMAND ----------

wnd_height_vis_tmp_dew.registerTempTable('wnd_height_vis_tmp_dew')

weather_metrics_final = spark.sql("""
SELECT coalesce(w1.YEAR, w2.YEAR) as YEAR, coalesce(w1.MONTH, w2.MONTH) as MONTH, coalesce(w1.DAY_OF_MONTH, w2.DAY_OF_MONTH) as DAY_OF_MONTH, 
  coalesce(w1.STATION, w2.STATION) as STATION, coalesce(w1.DATE, w2.DATE) as DATE, coalesce(w1.SOURCE, w2.SOURCE) as SOURCE, 
  coalesce(w1.LATITUDE, w2.LATITUDE) as LATITUDE, coalesce(w1.LONGITUDE, w2.LONGITUDE) as LONGITUDE, 
  coalesce(w1.ELEVATION, w2.ELEVATION) as ELEVATION, coalesce(w1.NAME, w2.NAME) as NAME, 
  coalesce(w1.REPORT_TYPE, w2.REPORT_TYPE) as REPORT_TYPE, coalesce(w1.CALL_SIGN, w2.CALL_SIGN) as CALL_SIGN, 
  coalesce(w1.QUALITY_CONTROL, w2.QUALITY_CONTROL) as QUALITY_CONTROL, w1.AVG_WND_SPEED, w1.MIN_CIG_HEIGHT, w1.MIN_VIS_DIS, w1.AVG_TMP_DEG, 
  w1.AVG_DEW_DEG, w2.AVG_SLP
FROM wnd_height_vis_tmp_dew as w1 FULL JOIN weather_slp_avg as w2
ON w1.YEAR == w2.YEAR AND w1.MONTH == w2.MONTH AND w1.DAY_OF_MONTH == w2.DAY_OF_MONTH AND w1.STATION == w2.STATION AND 
  w1.DATE == w2.DATE AND w1.SOURCE == w2.SOURCE AND w1.LATITUDE == w2.LATITUDE AND w1.LONGITUDE == w2.LONGITUDE AND 
  w1.ELEVATION == w2.ELEVATION AND w1.NAME == w2.NAME AND w1.REPORT_TYPE == w2.REPORT_TYPE AND 
  w1.CALL_SIGN == w2.CALL_SIGN AND w1.QUALITY_CONTROL == w2.QUALITY_CONTROL
""")

display(weather_metrics_final)

# COMMAND ----------

weather_metrics_simple_final = spark.sql("""
SELECT w.YEAR, w.MONTH, w.DAY_OF_MONTH, EXTRACT(HOUR FROM w.DATE) as HOUR, w.STATION, w.SOURCE, w.LATITUDE, w.LONGITUDE, w.ELEVATION, w.NAME, w.REPORT_TYPE, w.CALL_SIGN, w.QUALITY_CONTROL
      ,avg(w.AVG_WND_SPEED) as AVG_WND_SPEED, min(w.MIN_CIG_HEIGHT) as MIN_CIG_HEIGHT, min(w.MIN_VIS_DIS) as MIN_VIS_DIS, avg(w.AVG_TMP_DEG) as AVG_TMP_DEG, avg(w.AVG_DEW_DEG) as AVG_DEW_DEG, avg(w.AVG_SLP) as AVG_SLP
FROM weather_metrics_final as w
GROUP BY w.YEAR, w.MONTH, w.DAY_OF_MONTH, EXTRACT(HOUR FROM w.DATE), w.STATION, w.SOURCE, w.LATITUDE, w.LONGITUDE, w.ELEVATION, w.NAME, w.REPORT_TYPE, w.CALL_SIGN, w.QUALITY_CONTROL
""")

display(weather_metrics_simple_final)

# COMMAND ----------

weather_metrics_simple_final.count()

# COMMAND ----------

weather_metrics_simple_final.registerTempTable('weather_metrics_simple_final')

# COMMAND ----------

weather_metrics_simple_final.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_metrics_simple_final")

# COMMAND ----------

weather_metrics_final.count()

# COMMAND ----------

weather_metrics_final.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_metrics_final")

# COMMAND ----------

weather_metrics_final.registerTempTable('weather_metrics_final')

# COMMAND ----------

weather_metrics_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_metrics_final")

display(weather_metrics_final)

# COMMAND ----------

airlines_final = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final")

display(airlines_final)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #Full Table Joins

# COMMAND ----------

# Join airlines with stations to get origin station
airlines_final = airlines_final.join(airport_meta_final.alias('AM'), airlines_final.ORIGIN == col('AM.IATA')).select(*airlines_final, col('AM.STATION').alias('ORIGIN_STATION'), col('AM.NAME').alias('ORIGIN_STATION_NAME'), col('AM.pagerank').alias('PAGERANK'))

display(airlines_final)

# COMMAND ----------

# Join previous with stations to get destination station
airlines_final = airlines_final.join(airport_meta_final.alias('AM'), airlines_final.DEST == col('AM.IATA')).select(*airlines_final, col('AM.STATION').alias('DEST_STATION'), col('AM.NAME').alias('DEST_STATION_NAME'))

display(airlines_final)

# COMMAND ----------

airlines_final = spark.sql("""
SELECT a.*, a.ORIGIN_UTC - INTERVAL 50 HOURS as ORIGIN_UTC_ADJ_MIN, a.ORIGIN_UTC - INTERVAL 2 HOURS as ORIGIN_UTC_ADJ_MAX
FROM airlines_final as a
""")

display(airlines_final)

# COMMAND ----------

# dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final", True)
# airlines_final.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final")
airlines_final.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_range_final")

# COMMAND ----------

airlines_final.count()

# COMMAND ----------

airlines_final.registerTempTable('airlines_final')

# COMMAND ----------

weather_origin_helper = spark.sql("""
SELECT a2.ORIGIN_STATION, a2.ORIGIN_UTC, max(wo.DATE) as origin_max_date
        FROM airlines_final as a2, weather_metrics_final as wo
        WHERE wo.STATION == a2.ORIGIN_STATION AND wo.DATE <= a2.ORIGIN_UTC_ADJ
        GROUP BY a2.ORIGIN_STATION, a2.ORIGIN_UTC
""")

display(weather_origin_helper)

# COMMAND ----------

weather_origin_helper = spark.sql("""
SELECT a2.ORIGIN_STATION, a2.ORIGIN_UTC, max(wo.DATE) as ORIGIN_MAX_DATE
        FROM airlines_final as a2, weather_metrics_final as wo
        WHERE wo.STATION == a2.ORIGIN_STATION AND wo.DATE BETWEEN a2.ORIGIN_UTC_ADJ_MIN AND a2.ORIGIN_UTC_ADJ_MAX
        GROUP BY a2.ORIGIN_STATION, a2.ORIGIN_UTC
""")

display(weather_origin_helper)

# COMMAND ----------

weather_origin_helper.count()

# COMMAND ----------

# dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/woh_range", True)
# woh_head = weather_origin_helper.head()
# woh_head.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_origin_helper")
# weather_origin_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_origin_helper")
weather_origin_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/woh_range")

# COMMAND ----------

weather_origin_helper.count()

# COMMAND ----------

weather_dest_helper = spark.sql("""
SELECT a2.DEST_STATION, a2.ORIGIN_UTC, max(wo.DATE) as dest_max_date
        FROM airlines_final as a2, weather_metrics_final as wo
        WHERE wo.STATION == a2.DEST_STATION AND wo.DATE <= a2.ORIGIN_UTC_ADJ
        GROUP BY a2.DEST_STATION, a2.ORIGIN_UTC
""")

display(weather_dest_helper)

# COMMAND ----------

weather_dest_helper = spark.sql("""
SELECT a2.DEST_STATION, a2.ORIGIN_UTC, max(wo.DATE) as DEST_MAX_DATE
        FROM airlines_final as a2, weather_metrics_final as wo
        WHERE wo.STATION == a2.DEST_STATION AND wo.DATE BETWEEN a2.ORIGIN_UTC_ADJ_MIN AND a2.ORIGIN_UTC_ADJ_MAX
        GROUP BY a2.DEST_STATION, a2.ORIGIN_UTC
""")

display(weather_dest_helper)

# COMMAND ----------

# dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wdh_range", True)
# weather_dest_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/weather_dest_helper")
weather_dest_helper.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wdh_range")

# COMMAND ----------

weather_dest_helper.count()

# COMMAND ----------

weather_dest_helper.count()

# COMMAND ----------

weather_origin_helper = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/woh_range")

display(weather_origin_helper)

# COMMAND ----------

weather_dest_helper = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/wdh_range")

display(weather_dest_helper)

# COMMAND ----------

weather_origin_helper.registerTempTable('weather_origin_helper')
weather_dest_helper.registerTempTable('weather_dest_helper')

# COMMAND ----------

airlines_woh = airlines_final.join(weather_origin_helper, [airlines_final.ORIGIN_STATION == weather_origin_helper.ORIGIN_STATION, airlines_final.ORIGIN_UTC == weather_origin_helper.ORIGIN_UTC]).select(*airlines_final, weather_origin_helper.ORIGIN_MAX_DATE)

display(airlines_woh)

# COMMAND ----------

airlines_woh.count()

# COMMAND ----------

airlines_woh.count()

# COMMAND ----------

airlines_final_new = airlines_woh.join(weather_dest_helper, [airlines_woh.DEST_STATION == weather_dest_helper.DEST_STATION, airlines_woh.ORIGIN_UTC == weather_dest_helper.ORIGIN_UTC]).select(*airlines_woh, weather_dest_helper.DEST_MAX_DATE)

display(airlines_final_new)

# COMMAND ----------

# airlines_final_new.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final_new")
# dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final_new_range", True)
airlines_final_new.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/airlines_final_new_range")

# COMMAND ----------

airlines_final_new.count()

# COMMAND ----------

airlines_final_new.count()

# COMMAND ----------

airlines_final_new.registerTempTable('airlines_final_new')

# COMMAND ----------

data_final_max = spark.sql("""
SELECT a.*, wmo.AVG_WND_SPEED as AVG_WND_SPEED_ORIGIN, wmo.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_ORIGIN, 
       wmo.MIN_VIS_DIS as MIN_VIS_DIS_ORIGIN, wmo.AVG_TMP_DEG as AVG_TMP_DEG_ORIGIN,   
       wmo.AVG_DEW_DEG as AVG_DEW_DEG_ORIGIN, wmo.AVG_SLP as AVG_SLP_ORIGIN, wmd.AVG_WND_SPEED as AVG_WND_SPEED_DEST, 
       wmd.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_DEST, wmd.MIN_VIS_DIS as MIN_VIS_DIS_DEST, 
       wmd.AVG_TMP_DEG as AVG_TMP_DEG_DEST, wmd.AVG_DEW_DEG as AVG_DEW_DEG_DEST, wmd.AVG_SLP as AVG_SLP_DEST
FROM airlines_final_new as a, weather_metrics_final as wmo, weather_metrics_final as wmd
WHERE a.ORIGIN_STATION == wmo.STATION
  AND a.DEST_STATION == wmd.STATION
  AND wmo.DATE == a.origin_max_date
  AND wmd.DATE == a.dest_max_date
""")

display(data_final_max)

# COMMAND ----------

data_final_max.count()

# COMMAND ----------

data_final_range.count()

# COMMAND ----------

# data_final_max.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/data")
# data_final_range.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/cleaned_data/final/data_final_range")
data_final_range.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/final_datasets/data_range")

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/mids-w261/team20SSDK/final_datasets"))

# COMMAND ----------

data_final_range = spark.sql("""
SELECT a.*, wmo.AVG_WND_SPEED as AVG_WND_SPEED_ORIGIN, wmo.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_ORIGIN, 
       wmo.MIN_VIS_DIS as MIN_VIS_DIS_ORIGIN, wmo.AVG_TMP_DEG as AVG_TMP_DEG_ORIGIN,   
       wmo.AVG_DEW_DEG as AVG_DEW_DEG_ORIGIN, wmo.AVG_SLP as AVG_SLP_ORIGIN, wmd.AVG_WND_SPEED as AVG_WND_SPEED_DEST, 
       wmd.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_DEST, wmd.MIN_VIS_DIS as MIN_VIS_DIS_DEST, 
       wmd.AVG_TMP_DEG as AVG_TMP_DEG_DEST, wmd.AVG_DEW_DEG as AVG_DEW_DEG_DEST, wmd.AVG_SLP as AVG_SLP_DEST
FROM airlines_final_new as a, weather_metrics_final as wmo, weather_metrics_final as wmd
WHERE a.ORIGIN_STATION == wmo.STATION
  AND a.DEST_STATION == wmd.STATION
  AND wmo.DATE == a.ORIGIN_MAX_DATE
  AND wmd.DATE == a.DEST_MAX_DATE
""")

display(data_final_range)

# COMMAND ----------

len(data_final_range.columns)

# COMMAND ----------

data_final_range.filter("YEAR == 2019").count()

# COMMAND ----------

data_final_range.count()

# COMMAND ----------

data_final = spark.sql("""
SELECT a.*, wmo.AVG_WND_SPEED as AVG_WND_SPEED_ORIGIN, wmo.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_ORIGIN, 
       wmo.MIN_VIS_DIS as MIN_VIS_DIS_ORIGIN, wmo.AVG_TMP_DEG as AVG_TMP_DEG_ORIGIN,   
       wmo.AVG_DEW_DEG as AVG_DEW_DEG_ORIGIN, wmo.AVG_SLP as AVG_SLP_ORIGIN, wmd.AVG_WND_SPEED as AVG_WND_SPEED_DEST, 
       wmd.MIN_CIG_HEIGHT as MIN_CIG_HEIGHT_DEST, wmd.MIN_VIS_DIS as MIN_VIS_DIS_DEST, 
       wmd.AVG_TMP_DEG as AVG_TMP_DEG_DEST, wmd.AVG_DEW_DEG as AVG_DEW_DEG_DEST, wmd.AVG_SLP as AVG_SLP_DEST
FROM airlines_final as a, weather_metrics_final as wmo, weather_metrics_final as wmd
WHERE a.ORIGIN_STATION == wmo.STATION 
  AND a.DEST_STATION == wmd.STATION 
  AND wmo.DATE == a.ORIGIN_UTC_ADJ 
  AND wmd.DATE == a.ORIGIN_UTC_ADJ
""")

display(data_final)

# COMMAND ----------

data_final_max.registerTempTable('data_final_max')

checkdup2 = spark.sql("""
SELECT YEAR,
 QUARTER,
 MONTH,
 DAY_OF_MONTH,
 DAY_OF_WEEK,
 FL_DATE,
 OP_UNIQUE_CARRIER,
 OP_CARRIER_AIRLINE_ID,
 OP_CARRIER,
 TAIL_NUM,
 OP_CARRIER_FL_NUM,
 ORIGIN_AIRPORT_ID,
 ORIGIN_AIRPORT_SEQ_ID,
 ORIGIN_CITY_MARKET_ID,
 ORIGIN,
 ORIGIN_CITY_NAME,
 ORIGIN_STATE_ABR,
 ORIGIN_STATE_FIPS,
 ORIGIN_STATE_NM,
 ORIGIN_WAC,
 DEST_AIRPORT_ID,
 DEST_AIRPORT_SEQ_ID,
 DEST_CITY_MARKET_ID,
 DEST,
 DEST_CITY_NAME,
 DEST_STATE_ABR,
 DEST_STATE_FIPS,
 DEST_STATE_NM,
 DEST_WAC,
 CRS_DEP_TIME,
 DEP_TIME,
 DEP_DELAY,
 DEP_DELAY_NEW,
 DEP_DEL15,
 DEP_DELAY_GROUP,
 DEP_TIME_BLK,
 TAXI_OUT,
 WHEELS_OFF,
 WHEELS_ON,
 TAXI_IN,
 CRS_ARR_TIME,
 ARR_TIME,
 ARR_DELAY,
 ARR_DELAY_NEW,
 ARR_DEL15,
 ARR_DELAY_GROUP,
 ARR_TIME_BLK,
 CANCELLED,
 DIVERTED,
 CRS_ELAPSED_TIME,
 ACTUAL_ELAPSED_TIME,
 AIR_TIME,
 FLIGHTS,
 DISTANCE,
 DISTANCE_GROUP,
 DIV_AIRPORT_LANDINGS,
 ORIGIN_TZ,
 DEST_TZ,
 DEP_MIN,
 DEP_HOUR,
 ARR_MIN,
 ARR_HOUR,
 ORIGIN_TS,
 ORIGIN_UTC,
 DEST_TS,
 DEST_UTC,
 ORIGIN_FLIGHT_COUNT,
 DEST_FLIGHT_COUNT,
 ORIGIN_STATION,
 ORIGIN_STATION_NAME,
 PAGERANK,
 DEST_STATION,
 DEST_STATION_NAME,
 ORIGIN_UTC_ADJ,
 origin_max_date, 
 dest_max_date, count(1)
FROM data_final_max
GROUP BY YEAR,
 QUARTER,
 MONTH,
 DAY_OF_MONTH,
 DAY_OF_WEEK,
 FL_DATE,
 OP_UNIQUE_CARRIER,
 OP_CARRIER_AIRLINE_ID,
 OP_CARRIER,
 TAIL_NUM,
 OP_CARRIER_FL_NUM,
 ORIGIN_AIRPORT_ID,
 ORIGIN_AIRPORT_SEQ_ID,
 ORIGIN_CITY_MARKET_ID,
 ORIGIN,
 ORIGIN_CITY_NAME,
 ORIGIN_STATE_ABR,
 ORIGIN_STATE_FIPS,
 ORIGIN_STATE_NM,
 ORIGIN_WAC,
 DEST_AIRPORT_ID,
 DEST_AIRPORT_SEQ_ID,
 DEST_CITY_MARKET_ID,
 DEST,
 DEST_CITY_NAME,
 DEST_STATE_ABR,
 DEST_STATE_FIPS,
 DEST_STATE_NM,
 DEST_WAC,
 CRS_DEP_TIME,
 DEP_TIME,
 DEP_DELAY,
 DEP_DELAY_NEW,
 DEP_DEL15,
 DEP_DELAY_GROUP,
 DEP_TIME_BLK,
 TAXI_OUT,
 WHEELS_OFF,
 WHEELS_ON,
 TAXI_IN,
 CRS_ARR_TIME,
 ARR_TIME,
 ARR_DELAY,
 ARR_DELAY_NEW,
 ARR_DEL15,
 ARR_DELAY_GROUP,
 ARR_TIME_BLK,
 CANCELLED,
 DIVERTED,
 CRS_ELAPSED_TIME,
 ACTUAL_ELAPSED_TIME,
 AIR_TIME,
 FLIGHTS,
 DISTANCE,
 DISTANCE_GROUP,
 DIV_AIRPORT_LANDINGS,
 ORIGIN_TZ,
 DEST_TZ,
 DEP_MIN,
 DEP_HOUR,
 ARR_MIN,
 ARR_HOUR,
 ORIGIN_TS,
 ORIGIN_UTC,
 DEST_TS,
 DEST_UTC,
 ORIGIN_FLIGHT_COUNT,
 DEST_FLIGHT_COUNT,
 ORIGIN_STATION,
 ORIGIN_STATION_NAME,
 PAGERANK,
 DEST_STATION,
 DEST_STATION_NAME,
 ORIGIN_UTC_ADJ,
 origin_max_date,
 dest_max_date
HAVING count(1) > 1
""")

display(checkdup2)

# COMMAND ----------


