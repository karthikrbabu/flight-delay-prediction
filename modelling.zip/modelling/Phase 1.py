# Databricks notebook source
import numpy as np
import pandas as pd
import plotly as px
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from datetime import datetime
import time

import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.ml.feature import StringIndexer, VectorIndexer, VectorAssembler, StandardScaler, OneHotEncoder, SQLTransformer
from pyspark.ml.classification import LogisticRegression 
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml import Pipeline
from pyspark.sql import Window

from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

import mlflow
import mlflow.spark

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Goal 
# MAGIC Try out some tree based algorithms, **DecionsTree and RandomForest** on our **6 month** then **ALL** data and see how we can extend this setup to our final dataset.

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/final_datasets/data_range/part-00*.parquet")

# COMMAND ----------

print(data.count())
len(data.columns)
np.array(data.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Data Sanity

# COMMAND ----------

data.groupBy('DEP_DEL15').count().orderBy('count').show()

# COMMAND ----------

year_delay = data.groupBy('YEAR','DEP_DEL15').count().orderBy('count')
year_delay.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Select Needed 6 month Data

# COMMAND ----------

data_6 = data.where(col("YEAR") == 2015) \
             .where((col("ORIGIN") == "ORD") | (col("ORIGIN") == "ATL")) \
             .where(col("MONTH").isin([1,2,3,4,5,6]))

# COMMAND ----------

print("Number of columns: ",len(data_6.columns))

# COMMAND ----------

og_cols = data_6.columns

# COMMAND ----------

columns_to_drop = ["YEAR", 'QUARTER' 'OP_CARRIER', "OP_CARRIER_FL_NUM", "ORIGIN_AIRPORT_ID", 
                   "FL_DATE", "OP_CARRIER_AIRLINE_ID", "DEST_STATE_FIPS", "ARR_TIME_BLK", "DEP_TIME_BLK","DISTANCE_GROUP",
                   "ORIGIN_AIRPORT_SEQ_ID", "ORIGIN_CITY_NAME", "ORIGIN_STATE_FIPS", "ORIGIN_STATE_NM",
                   "ORIGIN_WAC", 'DEST_AIRPORT_ID','DEST_AIRPORT_SEQ_ID',"DEST_CITY_NAME", "DEST_STATE_FIPS",
                   'DEST_STATE_NM', 'DEST_WAC', 'CRS_DEP_TIME', 'CRS_ARR_TIME', 'DEP_TIME', 'ARR_TIME', "CANCELLED", "DIVERTED", 
                   "ACTUAL_ELAPSED_TIME", "FLIGHTS", "DIV_AIRPORT_LANDINGS", "ORIGIN_TS", "DEST_TS", "DEST_UTC",
                   "ORIGIN_STATION", "ORIGIN_STATION_NAME", "DEST_STATION","DEST_STATION_NAME", "ORIGIN_UTC_ADJ", "origin_max_date", 
                   "dest_max_date",'ARR_DELAY', 'ARR_DELAY_NEW', "ARR_DEL15", "ARR_DELAY_GROUP", "DEP_DELAY", "DEP_DELAY_NEW", "TAXI_OUT", 
                   'WHEELS_OFF', 'WHEELS_ON', 'TAXI_IN', 'AIR_TIME', 'ORIGIN_UTC_ADJ_MAX','ORIGIN_UTC_ADJ_MIN']

print("Number of dropped columns: ", len(columns_to_drop))
data_6 = data_6.drop(*columns_to_drop)

# COMMAND ----------

data_6 = data_6.drop(*['OP_CARRIER', 'QUARTER'])

# COMMAND ----------

print(len(data_6.columns))
display(data_6)

# COMMAND ----------

#Remaining Columns
cat_cols = ['MONTH', 'DAY_OF_MONTH', 'DAY_OF_WEEK', 'TAIL_NUM',
            'OP_UNIQUE_CARRIER', 'ORIGIN_CITY_MARKET_ID', 'ORIGIN',
            'ORIGIN_STATE_ABR', 'DEST_CITY_MARKET_ID', 'DEST',
            'DEST_STATE_ABR', 'ORIGIN_TZ', 'DEST_TZ', 'DEP_MIN', 
            'DEP_HOUR', 'ARR_MIN', 'ARR_HOUR']

num_cols = ['DISTANCE', 'CRS_ELAPSED_TIME','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
            'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
            'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
            'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
            'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
            'AVG_SLP_DEST']

label_cols = ['DEP_DEL15', 'DEP_DELAY_GROUP']

# COMMAND ----------

print("Number of remaining columns: ", len(cat_cols + num_cols + label_cols))

# COMMAND ----------

data_6_order = data_6.withColumn("time_rank", f.percent_rank().over(Window.partitionBy().orderBy("ORIGIN_UTC")))
display(data_6_order)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Number of Unique Vals by Category

# COMMAND ----------

for col in cat_cols:
  print(col, ": ", data_6_order.select(col).distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Convert Buckets Within Categorical
# MAGIC 
# MAGIC For any categorical feature that has a ton of values it can take on, we can form a minority bucket after analyzing its spread

# COMMAND ----------

# i.e. Here as an example we look at the spread of 
# DEST_CITY_MARKET_ID
dest_mark_id_count = data_6_order.groupBy("DEST_CITY_MARKET_ID").count().orderBy("count")
dest_mark_id_count.cache()
display(dest_mark_id_count)

# COMMAND ----------

counts = [x["count"] for x in dest_mark_id_count.select("count").collect()]

# COMMAND ----------

print("std", np.std(counts))
print("mean", np.mean(counts))
plt.hist(counts, bins = 50)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### For now we are not doing it, might try later

# COMMAND ----------

#After analyzing the distribution of categories, decided to bin anything greater than average count
# COUNT_THRESHOLD = 1967

# data_6_order = data_6_order.join(dest_mark_id_count, "DEST_CITY_MARKET_ID", "inner")

# def convertMinority(originalCol, colCount):
#   if colCount <= COUNT_THRESHOLD:
#     return originalCol
#   else:
#     return "MIN_CAT"
  
# udf_convertMin = udf(convertMinority, t.StringType())

# data_6_order = data_6_order.withColumn(udf_convertMin(data_6_order["DEST_CITY_MARKET_ID"], data_6_order["count"]))
# data_6_order = data_6_order.drop("DEST_CITY_MARKET_ID")
# data_6_order = data_6_order.drop("count")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Train/ Val Split

# COMMAND ----------

# data_6_order = data_6.withColumn("time_rank", f.percent_rank().over(Window.partitionBy().orderBy("ORIGIN_UTC")))
train = data_6_order.where("time_rank <= .8").drop("time_rank")
val = data_6_order.where("time_rank > .8").drop("time_rank")

print("Train size: ", train.count())
print("Val size: ", val.count())

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Model #1 - Random Forest
# MAGIC * Categorical
# MAGIC * Numerical

# COMMAND ----------

m1_num_cols = ['DISTANCE','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
               'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
               'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
               'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
               'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
               'AVG_SLP_DEST']


m1_cat_cols = ['MONTH', 'DAY_OF_MONTH', 'DAY_OF_WEEK',
              'OP_UNIQUE_CARRIER', 'ORIGIN_CITY_MARKET_ID', 'ORIGIN',
              'ORIGIN_STATE_ABR', 'DEST_CITY_MARKET_ID', 'DEST',
              'DEST_STATE_ABR', 'ORIGIN_TZ', 'DEST_TZ', 'DEP_MIN', 
              'DEP_HOUR']

label_col = ["DEP_DEL15"]

m1_cols = m1_num_cols + m1_cat_cols + label_col

m1_train = train.select(*m1_cols).withColumnRenamed('DEP_DEL15', 'label')
m1_val = val.select(*m1_cols).withColumnRenamed('DEP_DEL15', 'label')

# COMMAND ----------

display(m1_train)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Feature Engineering Pipeline
# MAGIC This way we can easily extend it to other data sets 
# MAGIC 
# MAGIC 1. One Hot Encoding

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in m1_cat_cols]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in m1_cat_cols]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(m1_cat_cols, col_vec_out)]

#Create pair of zips 
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

# COMMAND ----------

stages

# COMMAND ----------

m1_cols = m1_num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=m1_cols, outputCol="features")
stages += [vector_assembler]
pipeline = Pipeline().setStages(stages)

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC #MISLEADING - But no actualy model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC m1_train = pipeline.fit(m1_train).transform(m1_train)
# MAGIC m1_val = pipeline.fit(m1_val).transform(m1_val)

# COMMAND ----------

display(m1_train)

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC rf = RandomForestClassifier(labelCol='label',featuresCol='features', numTrees=50)
# MAGIC rf_model = rf.fit(m1_train)
# MAGIC 
# MAGIC m1_train_results = rf_model.transform(m1_train)
# MAGIC m1_val_results = rf_model.transform(m1_val)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Model #1 - EVAL

# COMMAND ----------

#Set up BinClassEval
evaluator = BinaryClassificationEvaluator()
evaluator.setRawPredictionCol("raw")

trainScoreAndLabels = m1_train_results.select(['probability','label', col("prediction").alias("raw")])
valScoreAndLabels = m1_val_results.select(['probability','label', col("prediction").alias("raw")])

#prepare score-label set
# m1_train_scores = [(float(i[0][0]), 1.0-float(i[1])) for i in trainScoreAndLabels.collect()]
# m1_val_scores = [(float(i[0][0]), 1.0-float(i[1])) for i in valScoreAndLabels.collect()]

print("Train Set")
print("areaUnderPR: ", evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"}))
print("areaUnderROC: ",evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"}))

# #prepare score-label set
# m1_val_collect = m1_val_results.collect()
# m1_val_results = [(float(i[0][0]), 1.0-float(i[1])) for i in m1_val_collect]
# scoreAndLabels = sc.parallelize(m1_val_results)
# metrics = BinaryClassificationEvaluator(scoreAndLabels)

# print("Val Set")
# print("areaUnderPR: ", evaluator.evaluate(scoreAndLabels, {metrics.metricName: "areaUnderPR"}))
# print("areaUnderROC: ",evaluator.evaluate(scoreAndLabels, {metrics.metricName: "areaUnderROC"}))


# COMMAND ----------

display(trainScoreAndLabels)

# COMMAND ----------

trainScoreAndLabels_col = trainScoreAndLabels.collect()
trainScoreAndLabels_col

# COMMAND ----------

m1_train_scores = [(float(i[0][1]), 1.0-float(i[1])) for i in trainScoreAndLabels.collect()]

# COMMAND ----------

m1_train_scores

# COMMAND ----------

from sklearn.metrics import roc_auc_score
roc_auc_score(y_test, y_score)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Visualize AUC Curve

# COMMAND ----------

from sklearn.metrics import roc_curve, auc

fpr = dict()
tpr = dict()
roc_auc = dict()

y_test = [i[1] for i in m1_train_scores]
y_score = [i[0] for i in m1_train_scores]

fpr, tpr, _ = roc_curve(y_test, y_score)
roc_auc = auc(fpr,tpr)

%matplotlib inline
plt.figure(figsize=(10,7))
plt.plot(fpr, tpr, label= 'ROC curve (area {0}'.format(roc_auc))
plt.plot([0,1],[0,1],'k--')
plt.xlim([0.0,1.0])
plt.ylim([0.0,1.05])
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC AUC")
plt.legend(loc="lower right")
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Goal 
# MAGIC Try out some tree based algorithms, **RandomForest** on our **ALL** data and see how we can extend this setup to our final dataset.

# COMMAND ----------

train_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/train/part-00*.parquet")
val_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/strategy/model_datasets/validation/part-00*.parquet")

print(train_data.count())
display(train_data)


# COMMAND ----------

print("Number of columns: ", len(train_data.columns))
np.array(train_data.columns)

# COMMAND ----------

columns_to_drop = ['YEAR', 'QUARTER', 'DAY_OF_MONTH', 
                   'FL_DATE', 'OP_CARRIER_AIRLINE_ID',
                   'OP_CARRIER', 'TAIL_NUM', 'OP_CARRIER_FL_NUM', 'ORIGIN_AIRPORT_ID',
                   'ORIGIN_AIRPORT_SEQ_ID', 'ORIGIN_CITY_MARKET_ID',
                   'ORIGIN_CITY_NAME', 'ORIGIN_STATE_FIPS',
                   'ORIGIN_STATE_NM', 'ORIGIN_WAC', 'DEST_AIRPORT_ID',
                   'DEST_AIRPORT_SEQ_ID', 'DEST_CITY_MARKET_ID',
                   'DEST_CITY_NAME', 'DEST_STATE_FIPS',
                   'DEST_STATE_NM', 'DEST_WAC', 'CRS_DEP_TIME', 'DEP_TIME',
                   'DEP_DELAY', 'DEP_DELAY_NEW',
                   'DEP_TIME_BLK', 'TAXI_OUT', 'WHEELS_OFF', 'WHEELS_ON', 'TAXI_IN',
                   'CRS_ARR_TIME', 'ARR_TIME', 'ARR_DELAY', 'ARR_DELAY_NEW','ARR_TIME_BLK', 
                   'CANCELLED','DIVERTED', 'ACTUAL_ELAPSED_TIME', 'AIR_TIME',
                   'FLIGHTS', 'DISTANCE_GROUP', 'DIV_AIRPORT_LANDINGS',
                   'DEP_MIN', 'ARR_MIN','ORIGIN_TS',  'DEST_TS','ORIGIN_STATION',
                   'ORIGIN_STATION_NAME', 'DEST_STATION', 'DEST_STATION_NAME',
                   'ORIGIN_UTC_ADJ_MIN', 'ORIGIN_UTC_ADJ_MAX',
                   'ORIGIN_MAX_DATE', 'DEST_MAX_DATE']

cat_cols = ['MONTH', 'DAY_OF_WEEK', 'WEST_TO_EAST', 'DEP_HOUR','ARR_HOUR', 'OP_UNIQUE_CARRIER', 'ORIGIN', 'ORIGIN_STATE_ABR','DEST', 
            'DEST_STATE_ABR', 'ORIGIN_UTC', 'DEST_UTC','ORIGIN_TZ', 'DEST_TZ']

num_cols = [ 'ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT','PAGERANK', 'CRS_ELAPSED_TIME',
             'DELAYS_SO_FAR','CRS_ELAPSED_TIME_AVG_DIFF','AVG_WND_SPEED_ORIGIN', 
             'AVG_CIG_HEIGHT_ORIGIN','MIN_CIG_HEIGHT_ORIGIN', 'AVG_VIS_DIS_ORIGIN',
             'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
             'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'AVG_CIG_HEIGHT_DEST',
             'MIN_CIG_HEIGHT_DEST', 'AVG_VIS_DIS_DEST', 'MIN_VIS_DIS_DEST',
             'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST', 'AVG_SLP_DEST', 'DISTANCE']

label_cols = [ 'DEP_DEL15', 'DEP_DELAY_GROUP', 'ARR_DEL15', 'ARR_DELAY_GROUP']

print("Number of dropped columns: ", len(columns_to_drop))

#Drop on Train
train_final = train_data.drop(*columns_to_drop)

#Drop on Val
val_final = val_data.drop(*columns_to_drop)

print("Remaining Col Count: ", len(train_final.columns))
display(train_final)

# COMMAND ----------

#Apply Balance Ratio, build this only from Train
balancing_ratio = train_final.filter("DEP_DEL15 == 0").count() / train_final.count()
print("Balancing Ratio =", balancing_ratio)

train_final = train_final.withColumn("CLASS_WEIGHTS", when(train_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))


val_final = val_final.withColumn("CLASS_WEIGHTS", when(val_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### To Extract Feature Importance

# COMMAND ----------

#Returns a Pandas DF with top features and scores
def ExtractFeatureImp(featureImp, dataset, featuresCol):
    list_extract = []
    for i in dataset.schema[featuresCol].metadata["ml_attr"]["attrs"]:
        list_extract = list_extract + dataset.schema[featuresCol].metadata["ml_attr"]["attrs"][i]
    varlist = pd.DataFrame(list_extract)
    varlist['score'] = varlist['idx'].apply(lambda x: featureImp[x])
    return(varlist.sort_values('score', ascending = False))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### M1 - "Kitchen Sink"
# MAGIC Throw everything we have at it!

# COMMAND ----------

label_col = ['DEP_DEL15']
m1_cat = list(set(cat_cols) - set(['ORIGIN_UTC', 'DEST_UTC']))
m1_cols = list(set(cat_cols + num_cols + label_col) - set(['ORIGIN_UTC', 'DEST_UTC'])) + ["CLASS_WEIGHTS"]

m1_train = train_final.select(*m1_cols).withColumnRenamed('DEP_DEL15', 'label')
m1_val = val_final.select(*m1_cols).withColumnRenamed('DEP_DEL15', 'label')

display(m1_train)

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in m1_cat]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in m1_cat]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(m1_cat, col_vec_out)]

#Create pair of zips
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

# COMMAND ----------

m1_cols = num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=m1_cols, outputCol="features", handleInvalid='skip')
stages += [vector_assembler]
pipeline = Pipeline().setStages(stages)

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC #MISLEADING - But no actualy model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC m1_train_pip = pipeline.fit(m1_train).transform(m1_train)
# MAGIC m1_val_pip = pipeline.fit(m1_val).transform(m1_val)
# MAGIC 
# MAGIC display(m1_train_pip)

# COMMAND ----------

# MAGIC %%time
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC   dt_string = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
# MAGIC   print("Start Model Fit= ", dt_string)  
# MAGIC   
# MAGIC   
# MAGIC   rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                               numTrees=50, maxDepth=10, cacheNodeIds = True, subsamplingRate = 1.0)
# MAGIC 
# MAGIC   rf_model = rf.fit(m1_train_pip)
# MAGIC   m1_train_results = rf_model.transform(m1_train_pip)
# MAGIC   m1_val_results = rf_model.transform(m1_val_pip)
# MAGIC   
# MAGIC   mlflow.log_param('numTrees', 50)
# MAGIC   mlflow.log_param('maxDepth', 10)
# MAGIC   mlflow.log_param('cacheNodeIds', True)
# MAGIC   mlflow.log_param('subsamplingRate', 1.0)
# MAGIC   
# MAGIC   #Set up BinClassEval
# MAGIC   evaluator = BinaryClassificationEvaluator()
# MAGIC   evaluator.setRawPredictionCol("raw")
# MAGIC   trainScoreAndLabels = m1_train_results.select(['probability','label', col("prediction").alias("raw")])
# MAGIC   valScoreAndLabels = m1_val_results.select(['probability','label', col("prediction").alias("raw")])
# MAGIC 
# MAGIC   print("Train Set")
# MAGIC   train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC   train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC   
# MAGIC   print("train areaUnderPR: ", train_pr)
# MAGIC   print("train areaUnderROC: ", train_roc)
# MAGIC   mlflow.log_metric('train_pr' ,train_pr)
# MAGIC   mlflow.log_metric('train_roc' ,train_roc)  
# MAGIC   
# MAGIC   print()
# MAGIC   print("Validation Set")
# MAGIC   val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC   val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC   
# MAGIC   print("val areaUnderPR: ", val_pr)
# MAGIC   print("val areaUnderROC: ", val_roc)
# MAGIC   mlflow.log_metric('val_pr' ,val_pr)
# MAGIC   mlflow.log_metric('val_roc' ,val_roc)
# MAGIC   
# MAGIC   dt_string = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
# MAGIC   print("Log Model = ", dt_string)
# MAGIC   
# MAGIC   # Log the best model.
# MAGIC   mlflow.spark.log_model(spark_model=rf_model, artifact_path='rf_model_1')
# MAGIC 
# MAGIC   dt_string = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
# MAGIC   print("Save Model = ", dt_string)
# MAGIC   
# MAGIC   #Save the model out in case we need to reference again in the future
# MAGIC   rf_model.write().overwrite().save("dbfs:/mnt/mids-w261/team20SSDK/models/rf_model_1")

# COMMAND ----------



# COMMAND ----------

rf_model.save("dbfs:/mnt/mids-w261/team20SSDK/models/rf_model_1")

# COMMAND ----------

varlist = ExtractFeatureImp(rf_model.featureImportances, m1_train_results, "features")
varlist["order"] = np.arange(1, len(varlist["idx"])+1)
varlist.head(50)

# COMMAND ----------



# Save the table of predicted values
varlist.to_csv('/dbfs/mnt/mids-w261/team20SSDK/models/tmp/varList.csv')
# # Log the saved table as an artifact
mlflow.log_artifact("predictions.csv")




# COMMAND ----------

# varidx = [x for x in varlist['idx'][0:10]]

# COMMAND ----------

# slicer = VectorSlicer(inputCol="features", outputCol="features2", indices=varidx)
# m1_trim = slicer.transform(m1_train_results)

# COMMAND ----------

# m1_trim = m1_trim.drop('rawPrediction', 'probability', 'prediction')
# rf2 = RandomForestClassifier(labelCol="label", featuresCol="features2", seed = 8464,
#                             numTrees=10, cacheNodeIds = True, subsamplingRate = 0.7)
# mod2 = rf2.fit(m1_trim)
# m1_trim_results = mod2.transform(m1_trim)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### M2 - "Kitchen Sink" + Deeper Tree
# MAGIC Throw everything we have at it!

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC model_version = "rd_model_2"
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC   
# MAGIC   start = time.time()
# MAGIC   pipeline_2 = Pipeline().setStages(stages)
# MAGIC   #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC   m2_train_pip = pipeline_2.fit(m1_train).transform(m1_train)
# MAGIC   m2_val_pip = pipeline_2.fit(m1_val).transform(m1_val)  
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC   
# MAGIC   
# MAGIC   rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=50, maxDepth=25, cacheNodeIds = True, subsamplingRate = 1.0)  
# MAGIC   mlflow.log_param('numTrees', 50)
# MAGIC   mlflow.log_param('maxDepth', 25)
# MAGIC   mlflow.log_param('cacheNodeIds', True)
# MAGIC   mlflow.log_param('subsamplingRate', 1.0)  
# MAGIC 
# MAGIC   
# MAGIC   start = time.time()  
# MAGIC   rf_model = rf.fit(m2_train_pip)
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC   
# MAGIC   start = time.time()
# MAGIC   m2_train_results = rf_model.transform(m2_train_pip)
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC   start = time.time()  
# MAGIC   m2_val_results = rf_model.transform(m2_val_pip)
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('val_pred_time' ,done - start)  
# MAGIC   
# MAGIC   #Set up BinClassEval
# MAGIC   evaluator = BinaryClassificationEvaluator()
# MAGIC   evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC   trainScoreAndLabels = m2_train_results.select(['probability','label', col("prediction").alias("raw")])
# MAGIC   valScoreAndLabels = m2_val_results.select(['probability','label', col("prediction").alias("raw")])
# MAGIC 
# MAGIC   print("Train Set")
# MAGIC   start =time.time()
# MAGIC   train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC   train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC   
# MAGIC   print("train areaUnderPR: ", train_pr)
# MAGIC   print("train areaUnderROC: ", train_roc)
# MAGIC   mlflow.log_metric('train_pr' ,train_pr)
# MAGIC   mlflow.log_metric('train_roc' ,train_roc)
# MAGIC   print()
# MAGIC   
# MAGIC   print("Validation Set")
# MAGIC   start =time.time()
# MAGIC   val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC   val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC   
# MAGIC   print("val areaUnderPR: ", val_pr)
# MAGIC   print("val areaUnderROC: ", val_roc)
# MAGIC   mlflow.log_metric('val_pr' ,val_pr)
# MAGIC   mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC   
# MAGIC   # Log this model.
# MAGIC   mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC   start =time.time()
# MAGIC   #Save the model out in case we need to reference again in the future
# MAGIC   rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC   
# MAGIC   
# MAGIC   start =time.time()
# MAGIC   #m2_train_results input is just used for Schema purposes
# MAGIC   varlist = ExtractFeatureImp(rf_model.featureImportances, m2_train_results, "features")
# MAGIC   varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC   done = time.time()
# MAGIC   mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC   
# MAGIC   start =time.time()
# MAGIC   #Log these artifacts for graphs and charts later on
# MAGIC   trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC   valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC 
# MAGIC #Some silly issues due to path mis match, caused this part to break, but no matter, got the details out below!  
# MAGIC #   varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/feat_imp.csv')
# MAGIC #   valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/val_pred.csv')  
# MAGIC #   trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/train_pred.csv')  
# MAGIC #   done = time.time()
# MAGIC #   mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC   
# MAGIC #   # # Log the saved table as an artifact
# MAGIC #   mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/feat_imp.csv')
# MAGIC #   mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/val_pred.csv')
# MAGIC #   mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/train_pred.csv')  
# MAGIC   

# COMMAND ----------

print(trainScoreAndLabels_pd.shape)
trainScoreAndLabels_pd.head()

# COMMAND ----------

varlist.head()

# COMMAND ----------

#Extract it all to evaluate later on.
# varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/feat_imp.csv', index=False)
# valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/val_pred.csv', index=False)
# trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/tmp/{model_version}/train_pred.csv', index=False)

# COMMAND ----------

#We are now dropping more columns after discussion in OH regarding columns that are too heavily mapped to specific patterns (i.e. IDs such as ORIGIN, DEST, OP_CARRIER)
columns_to_drop = ['YEAR', 'QUARTER', 'DAY_OF_MONTH', 
                   'FL_DATE', 'OP_CARRIER_AIRLINE_ID',
                   'OP_CARRIER', 'TAIL_NUM', 'OP_CARRIER_FL_NUM', 'ORIGIN_AIRPORT_ID',
                   'ORIGIN_AIRPORT_SEQ_ID', 'ORIGIN_CITY_MARKET_ID',
                   'ORIGIN_CITY_NAME', 'ORIGIN_STATE_FIPS',
                   'ORIGIN_STATE_NM', 'ORIGIN_WAC', 'DEST_AIRPORT_ID',
                   'DEST_AIRPORT_SEQ_ID', 'DEST_CITY_MARKET_ID',
                   'DEST_CITY_NAME', 'DEST_STATE_FIPS',
                   'DEST_STATE_NM', 'DEST_WAC', 'CRS_DEP_TIME', 'DEP_TIME',
                   'DEP_DELAY', 'DEP_DELAY_NEW',
                   'DEP_TIME_BLK', 'TAXI_OUT', 'WHEELS_OFF', 'WHEELS_ON', 'TAXI_IN',
                   'CRS_ARR_TIME', 'ARR_TIME', 'ARR_DELAY', 'ARR_DELAY_NEW','ARR_TIME_BLK', 
                   'CANCELLED','DIVERTED', 'ACTUAL_ELAPSED_TIME', 'AIR_TIME',
                   'FLIGHTS', 'DISTANCE_GROUP', 'DIV_AIRPORT_LANDINGS',
                   'DEP_MIN', 'ARR_MIN','ORIGIN_TS',  'DEST_TS','ORIGIN_STATION',
                   'ORIGIN_STATION_NAME', 'DEST_STATION', 'DEST_STATION_NAME',
                   'ORIGIN_UTC_ADJ_MIN', 'ORIGIN_UTC_ADJ_MAX',
                   'ORIGIN_MAX_DATE', 'DEST_MAX_DATE', 'ORIGIN_STATE_ABR', 'DEST_STATE_ABR', 'ORIGIN_UTC', 'DEST_UTC']


#Potential columns to keep around for model variants
pot_cols = ['ORIGIN','DEST', 'OP_UNIQUE_CARRIER']

cat_cols = ['MONTH', 'DAY_OF_WEEK', 'WEST_TO_EAST', 'DEP_HOUR','ARR_HOUR', 'ORIGIN_TZ', 'DEST_TZ']

num_cols = [ 'ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT','PAGERANK', 'CRS_ELAPSED_TIME',
             'DELAYS_SO_FAR','CRS_ELAPSED_TIME_AVG_DIFF','AVG_WND_SPEED_ORIGIN', 
             'AVG_CIG_HEIGHT_ORIGIN','MIN_CIG_HEIGHT_ORIGIN', 'AVG_VIS_DIS_ORIGIN',
             'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
             'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'AVG_CIG_HEIGHT_DEST',
             'MIN_CIG_HEIGHT_DEST', 'AVG_VIS_DIS_DEST', 'MIN_VIS_DIS_DEST',
             'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST', 'AVG_SLP_DEST', 'DISTANCE']

label_cols = [ 'DEP_DEL15', 'DEP_DELAY_GROUP', 'ARR_DEL15', 'ARR_DELAY_GROUP']

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Analysis of Model #2 Output

# COMMAND ----------



# COMMAND ----------

#Extract it all to evaluate later on.
varlist = pd.read_csv('/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/rd_model_2/feat_imp.csv')
valScoreAndLabels_pd = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/rd_model_2/val_pred.csv')
trainScoreAndLabels_pd = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/rd_model_2/train_pred.csv')

# COMMAND ----------

import seaborn as sn
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

# COMMAND ----------

varlist.head(50)

# COMMAND ----------

trainScoreAndLabels_pd.head()

# COMMAND ----------

valScoreAndLabels_pd.head()

# COMMAND ----------

trainScoreAndLabels_pd["label"][0:10]

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Training Analysis

# COMMAND ----------

y_train_true = trainScoreAndLabels_pd["label"]
y_train_pred = trainScoreAndLabels_pd["raw"]
conf_mat_train = confusion_matrix(y_train_true, y_train_pred)

# COMMAND ----------

print("Accuracy Score: ", accuracy_score(y_train_true, y_train_pred))
print("F1 Score: ", f1_score(y_train_true, y_train_pred))
print(classification_report(y_train_true, y_train_pred))

# COMMAND ----------

df_cm_train = pd.DataFrame(conf_mat_train, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm_train, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Validation Analysis

# COMMAND ----------

y_val_true = valScoreAndLabels_pd["label"]
y_val_pred = valScoreAndLabels_pd["raw"]
conf_mat_val = confusion_matrix(y_val_true, y_val_pred)

# COMMAND ----------

print("Accuracy Score: ", accuracy_score(y_val_true, y_val_pred))
print("F1 Score: ", f1_score(y_val_true, y_val_pred))
print(classification_report(y_val_true, y_val_pred))

# COMMAND ----------

df_cm_val = pd.DataFrame(conf_mat_val, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm_val, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------


