# Databricks notebook source
import numpy as np
import pandas as pd
import plotly as px
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from datetime import datetime
import time

import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.ml.feature import StringIndexer, VectorIndexer, VectorAssembler, StandardScaler, OneHotEncoder, SQLTransformer
from pyspark.ml.classification import LogisticRegression 
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml import Pipeline
from pyspark.sql import Window

from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

import mlflow
import mlflow.spark

import sys
import os
from pyspark.ml.classification import RandomForestClassificationModel


# COMMAND ----------

# MAGIC %md
# MAGIC ## False Positive Analysis
# MAGIC 
# MAGIC Since our business case is focused around precision due to a high cost of false positives, we wanted to take a closer look at the false positives in our validation set to see if we could gain further insight into which features might be making the largest contribution to the false positive rate.  

# COMMAND ----------

# load the validation predictions
val_pred = spark.read.format("csv").option("header", "true").load("dbfs:/mnt/mids-w261/team20SSDK/reports/fp_results.csv") 
print(val_pred.count())

# COMMAND ----------

# create a false positive column to quickly identify false positive rows.
val_pred = val_pred.withColumn("fp", when((col("prediction") == 1) & (col("label")==0),1).otherwise(0))
print(val_pred.count())
display(val_pred)

# COMMAND ----------

#Percent FP
str(100*1317864/ 7071462) + '%'


# COMMAND ----------

val_pred.registerTempTable('val_pred')

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of DELAYS_SO_FAR
spark.sql('SELECT DELAYS_SO_FAR, count(FP), sum(fp) FROM val_pred group by DELAYS_SO_FAR ORDER BY DELAYS_SO_FAR').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of DEP_HOUR_BIN
spark.sql('SELECT DEP_HOUR_BIN, count(FP), sum(fp) FROM val_pred group by DEP_HOUR_BIN ORDER BY DEP_HOUR_BIN').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of ARR_HOUR_BIN
spark.sql('SELECT ARR_HOUR_BIN, count(FP), sum(fp) FROM val_pred group by ARR_HOUR_BIN ORDER BY ARR_HOUR_BIN').display()

# COMMAND ----------

spark.sql('SELECT ROUND(MINUTES_AFTER_MIDNIGHT_ORIGIN / 60,0) as hour, sum(fp) as fp_count, count(FP) as non_fp_count FROM val_pred group by ROUND(MINUTES_AFTER_MIDNIGHT_ORIGIN / 60,0) ORDER BY hour').display()

# COMMAND ----------

spark.sql('SELECT ROUND(MINUTES_AFTER_MIDNIGHT_ORIGIN / 60,0) as h, count(FP) as non_fp_count, sum(fp) as fp_count FROM val_pred group by ROUND(MINUTES_AFTER_MIDNIGHT_ORIGIN / 60,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of MINUTES_AFTER_MIDNIGHT_DEST
spark.sql('SELECT ROUND(MINUTES_AFTER_MIDNIGHT_DEST / 60,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(MINUTES_AFTER_MIDNIGHT_DEST / 60,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of NETWORK_CONGESTION
spark.sql('SELECT ROUND(NETWORK_CONGESTION / 100,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(NETWORK_CONGESTION / 100,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of AVG_DEW_DEG_ORIGIN
spark.sql('SELECT ROUND(AVG_DEW_DEG_ORIGIN / 100,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(AVG_DEW_DEG_ORIGIN / 100,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of AVG_WND_SPEED_ORIGIN
spark.sql('SELECT ROUND(AVG_WND_SPEED_ORIGIN / 10,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(AVG_WND_SPEED_ORIGIN / 10,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of AVG_WND_SPEED_DEST
spark.sql('SELECT ROUND(AVG_WND_SPEED_DEST / 10,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(AVG_WND_SPEED_DEST / 10,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of ORIGIN PAGERANK
spark.sql('SELECT ROUND(ORIGIN_PR * 1000,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(ORIGIN_PR * 1000,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of DESTINATION PAGERANK
spark.sql('SELECT ROUND(DEST_PR * 1000,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(DEST_PR * 1000,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of CRS_ELAPSED_TIME
spark.sql('SELECT ROUND(CRS_ELAPSED_TIME / 10,0) as h, count(FP), sum(fp) FROM val_pred group by ROUND(CRS_ELAPSED_TIME / 10,0) ORDER BY h').display()

# COMMAND ----------

# compare the total rows vs. the false positive rows for values of QUARTER
spark.sql('SELECT QUARTER, count(FP), sum(fp) FROM val_pred group by QUARTER ORDER BY QUARTER').display()
