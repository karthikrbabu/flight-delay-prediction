# Databricks notebook source
import numpy as np
import pandas as pd
import plotly as px
import matplotlib.pyplot as plt


import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.sql import Window
from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

# COMMAND ----------

data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/final_datasets/data_range/part-00*.parquet")

# COMMAND ----------

print(data.count())
len(data.columns)
np.array(data.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Yearly Spread Sanity

# COMMAND ----------

data.groupBy('DEP_DEL15').count().orderBy('count').show()

# COMMAND ----------



# COMMAND ----------

year_group = data.groupBy('YEAR').count().orderBy('count')
year_group.show()

# COMMAND ----------

year_delay = data.groupBy('YEAR','DEP_DEL15').count().orderBy('count')
year_delay.show()

# COMMAND ----------

yearly_percent_split = year_delay.join(year_group, year_delay.YEAR == year_group.YEAR)\
                                 .select(year_delay["*"], year_group["count"].alias("year_count"))\
                                 .withColumn("percent_split", (col("count") / col("year_count"))) \
                                 .orderBy("YEAR", "DEP_DEL15")
yearly_percent_split.show()

# COMMAND ----------

print("Data lost, going from max date to range ")

#2015
print("2015: ", 5591924 - 5590241)

#2016
print("2016: ",5418649 - 5411738)

#2017
print("2017: ",5493163 - 5489903)

#2018
print("2018: ",6964376 - 6934801)

#2019
print("2019: ",7147756 - 1177048)

# COMMAND ----------

#max_date
year_group = data.groupBy('YEAR').count().orderBy('count')
year_group.show()

# COMMAND ----------

6934801 / (5411738 + 5489903 + 5590241 + 6934801)

# COMMAND ----------

#max_date
year_delay = data.groupBy('YEAR','DEP_DEL15').count().orderBy('count')
year_delay.show()

# COMMAND ----------

#max_date
yearly_percent_split = year_delay.join(year_group, year_delay.YEAR == year_group.YEAR)\
                                 .select(year_delay["*"], year_group["count"].alias("year_count"))\
                                 .withColumn("percent_split", (col("count") / col("year_count"))) \
                                 .orderBy("YEAR", "DEP_DEL15")
yearly_percent_split.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Focus on 6 month data
# MAGIC * ORD, ATL
# MAGIC * First 6 months of the year

# COMMAND ----------

data_6 = data.where(col("YEAR") == 2015) \
             .where((col("ORIGIN") == "ORD") | (col("ORIGIN") == "ATL")) \
             .where(col("MONTH").isin([1,2,3,4,5,6]))

# COMMAND ----------

data6_snapshot = data_6.groupBy('YEAR','MONTH', 'ORIGIN').count().orderBy('ORIGIN')
data6_snapshot.show()

# COMMAND ----------

display(data_6)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Drop unnecessary columns

# COMMAND ----------

columns_to_drop = ["YEAR", "QUARTER" "OP_CARRIER", "TAIL_NUM", "OP_CARRIER_FL_NUM", "ORIGIN_AIRPORT_ID", 
                   "FL_DATE", "OP_CARRIER_AIRLINE_ID", "DEST_STATE_FIPS", "ARR_TIME_BLK", "DEP_TIME_BLK","DISTANCE_GROUP",
                   "ORIGIN_AIRPORT_SEQ_ID", "ORIGIN_CITY_NAME", "ORIGIN_STATE_FIPS", "ORIGIN_STATE_NM",
                   "ORIGIN_WAC", 'DEST_AIRPORT_ID','DEST_AIRPORT_SEQ_ID',"DEST_CITY_NAME", "DEST_STATE_FIPS",
                   'DEST_STATE_NM', 'DEST_WAC', 'CRS_DEP_TIME', 'CRS_ARR_TIME', 'DEP_TIME', 'ARR_TIME', "CANCELLED", "DIVERTED", 
                   "ACTUAL_ELAPSED_TIME", "FLIGHTS", "DIV_AIRPORT_LANDINGS", "ORIGIN_TS", "DEST_TS", "DEST_UTC",
                   "ORIGIN_STATION", "ORIGIN_STATION_NAME", "DEST_STATION","DEST_STATION_NAME", "ORIGIN_UTC_ADJ", "origin_max_date", 
                   "dest_max_date",'ARR_DELAY', 'ARR_DELAY_NEW', "ARR_DEL15", "ARR_DELAY_GROUP", "DEP_DELAY", "DEP_DELAY_NEW", "TAXI_OUT", 
                   'WHEELS_OFF', 'WHEELS_ON', 'TAXI_IN', 'AIR_TIME']

print(len(columns_to_drop))
data_6 = data_6.drop(*columns_to_drop)

# COMMAND ----------

data_6.printSchema()

# COMMAND ----------

#Remaining Columns
cat_cols = ['MONTH', 'DAY_OF_MONTH', 'DAY_OF_WEEK',
            'OP_UNIQUE_CARRIER', 'ORIGIN_CITY_MARKET_ID', 'ORIGIN',
            'ORIGIN_STATE_ABR', 'DEST_CITY_MARKET_ID', 'DEST',
            'DEST_STATE_ABR', 'ORIGIN_TZ', 'DEST_TZ', 'DEP_MIN', 
            'DEP_HOUR', 'ARR_MIN', 'ARR_HOUR']

num_cols = ['DISTANCE', 'CRS_ELAPSED_TIME','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
            'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
            'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
            'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
            'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
            'AVG_SLP_DEST']

label_cols = ['DEP_DEL15', 'DEP_DELAY_GROUP']

# COMMAND ----------

display(data_6)

# COMMAND ----------

data_6.groupBy('DEP_DELAY_GROUP').count().orderBy('DEP_DELAY_GROUP').show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Findings
# MAGIC These might have a pretty good correlation to delay, but we prolly CANNOT use it due to it being in the 2 hour window before depart time
# MAGIC * `TAXI_OUT` 
# MAGIC * `WHEELS_OFF`
# MAGIC * `WHEELS_ON`
# MAGIC * `TAXI_IN`
# MAGIC * `CRS_ELAPSED_TIME`
# MAGIC * `AIR_TIME`

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### DEP_DELAY_GROUP - categorical that we could predict!! 
# MAGIC 
# MAGIC |Code|Description                     |
# MAGIC |----|--------------------------------|
# MAGIC |-2  |Delay < -15 minutes             |
# MAGIC |-1  |Delay between -15 and -1 minutes|
# MAGIC |0   |Delay between 0 and 14 minutes  |
# MAGIC |1   |Delay between 15 to 29 minutes  |
# MAGIC |2   |Delay between 30 to 44 minutes  |
# MAGIC |3   |Delay between 45 to 59 minutes  |
# MAGIC |4   |Delay between 60 to 74 minutes  |
# MAGIC |5   |Delay between 75 to 89 minutes  |
# MAGIC |6   |Delay between 90 to 104 minutes |
# MAGIC |7   |Delay between 105 to 119 minutes|
# MAGIC |8   |Delay between 120 to 134 minutes|
# MAGIC |9   |Delay between 135 to 149 minutes|
# MAGIC |10  |Delay between 150 to 164 minutes|
# MAGIC |11  |Delay between 165 to 179 minutes|
# MAGIC |12  |Delay >= 180 minutes            |

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Train/ Test Split
# MAGIC 
# MAGIC **All models account for the time series nature of our data**
# MAGIC 
# MAGIC **PERCENT_RANK:** https://www.sqlservertutorial.net/sql-server-window-functions/sql-server-percent_rank-function/
# MAGIC 
# MAGIC **Approach:** https://stackoverflow.com/questions/51772908/split-time-series-pyspark-data-frame-into-test-train-without-using-random-spli
# MAGIC 
# MAGIC We treat the whole data as a one big partition, and get a cumulative spread of the ranking of each record by `ORIGIN_UTC`, then we can do an even train/test split

# COMMAND ----------

display(data_6)

# COMMAND ----------

data_6_order = data_6.withColumn("time_rank", f.percent_rank().over(Window.partitionBy().orderBy("ORIGIN_UTC")))
display(data_6_order)

# COMMAND ----------

data_6_order.select("time_rank").show(10)

# COMMAND ----------

data_6_order = data_6.withColumn("time_rank", f.percent_rank().over(Window.partitionBy().orderBy("ORIGIN_UTC")))
train = data_6_order.where("time_rank <= .8").drop("time_rank")
test = data_6_order.where("time_rank > .8").drop("time_rank")

print("Train size: ", train.count())
print("Test size: ", test.count())

# COMMAND ----------

data_6_order.groupBy("time_rank").count().orderBy(f.desc("count")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Writing the train/ test data to DBFS

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/6m_train_test/train", True)

#Write cleaned airlines data to our store
train.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/6m_train_test/train")

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/mids-w261/team20SSDK/6m_train_test/test", True)

#Write cleaned airlines data to our store
test.write.parquet("dbfs:/mnt/mids-w261/team20SSDK/6m_train_test/test")

# COMMAND ----------

train.groupBy('DEP_DEL15').count().orderBy('count').show()

# COMMAND ----------

test.groupBy('DEP_DEL15').count().orderBy('count').show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC ### Model #1 - LogReg (numerical)
# MAGIC - Features:
# MAGIC             ['DISTANCE', 'ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
# MAGIC              'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
# MAGIC              'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
# MAGIC              'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
# MAGIC              'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
# MAGIC              'AVG_SLP_DEST']
# MAGIC 
# MAGIC 
# MAGIC - Label:
# MAGIC             ['DEP_DEL15']

# COMMAND ----------

m1_cols = ['DISTANCE','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
       'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
       'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
       'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
       'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
       'AVG_SLP_DEST', 'DEP_DEL15']

m1_train = train.select(*m1_cols).withColumnRenamed('DEP_DEL15', 'label') 
m1_test = test.select(*m1_cols).withColumnRenamed('DEP_DEL15', 'label') 

# COMMAND ----------

# MAGIC %md
# MAGIC Below is the step by step way, but the other option is to use Pipeline for preprocesing the data, then building the LogReg model on train
# MAGIC 
# MAGIC ##### Steps:
# MAGIC * Vector Assembler
# MAGIC * Standardize Can also try MinMaxScaler
# MAGIC * Build LogReg Model
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC #### Pipeline:
# MAGIC 
# MAGIC Pipeline is used to pre-process the train and then transform (predict) on the test data

# COMMAND ----------

# Line by line steps
vector_assembler = VectorAssembler(inputCols=m1_cols[:-1], outputCol="SS_features")
standard_scaler = StandardScaler(inputCol="SS_features", outputCol="features")
lr = LogisticRegression()
stages = [vector_assembler, standard_scaler, lr]
stages

# COMMAND ----------

# MAGIC  %%time
# MAGIC m1_pipeline = Pipeline().setStages(stages)
# MAGIC m1_model = m1_pipeline.fit(m1_train) #Fit the pipeline on the training data
# MAGIC m1_results = m1_model.transform(m1_test) #transform the test set with the pipeline, don't want to fit on this.

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC #### Evaluation

# COMMAND ----------

m1_results.printSchema()

# COMMAND ----------

predAndLabels = m1_results.select(col("prediction").alias("raw"),"label")

# COMMAND ----------

#Set up BinClassEval
evaluator = BinaryClassificationEvaluator()
evaluator.setRawPredictionCol("raw")

# COMMAND ----------

print("areaUnderPR: ", evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderPR"}))
print("areaUnderROC: ",evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderROC"}))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC ### Model #2 - LogReg (numerical) + weight balancing ratio
# MAGIC - Features:
# MAGIC             ['DISTANCE', 'CRS_ELAPSED_TIME','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
# MAGIC              'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
# MAGIC              'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
# MAGIC              'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
# MAGIC              'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
# MAGIC              'AVG_SLP_DEST']
# MAGIC 
# MAGIC 
# MAGIC * adding in 'CRS_ELAPSED_TIME'
# MAGIC 
# MAGIC - Label:
# MAGIC             ['DEP_DEL15']

# COMMAND ----------

# MAGIC %md
# MAGIC #### Handling Imbalanced Data - Sanjay's logic
# MAGIC 
# MAGIC * https://stackoverflow.com/questions/33372838/dealing-with-unbalanced-datasets-in-spark-mllib

# COMMAND ----------

m2_cols = ['DISTANCE', 'CRS_ELAPSED_TIME','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
       'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
       'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
       'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
       'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
       'AVG_SLP_DEST', 'DEP_DEL15']

m2_train = train.select(*m2_cols).withColumnRenamed('DEP_DEL15', 'label')
m2_test = test.select(*m2_cols).withColumnRenamed('DEP_DEL15', 'label')


# COMMAND ----------

balancing_ratio = m2_train.filter("label == 0").count() / m2_train.count()
print("Balancing Ratio =", balancing_ratio) #0.789
m2_train = m2_train.withColumn("CLASS_WEIGHTS", when(m2_train.label == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

# COMMAND ----------

m2_train = m2_train.withColumn("CLASS_WEIGHTS", when(m2_train.label == 1, balancing_ratio).otherwise(1 - balancing_ratio))

# COMMAND ----------

# Line by line steps
vector_assembler = VectorAssembler(inputCols=m2_cols[:-1], outputCol="SS_features")
standard_scaler = StandardScaler(inputCol="SS_features", outputCol="features")
lr = LogisticRegression(weightCol="CLASS_WEIGHTS")

#Pipeline 
stages = [vector_assembler,standard_scaler, lr]
m2_pipeline = Pipeline().setStages(stages)
m2_model = m2_pipeline.fit(m2_train) #Fit the pipeline on the training data
m2_results = m2_model.transform(m2_test) #transform the test set with the pipeline, don't want to fit on this.

# COMMAND ----------

predAndLabels = m2_results.select(col("prediction").alias("raw"),"label")
predAndLabelsTrain = m2_model.transform(m2_train).select(col("prediction").alias("raw"),"label")  #transform the test set with the pipeline, don't want to fit on this.

#Set up BinClassEval
evaluator = BinaryClassificationEvaluator()
evaluator.setRawPredictionCol("raw")

print("Train Set")
print("areaUnderPR: ", evaluator.evaluate(predAndLabelsTrain, {evaluator.metricName: "areaUnderPR"}))
print("areaUnderROC: ",evaluator.evaluate(predAndLabelsTrain, {evaluator.metricName: "areaUnderROC"}))


print("Test Set")
print("areaUnderPR: ", evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderPR"}))
print("areaUnderROC: ",evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderROC"}))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Build a Confusion Matrix

# COMMAND ----------

from sklearn.metrics import confusion_matrix
predLabels = predAndLabels.collect()
y_true = [x.label for x in predLabels]
y_pred = [x.raw for x in predLabels]
conf_mat = confusion_matrix(y_true, y_pred)

# COMMAND ----------

from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import classification_report

print("Accuracy Score: ", accuracy_score(y_true, y_pred))
print("F1 Score: ", f1_score(y_true, y_pred))
print(classification_report(y_true, y_pred))

# COMMAND ----------

conf_mat

# COMMAND ----------

import seaborn as sn
import matplotlib.pyplot as plt

df_cm = pd.DataFrame(conf_mat, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC ### Model #3 - LogReg (numerical) + weight balancing ratio + hyper parameter tuning 
# MAGIC - Features:
# MAGIC             ['DISTANCE', 'ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
# MAGIC              'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
# MAGIC              'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
# MAGIC              'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
# MAGIC              'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
# MAGIC              'AVG_SLP_DEST']
# MAGIC 
# MAGIC 
# MAGIC - Label:
# MAGIC             ['DEP_DEL15']

# COMMAND ----------

m3_cols = ['DISTANCE', 'CRS_ELAPSED_TIME','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
       'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
       'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
       'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
       'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
       'AVG_SLP_DEST', 'DEP_DEL15']

m3_train = train.select(*m3_cols).withColumnRenamed('DEP_DEL15', 'label')
m3_test = test.select(*m3_cols).withColumnRenamed('DEP_DEL15', 'label')


# COMMAND ----------

balancing_ratio = m3_train.filter("label == 0").count() / m3_train.count()
m3_train = m3_train.withColumn("CLASS_WEIGHTS", when(m3_train.label == 1, balancing_ratio).otherwise(1 - balancing_ratio))

# COMMAND ----------

#Stages
vector_assembler = VectorAssembler(inputCols=m3_cols[:-1], outputCol="SS_features")
standard_scaler = StandardScaler(inputCol="SS_features", outputCol="features")
lr = LogisticRegression(weightCol="CLASS_WEIGHTS")

#Pipeline 
stages = [vector_assembler,standard_scaler, lr]
m3_pipeline = Pipeline().setStages(stages)


# We now treat the Pipeline as an Estimator, wrapping it in a CrossValidator instance.
# This will allow us to jointly choose parameters for all Pipeline stages.
# A CrossValidator requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
# We use a ParamGridBuilder to construct a grid of parameters to search over.
# This grid will have 7 x 2 x 7 x 3 = 294 parameter settings for CrossValidator to choose from.

# Hyper Parameter tuning
# Elastic regualarization, so that parameters don't over dominate to prevent overfitting (Combo of L1 + L2)
paramGrid = ParamGridBuilder() \
            .addGrid(lr.regParam, [0.5, 0.3, 0.1, 0.05, 0.01, 0.005, 0.001]) \
            .addGrid(lr.fitIntercept, [False, True]) \
            .addGrid(lr.elasticNetParam, [0.5, 0.3, 0.1, 0.05, 0.01, 0.005, 0.001]) \
            .build()

crossval = CrossValidator(estimator=m3_pipeline,
                          estimatorParamMaps=paramGrid,
                          evaluator=BinaryClassificationEvaluator(),
                          numFolds=3)  # use 3+ folds in practice

# #Elastic regualarization, so that parameters don't over dominate to prevent overfitting (Combo of L1 + L2)
# paramGrid = ParamGridBuilder() \
#             .addGrid(lr.regParam, [0.5, 0.1, 0.01]) \
#             .addGrid(lr.fitIntercept, [False, True]) \
#             .addGrid(lr.elasticNetParam, [0.5, 0.1, 0.01]) \
#             .build()

# crossval = CrossValidator(estimator=m3_pipeline,
#                           estimatorParamMaps=paramGrid,
#                           evaluator=BinaryClassificationEvaluator(),
#                           numFolds=3)  # use 3+ folds in practice


# Run cross-validation, and choose the best set of parameters.
cvModel = crossval.fit(m3_train)

# Make predictions on test documents. cvModel uses the best model found (lrModel).
m3_results = cvModel.transform(m3_test)

# COMMAND ----------

#Save the model out in case we need to reference again in the future
cvModel.save("dbfs:/mnt/mids-w261/team20SSDK/models/logRegCV")

# COMMAND ----------

# cvModel.stages[-1].coefficients

cvModel.bestModel.stages

# COMMAND ----------

bestModel = cvModel.bestModel
print("Best Param (regParam)", bestModel.__java_obj.getRegParam())
print("Best Param (elasticNetParam)", bestModel.__java_obj.getElasticNetParam())

# COMMAND ----------

predAndLabels = m3_results.select(col("prediction").alias("raw"),"label")

#Set up BinClassEval
evaluator = BinaryClassificationEvaluator()
evaluator.setRawPredictionCol("raw")

print("areaUnderPR: ", evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderPR"}))
print("areaUnderROC: ",evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderROC"}))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC 
# MAGIC ### Model #4 - LogReg (numerical) + weight balancing ratio + hyper parameter tuning + CV
# MAGIC - Features:
# MAGIC             ['DISTANCE', 'CRS_ELAPSED_TIME', 'ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
# MAGIC              'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
# MAGIC              'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
# MAGIC              'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
# MAGIC              'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
# MAGIC              'AVG_SLP_DEST']
# MAGIC 
# MAGIC 
# MAGIC - Label:
# MAGIC             ['DEP_DEL15']

# COMMAND ----------

m4_cols = ['DISTANCE', 'CRS_ELAPSED_TIME','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT', 'PAGERANK',
       'AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN',
       'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN',
       'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST',
       'MIN_VIS_DIS_DEST', 'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST',
       'AVG_SLP_DEST', 'DEP_DEL15']

m4_train = train.select(*m4_cols).withColumnRenamed('DEP_DEL15', 'label')
m4_test = test.select(*m4_cols).withColumnRenamed('DEP_DEL15', 'label')


# COMMAND ----------

balancing_ratio = m4_train.filter("label == 0").count() / m4_train.count()
m4_train = m4_train.withColumn("CLASS_WEIGHTS", when(m4_train.label == 1, balancing_ratio).otherwise(1 - balancing_ratio))

# COMMAND ----------

display(m4_train)

# COMMAND ----------

#Stages
vector_assembler = VectorAssembler(inputCols=m4_cols[:-1], outputCol="SS_features")
standard_scaler = StandardScaler(inputCol="SS_features", outputCol="features")
lr = LogisticRegression(weightCol="CLASS_WEIGHTS", maxIter=10, regParam= 1.0, elasticNetParam = 1.0)

#Pipeline 
stages = [vector_assembler,standard_scaler, lr]
m4_pipeline = Pipeline().setStages(stages)


m4_model = m4_pipeline.fit(m4_train) #Fit the pipeline on the training data
m4_results = m4_model.transform(m4_test) #transform the test set with the pipeline, don't want to fit on this.

# We now treat the Pipeline as an Estimator, wrapping it in a CrossValidator instance.
# This will allow us to jointly choose parameters for all Pipeline stages.
# A CrossValidator requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
# We use a ParamGridBuilder to construct a grid of parameters to search over.
# This grid will have 7 x 2 x 7 x 3 = 294 parameter settings for CrossValidator to choose from.

# crossval = CrossValidator(estimator=m4_pipeline,
#                           estimatorParamMaps=paramGrid,
#                           evaluator=BinaryClassificationEvaluator(),
#                           numFolds=3)  # use 3+ folds in practice

# Run cross-validation, and choose the best set of parameters.
# cvModel = crossval.fit(m4_train)

# Make predictions on test documents. cvModel uses the best model found (lrModel).
# m4_results = cvModel.transform(m3_test)

# COMMAND ----------

m4_train_results = m4_model.transform(m4_train)
predAndLabels = m4_train_results.select(col("prediction").alias("raw"),"label")

#Set up BinClassEval
evaluator = BinaryClassificationEvaluator()
evaluator.setRawPredictionCol("raw")

print("areaUnderPR: ", evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderPR"}))
print("areaUnderROC: ",evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderROC"}))

# COMMAND ----------

predAndLabels = m4_results.select(col("prediction").alias("raw"),"label")

#Set up BinClassEval
evaluator = BinaryClassificationEvaluator()
evaluator.setRawPredictionCol("raw")

print("areaUnderPR: ", evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderPR"}))
print("areaUnderROC: ",evaluator.evaluate(predAndLabels, {evaluator.metricName: "areaUnderROC"}))

# COMMAND ----------

predLabels = predAndLabels.collect()
y_true = [x.label for x in predLabels]
y_pred = [x.raw for x in predLabels]
conf_mat = confusion_matrix(y_true, y_pred)

print("Accuracy Score: ", accuracy_score(y_true, y_pred))
print("F1 Score: ", f1_score(y_true, y_pred))
print(classification_report(y_true, y_pred))

# COMMAND ----------


