# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, NullType, ShortType, DateType, BooleanType, BinaryType
from pyspark.sql import SQLContext
from pyspark.sql.functions import concat, col, hour, minute, lpad, rpad, substring, year, month, dayofmonth, lit, to_timestamp, expr,split,explode,split
from pyspark.sql.functions import isnan, when, count, col,isnull
from pyspark.mllib import *

from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

import numpy as np
#spark = SparkSession.builder.getOrCreate()

sqlContext = SQLContext(sc)

# COMMAND ----------

df = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/final_datasets/data_range/")



# COMMAND ----------

# MAGIC %md
# MAGIC ### The Dataset is hugely imbalanced, We'll balance it with class weighings

# COMMAND ----------

dataset_size = df.count()
print(f'dataset_size = {dataset_size}')

# COMMAND ----------

num_delayed = df.filter(df['DEP_DEL15'] == 1).count()
print(f'num_delayed = {num_delayed}')


num_not_delayed = df.filter(df['DEP_DEL15'] == 0).count()
print(f'num_not_delayed = {num_not_delayed}')

# COMMAND ----------


BalancingRatio= num_not_delayed /dataset_size
print('BalancingRatio = {}'.format(BalancingRatio))

# COMMAND ----------

#Adding the column in the data frame
df =df.withColumn("classWeights", when(df.DEP_DEL15 == 1,BalancingRatio).otherwise(1-BalancingRatio))
df.select("classWeights").show(5)

# COMMAND ----------

#Scaling the variables because WND and Temp measurements are scaled by 10.
df = df.withColumn('AVG_WND_SPEED_ORIGIN', df.AVG_WND_SPEED_ORIGIN/10)
df = df.withColumn('AVG_TMP_DEG_ORIGIN', df.AVG_TMP_DEG_ORIGIN/10)
df = df.withColumn('AVG_DEW_DEG_ORIGIN', df.AVG_DEW_DEG_ORIGIN/10)
df = df.withColumn('AVG_WND_SPEED_DEST', df.AVG_WND_SPEED_DEST/10)



# COMMAND ----------

#Restricing the dataset to 2015 Q1 and to Origin to ORD and ATL
df_Q1_15 = df.filter(((df['ORIGIN'] =='ORD') | (df['ORIGIN'] =='ATL')) & (df['QUARTER'] == 1) & (df['YEAR'] == 2015))

# COMMAND ----------

DROPPED = ['ORIGIN_AIRPORT_SEQ_ID','ORIGIN_CITY_MARKET_ID','ORIGIN_STATE_ABR', 'ORIGIN_STATE_FIPS', 'ORIGIN_STATE_NM', 'ORIGIN_WAC', 'DEST_AIRPORT_ID', 'DEST_AIRPORT_SEQ_ID',
 'DEST_CITY_MARKET_ID','ORIGIN_CITY_NAME','DEST_CITY_NAME', 'DEST_STATE_ABR', 'DEST_STATE_FIPS', 'DEST_STATE_NM', 'DEST_WAC','TAXI_IN',  'CANCELLED', 'DIVERTED', 'CRS_ELAPSED_TIME', 'ACTUAL_ELAPSED_TIME', 'AIR_TIME','origin_max_date', 'dest_max_date','OP_CARRIER','ORIGIN_AIRPORT_ID','ORIGIN_AIRPORT_ID','CRS_DEP_TIME','WHEELS_ON',  'FLIGHTS','DIV_AIRPORT_LANDINGS','ORIGIN_TZ','DEST_TZ','DEST_STATION', 'DEST_STATION_NAME', 'ORIGIN_UTC_ADJ','TAIL_NUM','ORIGIN_TS', 'DEST_TS', 'DEST_UTC', 'ORIGIN_STATION', 'ORIGIN_STATION_NAME','OP_CARRIER_FL_NUM','OP_UNIQUE_CARRIER','FL_DATE']

cat_cols = ['DAY_OF_MONTH', 'DAY_OF_WEEK','OP_CARRIER_AIRLINE_ID', 'ORIGIN', 'DEST', 'DEP_TIME_BLK',  'DISTANCE_GROUP', 'MONTH']

num_cols = [ 'TAXI_OUT','AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN', 'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN', 'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST','DISTANCE','MIN_VIS_DIS_DEST','AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST', 'AVG_SLP_DEST' ,'WHEELS_OFF','PAGERANK','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT','DEP_MIN', 'DEP_HOUR', 'ARR_MIN', 'ARR_HOUR']

weights = 'classWeights'

label = 'DEP_DEL15','DEP_DELAY_GROUP'

# COMMAND ----------

# MAGIC %md 
# MAGIC ### One hot encoder

# COMMAND ----------

#creating a truncated dataframe 
trunc_df = df_Q1_15[['DAY_OF_MONTH', 'DAY_OF_WEEK','OP_CARRIER_AIRLINE_ID', 'ORIGIN', 'DEST', 'DEP_TIME_BLK',  'DISTANCE_GROUP', 'MONTH','TAXI_OUT','AVG_WND_SPEED_ORIGIN', 'MIN_CIG_HEIGHT_ORIGIN', 'MIN_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN', 'AVG_DEW_DEG_ORIGIN', 'AVG_SLP_ORIGIN', 'AVG_WND_SPEED_DEST', 'MIN_CIG_HEIGHT_DEST','DISTANCE','MIN_VIS_DIS_DEST','AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_DEST', 'AVG_SLP_DEST' ,'WHEELS_OFF',
 'DEP_DELAY_GROUP','PAGERANK','ORIGIN_FLIGHT_COUNT', 'DEST_FLIGHT_COUNT','DEP_MIN', 'DEP_HOUR', 'ARR_MIN', 'ARR_HOUR','classWeights','DEP_DEL15','ORIGIN_UTC']]




# COMMAND ----------

from pyspark.ml.feature import StringIndexer,OneHotEncoder
cat_cols_indexed = [x+"_string_indexer" for x in cat_cols]
#print(cat_cols_indexed)
for i in range(0,len(cat_cols)):
  cat_cols_indexed[i] = StringIndexer(inputCol = cat_cols[i] , outputCol= cat_cols[i] +"_StringIndexer",handleInvalid='skip')
  

# COMMAND ----------

for i in range(0,len(cat_cols_indexed)):
  trunc_df = cat_cols_indexed[i].fit(trunc_df).transform(trunc_df)

# COMMAND ----------

#sending the output of String Indexer into OHE.

from pyspark.ml.feature import OneHotEncoder
cat_cols_one_hot = ['DAY_OF_MONTH_StringIndexer', 'DAY_OF_WEEK_StringIndexer', 'OP_CARRIER_AIRLINE_ID_StringIndexer', 'ORIGIN_StringIndexer', 'DEST_StringIndexer', 'DEP_TIME_BLK_StringIndexer', 'DISTANCE_GROUP_StringIndexer',  'MONTH_StringIndexer']
#print(cat_cols_indexed)
for i in range(0,len(cat_cols_one_hot)):
  cat_cols_one_hot[i] = OneHotEncoder(inputCol = cat_cols_one_hot[i] , outputCol= cat_cols_one_hot[i] +"_ohe")
  


# COMMAND ----------

#adding those OHE columnt to the truncated dataframe(with dropped columns)
for i in range(0,len(cat_cols_one_hot)):
  trunc_df = cat_cols_one_hot[i].fit(trunc_df).transform(trunc_df)

# COMMAND ----------

#preparing colums for input to vector assembler
encoded_cols = ['DAY_OF_MONTH_StringIndexer_ohe',
 'DAY_OF_WEEK_StringIndexer_ohe',
 'OP_CARRIER_AIRLINE_ID_StringIndexer_ohe',
 'ORIGIN_StringIndexer_ohe',
 'DEST_StringIndexer_ohe',
 'DEP_TIME_BLK_StringIndexer_ohe',
 'DISTANCE_GROUP_StringIndexer_ohe',
 'MONTH_StringIndexer_ohe']

assembler_cols = [num_cols.append(col) for col in encoded_cols]
assembler_cols = num_cols


# COMMAND ----------

print(assembler_cols)

# COMMAND ----------

from pyspark.ml.feature import VectorAssembler
assembler = VectorAssembler(inputCols=assembler_cols,outputCol="features",handleInvalid='skip')

# COMMAND ----------

one_hot_encoded_trunc_df =assembler.transform(trunc_df)
one_hot_encoded_trunc_df.select("features").display(truncate=False)

# COMMAND ----------

one_hot_encoded_trunc_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Original dataset size was 24603731 and now we are down to 24603083 . We've lost 700 records as a result of 'skip' operation in vector assembler

# COMMAND ----------

# MAGIC %md
# MAGIC ### Separting 2019 data as test data
# MAGIC We only want 2015-2018 data for training and val.
# MAGIC In the cells below we split the dataset.

# COMMAND ----------

df_temp = one_hot_encoded_trunc_df.filter(df['YEAR']<2019)

# COMMAND ----------

df_test = one_hot_encoded_trunc_df.filter(df['YEAR']== 2019)

# COMMAND ----------

#Validating the total 
print(df_temp.count()+df_test.count())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Let's do a train Val split- based on timeseries split.

# COMMAND ----------

#Renaiming the dependent variable to label
df_temp = df_temp.withColumnRenamed('DEP_DEL15', 'label')


# COMMAND ----------

from pyspark.sql import Window
df_temp_order = df_temp.withColumn("time_rank", f.percent_rank().over(Window.partitionBy().orderBy("ORIGIN_UTC")))
#display(df_temp_order)

# COMMAND ----------

train_df = df_temp_order.where("time_rank <= .8").drop("time_rank")
val_df = df_temp_order.where("time_rank > .8").drop("time_rank")

print("Train size: ", train_df.count())
print("Test size: ", val_df.count())


# COMMAND ----------

# MAGIC %md 
# MAGIC ### Modeling

# COMMAND ----------

# MAGIC %md
# MAGIC ### Let's try to map features and coefficients
# MAGIC (reference)[https://stackoverflow.com/questions/42935914/how-to-map-features-from-the-output-of-a-vectorassembler-back-to-the-column-name]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Let's now try to include the Interaction terms for weather

# COMMAND ----------

#New Data frame with interaction terms for ORIGIN weather
train_df_interaction =  train_df.withColumn('combined_weather_ORIGIN',train_df.AVG_WND_SPEED_ORIGIN*train_df.MIN_CIG_HEIGHT_ORIGIN*train_df.MIN_VIS_DIS_ORIGIN*train_df.AVG_TMP_DEG_ORIGIN*train_df.AVG_DEW_DEG_ORIGIN*train_df.AVG_SLP_ORIGIN)



# COMMAND ----------

#New Data frame with interaction terms for DEST weather
train_df_interaction =  train_df_interaction.withColumn('combined_weather_DEST',train_df.AVG_WND_SPEED_DEST*train_df.MIN_CIG_HEIGHT_DEST*train_df.MIN_VIS_DIS_DEST*train_df.AVG_TMP_DEG_DEST*train_df.AVG_DEW_DEG_DEST*train_df.AVG_SLP_DEST)




# COMMAND ----------

#New Data frame with interaction terms for ORIGIN weather

val_df_interaction =  val_df.withColumn('combined_weather_ORIGIN',train_df.AVG_WND_SPEED_ORIGIN*train_df.MIN_CIG_HEIGHT_ORIGIN*train_df.MIN_VIS_DIS_ORIGIN*train_df.AVG_TMP_DEG_ORIGIN*train_df.AVG_DEW_DEG_ORIGIN*train_df.AVG_SLP_ORIGIN)



# COMMAND ----------

#New Data frame with interaction terms for DEST weather

val_df_interaction =  val_df_interaction.withColumn('combined_weather_DEST',train_df.AVG_WND_SPEED_DEST*train_df.MIN_CIG_HEIGHT_DEST*train_df.MIN_VIS_DIS_DEST*train_df.AVG_TMP_DEG_DEST*train_df.AVG_DEW_DEG_DEST*train_df.AVG_SLP_DEST)



# COMMAND ----------

#New Data frame with interaction terms for ORIGIN weather


df_test_interaction =  df_test.withColumn('combined_weather_ORIGIN',train_df.AVG_WND_SPEED_ORIGIN*train_df.MIN_CIG_HEIGHT_ORIGIN*train_df.MIN_VIS_DIS_ORIGIN*train_df.AVG_TMP_DEG_ORIGIN*train_df.AVG_DEW_DEG_ORIGIN*train_df.AVG_SLP_ORIGIN)




# COMMAND ----------

#New Data frame with interaction terms for DEST weather

df_test_interaction =  df_test_interaction.withColumn('combined_weather_DEST',train_df.AVG_WND_SPEED_DEST*train_df.MIN_CIG_HEIGHT_DEST*train_df.MIN_VIS_DIS_DEST*train_df.AVG_TMP_DEG_DEST*train_df.AVG_DEW_DEG_DEST*train_df.AVG_SLP_DEST)

# COMMAND ----------

#Addiing the new cols to assembler
#preparing colums for input to vector assembler
encoded_cols = ['DAY_OF_MONTH_StringIndexer_ohe',
 'DAY_OF_WEEK_StringIndexer_ohe',
 'OP_CARRIER_AIRLINE_ID_StringIndexer_ohe',
 'ORIGIN_StringIndexer_ohe',
 'DEST_StringIndexer_ohe',
 'DEP_TIME_BLK_StringIndexer_ohe',
 'DISTANCE_GROUP_StringIndexer_ohe',
 
 'MONTH_StringIndexer_ohe']

num_cols.append('combined_weather_DEST')
num_cols.append('combined_weather_ORIGIN')

assembler_cols = [num_cols.append(col) for col in encoded_cols]
assembler_cols = num_cols



# COMMAND ----------

#Dropping the features column from train:
#df = df.drop("address", "phoneNumber")
train_df_interaction = train_df_interaction.drop('features')


# COMMAND ----------

# creating a new feature column with the new interaction term for training
from pyspark.ml.feature import VectorAssembler
assembler = VectorAssembler(inputCols=assembler_cols,outputCol="features",handleInvalid='skip')

# COMMAND ----------

# creating a new feature column with the new interaction term for training
train_df_interaction =assembler.transform(train_df_interaction)
train_df_interaction.select("features").display(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Standardization 0mean and 1 std. Deviation

# COMMAND ----------

from pyspark.ml.feature import StandardScaler
standardscaler=StandardScaler().setInputCol("features").setOutputCol("Scaled_features")
std_train_df_interaction=standardscaler.fit(train_df_interaction).transform(train_df_interaction)
std_train_df_interaction.select("features","Scaled_features").display(truncate=False)

# COMMAND ----------

#Dropping the 'features' column
val_df_interaction = val_df_interaction.drop('features')


# COMMAND ----------

# creating a new feature column with the new interaction term for VAl
val_df_interaction =assembler.transform(val_df_interaction)

# COMMAND ----------

#Standardizing the validation set
standardscaler=StandardScaler().setInputCol("features").setOutputCol("Scaled_features")
std_val_df_interaction=standardscaler.fit(val_df_interaction).transform(val_df_interaction)
#std_val_df_interaction.select("features","Scaled_features").display(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Modeling

# COMMAND ----------

from pyspark.ml.classification import LogisticRegression
# lr = LogisticRegression().setWeightCol("classWeights").setLabelCol("Outcome").setFeaturesCol("Aspect")
#lr = LogisticRegression(labelCol="DEP_DEL15", featuresCol="features",weightCol="classWeights",maxIter=10)
lr = LogisticRegression(labelCol="label", featuresCol="Scaled_features",weightCol="classWeights",maxIter=10)
model=lr.fit(std_train_df_interaction)
predict_train=model.transform(std_train_df_interaction)

predict_test=model.transform(std_val_df_interaction)
predict_test.select("label","prediction").show(10)
from sklearn.metrics import confusion_matrix


trainScoreAndLabels = predict_train.select(['probability','label', f.col("prediction").alias("raw")])
valScoreAndLabels = predict_test.select(['probability','label', f.col("prediction").alias("raw")])


# To print confusion metrics
trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
valScoreAndLabels_pd = valScoreAndLabels.toPandas()
    
y_train_true = trainScoreAndLabels_pd["label"]
y_train_pred = trainScoreAndLabels_pd["raw"]
conf_mat_train = confusion_matrix(y_train_true, y_train_pred)
    
    
    
y_val_true = valScoreAndLabels_pd["label"]
y_val_pred = valScoreAndLabels_pd["raw"]
conf_mat_val = confusion_matrix(y_val_true, y_val_pred)
    
print("Accuracy Score: ", accuracy_score(y_val_true, y_val_pred))
print("F1 Score: ", f1_score(y_val_true, y_val_pred))
print(classification_report(y_val_true, y_val_pred))


# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------




# COMMAND ----------


