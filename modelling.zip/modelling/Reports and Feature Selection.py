# Databricks notebook source
import seaborn as sn
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_auc_score

import pandas as pd
import numpy as np
import collections

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Model Analysis
# MAGIC From our model pipeline process, using **ML Flow** we have logged and saved our model outputs. This includes, the actual model, the predictions (train + validation), and the feature importance rankings. Based on the various outputs from our train and validation we would like to evaluate and reason which model is our best performer.
# MAGIC 
# MAGIC ##### Goal:
# MAGIC Choose the best model based on various performance metrics and gather it's features ranked by featured importance. From this model take note of the hyper parameters, as well as choose the top `N` number of non-colinear features.
# MAGIC 
# MAGIC 
# MAGIC We hope that with these finalized hyperparams and features we can build a final model that produces accurate predictions, generalizes well to unseen data, and is parsimonious

# COMMAND ----------

# MAGIC %md
# MAGIC #### Documentation for metric calculations
# MAGIC 
# MAGIC * [Classification Report]
# MAGIC * [Confusion Matrix]
# MAGIC * [ROC_AUC]
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC [Classification Report]:https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html
# MAGIC [Confusion Matrix]:https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html
# MAGIC [ROC_AUC]:https://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_auc_score.html

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read the outputs from our store in DBFS
# MAGIC 
# MAGIC Organized into a nested dictionary structure for use throughout this report. For simplicity, we are manuallly adding the hyper parameters that were used, for each model.

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Note: We have a separate models that were built by Devesh, to bring in his data we are storing it manually here in a dictionary to read and to populate

# COMMAND ----------

devesh_models = {}

devesh_models["rf_model_6"] = {'name': "rf_model_6", 'numTree':48,'maxDepth':12 ,'accuracy':.73,'roc_auc':.68, 'weighted avg_f1-score':.75, 'macro avg_f1-score':.64,'weighted avg_precision':.8, 'macro avg_precision':.63, 'weighted avg_recall':.73, 'macro avg_recall':.68,'weighted avg_support':701462, 'macro avg_support':.71, '0.0_f1-score':.82, '1.0_f1-score':.45, '0.0_precision':.90, '1.0_precision':.36, '0.0_recall':.76, '1.0_recall':.61, '0.0_support':577311, '1.0_support':1298351,'tn':0,'fp':0,'fn':0,'tp':0}

devesh_models["rf_model_7"] = {'name': "rf_model_7", 'numTree':52,'maxDepth':13 ,'accuracy':.73,'roc_auc':.68, 'weighted avg_f1-score':.75, 'macro avg_f1-score':.64, 'weighted avg_precision':.8, 'macro avg_precision':.63, 'weighted avg_recall':.73, 'macro avg_recall':.68,'weighted avg_support':7071462, 'macro avg_support':.71, '0.0_f1-score':.82, '1.0_f1-score':.45, '0.0_precision':.90, '1.0_precision':.36, '0.0_recall':.76, '1.0_recall':.61, '0.0_support':577311, '1.0_support':1298351, 'tn':0,'fp':0,'fn':0,'tp':0}

devesh_models["rf_model_8"] = {'name': "rf_model_8", 'numTree':56,'maxDepth':14 ,'accuracy':.73,'roc_auc':.68, 'weighted avg_f1-score':.73, 'macro avg_f1-score':.63,'weighted avg_precision':.8, 'macro avg_precision':.63, 'weighted avg_recall':.73, 'macro avg_recall':.68,'weighted avg_support':7071462, 'macro avg_support':.71, '0.0_f1-score':.82, '1.0_f1-score':.45, '0.0_precision':.89, '1.0_precision':.36, '0.0_recall':.76, '1.0_recall':.60, '0.0_support':577311, '1.0_support':1298351, 'tn':0,'fp':0,'fn':0,'tp':0}

devesh_models["rf_model_9"] = {'name': "rf_model_9", 'numTree':60,'maxDepth':15 ,'accuracy':.74,'roc_auc':.68, 'weighted avg_f1-score':.76, 'macro avg_f1-score':.64,'weighted avg_precision':.8, 'macro avg_precision':.63, 'weighted avg_recall':.74, 'macro avg_recall':.68,'weighted avg_support':7071462, 'macro avg_support':7071462, '0.0_f1-score':.83, '1.0_f1-score':.46, '0.0_precision':.89, '1.0_precision':.37, '0.0_recall':.78, '1.0_recall':.58, '0.0_support':577311, '1.0_support':1298351,'tn':0,'fp':0,'fn':0,'tp':0}

# COMMAND ----------

# MAGIC %%time
# MAGIC #Extract it all to evaluate later on.
# MAGIC model_versions = ['rd_model_2','rf_model_3','rf_model_4','rf_model_5',
# MAGIC                   'rf_model_6','rf_model_7','rf_model_8','rf_model_9',
# MAGIC                   'rf_model_21','rf_model_22','rf_model_24','rf_model_25',
# MAGIC                   'rf_model_27' ]
# MAGIC 
# MAGIC #Indexes align to model_versions
# MAGIC # i.e. (numTree, maxDepth)
# MAGIC meta_param = [(50,25),(30,15),(30,15),(40,15),(48,12),(52,13),(56,14),(60,15),(40,15),(40,15),(60,15),(50,18),(40,15),(40,15)]
# MAGIC 
# MAGIC model_meta = {}
# MAGIC for ind, ver in enumerate(model_versions):
# MAGIC     print(f"Model #{ind}: {ver}")
# MAGIC     feat_imp = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{ver}/feat_imp.csv')
# MAGIC     if ver not in devesh_models:
# MAGIC         val_pred = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{ver}/val_pred.csv')
# MAGIC         train_pred = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{ver}/train_pred.csv')
# MAGIC         model_meta[ver] = {"feat_imp": feat_imp, "val_pred": val_pred, "train_pred": train_pred, "params": meta_param[ind]}
# MAGIC     else:
# MAGIC         #Devesh's models
# MAGIC         model_meta[ver] = {"feat_imp": feat_imp, "val_pred": "", "train_pred": "", "params": meta_param[ind]}
# MAGIC         

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Setup empty dataframes to track all the metrics of each model for reporting purposes.

# COMMAND ----------

train_perf = pd.DataFrame()
val_perf = pd.DataFrame()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Confusion Matrices
# MAGIC 
# MAGIC **Run script to build confusion matrix for each model variant, and log all metrics for both TRAIN + VALIDATION**
# MAGIC 
# MAGIC All the outputs are produced for reading and understanding. The strategy that our team took to deducing our final feature set is described in the **Feature Selection** section, as well as next steps in the **Summary**.
# MAGIC 
# MAGIC Note for confusion matrix the breakdown is the following
# MAGIC 
# MAGIC | TN   |   FN |
# MAGIC |-------|--------|
# MAGIC | FP    |    TP |

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC for ind, model in enumerate(model_meta):
# MAGIC     
# MAGIC     print(f"Model: {model}")
# MAGIC     print(f"num_tree: {model_meta[model]['params'][0]}")
# MAGIC     print(f"max_depth: {model_meta[model]['params'][1]}")    
# MAGIC     
# MAGIC     print()
# MAGIC     
# MAGIC     if model not in devesh_models:
# MAGIC         ############################################################################
# MAGIC         #Train    
# MAGIC         y_train_true = model_meta[model]["train_pred"]["label"]
# MAGIC         y_train_pred = model_meta[model]["train_pred"]["raw"]
# MAGIC 
# MAGIC         roc_auc_train = roc_auc_score(y_train_true, y_train_pred)    
# MAGIC         train_report = classification_report(y_train_true, y_train_pred, output_dict=True)
# MAGIC         print("Train Accuracy Score: ", accuracy_score(y_train_true, y_train_pred))
# MAGIC         print("Train F1 Score: ", f1_score(y_train_true, y_train_pred))
# MAGIC         print("Train ROC_AUC: ", roc_auc_train)    
# MAGIC         print(classification_report(y_train_true, y_train_pred))
# MAGIC 
# MAGIC         conf_mat_train = confusion_matrix(y_train_true, y_train_pred)    
# MAGIC         df_cm_train = pd.DataFrame(conf_mat_train, range(2), range(2))
# MAGIC         plt.figure(figsize=(10,7))
# MAGIC         sn.set(font_scale=1.4) # for label size
# MAGIC         sn.heatmap(df_cm_train, annot=True, annot_kws={"size": 14}) # font size
# MAGIC         plt.show()
# MAGIC 
# MAGIC         #Track
# MAGIC         train_row= pd.json_normalize(train_report, sep='_').to_dict(orient='records')[0]
# MAGIC         train_row["name"] = model
# MAGIC         train_row["numTree"] = model_meta[model]["params"][0]
# MAGIC         train_row["maxDepth"] = model_meta[model]["params"][1]
# MAGIC         train_row["tn"], train_row["fp"], train_row["fn"], train_row["tp"] = conf_mat_train.ravel()
# MAGIC         train_row["roc_auc"] = roc_auc_train
# MAGIC         train_perf = train_perf.append(train_row,True)
# MAGIC     
# MAGIC     
# MAGIC         ############################################################################
# MAGIC         #Validation
# MAGIC     
# MAGIC         y_val_true = model_meta[model]["val_pred"]["label"]
# MAGIC         y_val_pred = model_meta[model]["val_pred"]["raw"]
# MAGIC 
# MAGIC         val_report = classification_report(y_val_true, y_val_pred, output_dict=True)
# MAGIC         roc_auc_val = roc_auc_score(y_val_true, y_val_pred)
# MAGIC 
# MAGIC         print("Val Accuracy Score: ", accuracy_score(y_val_true, y_val_pred))
# MAGIC         print("Val F1 Score: ", f1_score(y_val_true, y_val_pred))
# MAGIC         print("Val ROC_AUC: ", roc_auc_val)
# MAGIC         print(classification_report(y_val_true, y_val_pred)) 
# MAGIC 
# MAGIC         conf_mat_val = confusion_matrix(y_val_true, y_val_pred)    
# MAGIC         df_cm_val = pd.DataFrame(conf_mat_val, range(2), range(2))
# MAGIC         plt.figure(figsize=(10,7))
# MAGIC         sn.set(font_scale=1.4) # for label size
# MAGIC         sn.heatmap(df_cm_val, annot=True, annot_kws={"size": 14}) # font size
# MAGIC         plt.show()
# MAGIC 
# MAGIC         #Track
# MAGIC         val_row = pd.json_normalize(val_report, sep='_').to_dict(orient='records')[0]
# MAGIC         val_row["name"] = model
# MAGIC         val_row["numTree"] = model_meta[model]["params"][0]
# MAGIC         val_row["maxDepth"] = model_meta[model]["params"][1]
# MAGIC         val_row["tn"], val_row["fp"], val_row["fn"], val_row["tp"] = conf_mat_val.ravel()
# MAGIC         val_row["roc_auc"] = roc_auc_val
# MAGIC         val_perf = val_perf.append(val_row,True)
# MAGIC     else:
# MAGIC         #Deveshs Metrics
# MAGIC         val_perf = val_perf.append(devesh_models[model],True)
# MAGIC         print(devesh_models[model])
# MAGIC 
# MAGIC     print()
# MAGIC     print('############################################################################')
# MAGIC     print()

# COMMAND ----------

# MAGIC %md
# MAGIC **Reorder the columns so that they are easy to understand**

# COMMAND ----------

order_cols = ['name', 'numTree','maxDepth', 'accuracy','roc_auc', 'weighted avg_f1-score', 'macro avg_f1-score', 
              'weighted avg_precision', 'macro avg_precision', 'weighted avg_recall', 'macro avg_recall',
              'weighted avg_support', 'macro avg_support', '0.0_f1-score', '1.0_f1-score', '0.0_precision', 
              '1.0_precision', '0.0_recall', '1.0_recall', '0.0_support', '1.0_support',
              'tn','fp','fn','tp']

train_perf = train_perf[order_cols]
val_perf = val_perf[order_cols]

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Metrics Report

# COMMAND ----------

train_perf

# COMMAND ----------

val_perf

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### False Positive Analysis:
# MAGIC 
# MAGIC As we look at our metrics, we seee that we have a consistent issue in predicting **FP**'s, we take a deeper dive into this in the following [notebook]
# MAGIC * Prediction Probabilities
# MAGIC * Flight/Weather Trends
# MAGIC 
# MAGIC [notebook]:https://deerlab.com/images/uploads/blog/98/omg.gif

# COMMAND ----------

# # #Store them for easy access later on
# train_perf.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/reports/train_perf.csv', index=False)
# val_perf.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/reports/val_perf.csv', index=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Feature Importance
# MAGIC 
# MAGIC Study the features ranked by importance for each Random Forest model run

# COMMAND ----------

# MAGIC %%time
# MAGIC for model in model_meta:
# MAGIC     print(f"Model: {model}")
# MAGIC     print(f"num_tree: {model_meta[model]['params'][0]}")
# MAGIC     print(f"max_depth: {model_meta[model]['params'][1]}")
# MAGIC     print(model_meta[model]['feat_imp'].head(20))
# MAGIC     print()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Feature Selection
# MAGIC 
# MAGIC Now that we have reports on various metrics for all the **Random Forest** models that we have run, it is time to really hone in on the features that we've given the model. Throughout the modelling phase we have experimented with hyper parameters as well as features based on our research and EDA. Looking at the feature importance reports we can quickly get a gauge on what features consistently make it to the top.
# MAGIC 
# MAGIC As we consider these top features we must be mindful of collinearity amongst these features; by avoiding collinearity we will ensure that the model is not giving more importance to any given facet of the data. We will make sure to reduce noise as well as make our model more parsimonious and explainable by cutting down on the feature set.

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Correlation Matrix
# MAGIC Build a correlation matrix on all our numerical features to get an understanding of collinearity. By studying the correlations side-by-side with the feature importance tables, we can justify which feature to select when it comes to collinear scenarios.

# COMMAND ----------

train_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/train/part-00*.parquet")
print("Train Data: ", train_data.count())

# COMMAND ----------

num_cols = ['DELAYS_SO_FAR','AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST','AVG_TMP_DEG_ORIGIN',
            'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_ORIGIN', 'AVG_CIG_HEIGHT_ORIGIN', 'AVG_CIG_HEIGHT_DEST',
            'AVG_VIS_DIS_ORIGIN', 'ORIGIN_FLIGHT_COUNT', 'AVG_SLP_ORIGIN', 'MIN_VIS_DIS_ORIGIN',
            'AVG_VIS_DIS_DEST','ORIGIN_PR','DEST_PR','AVG_DEW_DEG_DEST', 'MIN_CIG_HEIGHT_ORIGIN',
            'DEST_FLIGHT_COUNT', 'AVG_SLP_DEST','CRS_ELAPSED_TIME', 'CRS_ELAPSED_TIME_AVG_DIFF',
            'MINUTES_AFTER_MIDNIGHT_ORIGIN', 'MINUTES_AFTER_MIDNIGHT_DEST', 'NETWORK_CONGESTION']

train_trim = train_data.select(*num_cols).toPandas()
print("Train Shape ", train_trim.shape)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC The correlation matrix below points out some distinct cases of collinearity. For example the `ORIGIN_PR` (origin airport pagerank) and the `ORIGIN_FLIGHT_COUNT` a extremely high correlation. When we compare this to the feature importance tables overall, we can see that the `ORIGIN_PR` ranks higher in the Random Forest, therefore we can justify that we will drop the feature `ORIGIN_FLIGHT_COUNT`.

# COMMAND ----------

# DBTITLE 1,Correlation Matrix - Train Data
trainCorrMatrix = train_trim.corr()

# Generate a mask for the upper triangle
mask_train = np.triu(np.ones_like(trainCorrMatrix, dtype=bool))

f = plt.figure(figsize=(20, 20))
sn.heatmap(trainCorrMatrix, square=True, mask=mask_train, cmap="YlGnBu", linewidths=0.1, annot=True, annot_kws={"fontsize":10})  
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Just focus on the top ~15ish features
# MAGIC Because we want to reduce collinearity in our **top features**, we will consider the top 15 features based on `feature_imp` score that we have stored in our **models_meta** dictionary for each model variant.

# COMMAND ----------

feature_names = set()
for model in model_meta:
    feature_names.update(list(model_meta[model]['feat_imp'][0:15]["name"]))
print("NUmber of feature columns: ", len(feature_names))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC `32` represents the total number of features columns that reflects OHE columns, therefore we have to do some manual intervention to map those `32` to actual feature columns. Ultimately focussing on the numerical features we result in `19` that we can study below.

# COMMAND ----------

#Manually cut away
top_num_features = ['AVG_WND_SPEED_DEST', 'DEST_PR', 'AVG_VIS_DIS_ORIGIN', 'AVG_TMP_DEG_ORIGIN',
                    'AVG_TMP_DEG_DEST', 'NETWORK_CONGESTION', 'AVG_SLP_ORIGIN',
                    'ORIGIN_FLIGHT_COUNT', 'AVG_CIG_HEIGHT_ORIGIN', 'AVG_WND_SPEED_ORIGIN',
                    'MINUTES_AFTER_MIDNIGHT_ORIGIN', 'MINUTES_AFTER_MIDNIGHT_DEST', 'AVG_DEW_DEG_ORIGIN',
                    'MIN_VIS_DIS_ORIGIN', 'AVG_VIS_DIS_DEST', 'DELAYS_SO_FAR', 'ORIGIN_PR', 'AVG_CIG_HEIGHT_DEST', 'CRS_ELAPSED_TIME']

len(top_num_features)

# COMMAND ----------

# DBTITLE 1,Correlation Matrix - Top 19 Features
train_top = train_trim[top_num_features]
trainCorrMatrix = train_top.corr()

# Generate a mask for the upper triangle
mask_train = np.triu(np.ones_like(trainCorrMatrix, dtype=bool))

f = plt.figure(figsize=(15, 15))
sn.heatmap(trainCorrMatrix, square=True, mask=mask_train, cmap="YlGnBu", linewidths=0.1, annot=True, annot_kws={"fontsize":10})  
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Group by the features that show up most in the top 15 across our models
# MAGIC 
# MAGIC **Grain of salt** for the below results Not all features were used in all models therefore some features may automatically show up lower based off counts.

# COMMAND ----------

feat_imp_top_track = {}
for model in model_meta:
    feats = list(model_meta[model]['feat_imp'][0:15]["name"])
    for feat in feats:
        if feat in feat_imp_top_track:
            feat_imp_top_track[feat] += 1
        else:
            feat_imp_top_track[feat]= 1
od = collections.OrderedDict(sorted(feat_imp_top_track.items()))

# print(od)
top_feat_by_count = [('ARR_HOUR_BIN_catVec_1', 6),
             ('ARR_HOUR_BIN_catVec_2', 5),
             ('ARR_HOUR_BIN_catVec_3', 4),
             ('ARR_HOUR_BIN_catVec_4', 4),
             ('ARR_HOUR_catVec_8', 1),
             ('ARR_HOUR_catVec_9', 1),
             ('AVG_CIG_HEIGHT_DEST', 1),
             ('AVG_CIG_HEIGHT_ORIGIN', 4),
             ('AVG_DEW_DEG_ORIGIN', 4),
             ('AVG_SLP_ORIGIN', 1),
             ('AVG_TMP_DEG_DEST', 1),
             ('AVG_TMP_DEG_ORIGIN', 7),
             ('AVG_VIS_DIS_DEST', 1),
             ('AVG_VIS_DIS_ORIGIN', 7),
             ('AVG_WND_SPEED_DEST', 6),
             ('AVG_WND_SPEED_ORIGIN', 6),
             ('CRS_ELAPSED_TIME', 2),
             ('DELAYS_SO_FAR', 8),
             ('DEP_HOUR_BIN_catVec_1', 7),
             ('DEP_HOUR_BIN_catVec_2', 2),
             ('DEP_HOUR_BIN_catVec_3', 7),
             ('DEP_HOUR_BIN_catVec_4', 2),
             ('DEP_HOUR_catVec_6', 2),
             ('DEP_HOUR_catVec_7', 1),
             ('DEST_PR', 2),
             ('MINUTES_AFTER_MIDNIGHT_DEST', 3),
             ('MINUTES_AFTER_MIDNIGHT_ORIGIN', 3),
             ('MIN_VIS_DIS_ORIGIN', 2),
             ('NETWORK_CONGESTION', 6),
             ('OP_CARRIER_catVec_WN', 4),
             ('ORIGIN_FLIGHT_COUNT', 4),
             ('ORIGIN_PR', 6)]

top_feat_by_count = sorted(top_feat_by_count, key= lambda x: -x[1])


# COMMAND ----------

top_feat_by_count

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Summary
# MAGIC 
# MAGIC Looking at the `train_perf` some trends in modelling become very clear. As we increase the hyper parameter `numTrees` we see an improvement in our model, there is a steady increase that is also a reflection of `maxDepth`. We have to be mindful of the business problem we are trying to solve. Our assumption is that incorrectly predicting a delay when in fact a flight is on time should be penalized; i.e. predicting a false positive. We would like to ride on the conservative side, because this way in the worst case a traveller may be disgruntled due to a delay, instead of extremeley upset because they missed their flight due to our prediction.
# MAGIC 
# MAGIC Therefore the metrics that we are looking to optimize on are **1.0_precision** (delay class), **accuracy**, and **weighted avg_precision**(accounts for class imbalance). Therefore from our models we see models **#4**, **#5**, and **#9** as our top performers. After identifying these, we focus on what features make it into the respective `top_15` for each model. We cross validate these features with the `top_feat_by_count` as sanity check that a feature makes it into the top 15 across multiple models.
# MAGIC 
# MAGIC Finally from this subset we will end up having both categorical and numerical features. From the numerical features, we can then study the correlation matrix, to choose features that are not collinear with each other, ultimately giving us a chance to capture the variance of the problem space. By picking features that don't overlap with one another we can conceptually represent many things, such as:
# MAGIC * Weather
# MAGIC * Time of Day
# MAGIC * Propagation Delay
# MAGIC * Airport Popularity
# MAGIC * Network Congestion
# MAGIC * Estimated Trip Durations.
# MAGIC 
# MAGIC This gives our model a well rounded, parsimonious feature set that we hope to see improve our key performance metrics.

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Final Features
# MAGIC 
# MAGIC The **numerical features** listed below are all described above, and can be found in the correlation matrix below.
# MAGIC 
# MAGIC The **categorical features** all stem from behavior we have seen in the departure hour during the day, and the flight behavior we see across quarterly segments during the year. We noticed that specifc hour ranges during the day are associated to unique behavior in delay uptic, and delay plateau'ing, therefore we will be creating two new boolean features on the fly for our final model.
# MAGIC 
# MAGIC If a flight is leaving between 6 AM - 9 AM, `IS_MORNING_FLIGHT` will be **TRUE**l if a flight is leaving between 3 PM - 8 PM, `IS_EVENING_FLIGHT` will be **TRUE**. Otherwise respectively the values will be **FALSE**.

# COMMAND ----------

final_num = ['DELAYS_SO_FAR', 'MINUTES_AFTER_MIDNIGHT_ORIGIN','MINUTES_AFTER_MIDNIGHT_DEST',
                 'NETWORK_CONGESTION','AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR', 'AVG_DEW_DEG_ORIGIN',
                 'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST',            
            ]

final_cat = ['QUARTER', 'IS_MORNING_FLIGHT', 'IS_EVENING_FLIGHT']

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Correlation Matrix (pt.2)
# MAGIC As you can see here, with the final numerical features we have selected we have very much improved upon the correlation between features, thus avoiding collinearity. As per the categorical features, we have limited 

# COMMAND ----------

# DBTITLE 1,Correlation Matrix - Final Features
train_top_fin = train_trim[final_num]
val_top_fin = val_trim[final_num]
trainCorrMatrix = train_top_fin.corr()

# Generate a mask for the upper triangle
mask_train = np.triu(np.ones_like(trainCorrMatrix, dtype=bool))

f = plt.figure(figsize=(15, 15))
sn.heatmap(trainCorrMatrix, square=True, mask=mask_train, cmap="YlGnBu", linewidths=0.1, annot=True, annot_kws={"fontsize":10})  
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Next Steps
# MAGIC 
# MAGIC Now that we have all our features finalized we will take this onto our final round of modelling with **Random Forests** and **Gradient Boosted Trees**. After trying a few different 

# COMMAND ----------

model_meta['rd_model_2']['feat_imp'].head(20)

# COMMAND ----------


