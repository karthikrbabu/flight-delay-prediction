# Databricks notebook source
import numpy as np
import pandas as pd
import plotly as px
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from datetime import datetime
import time

import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.ml.feature import StringIndexer, VectorIndexer, VectorAssembler, StandardScaler, OneHotEncoder, SQLTransformer
from pyspark.ml.classification import LogisticRegression 
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml import Pipeline
from pyspark.sql import Window

from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

import mlflow
import mlflow.spark

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Final Model Variants
# MAGIC After various iterations of model tuning, feature engineering/selection, and performance analysis, we have settled on the final set of features we'd like to use for our **Random Forest** model. In this notebook we explore a few different subsets of those features, as well as try some high level hyperparameter tuning.
# MAGIC 
# MAGIC ### Goal 
# MAGIC Build a final model pipeline and evaluate on train and validation for final hyper parameter tuning.

# COMMAND ----------

train_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/train/part-00*.parquet")
val_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/validation/part-00*.parquet")

print("Train Data: ", train_data.count())
print("Validation Data: ", val_data.count())

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC **Note: `MINUTES_AFTER_MIDNIGHT_ORIGIN` and `MINUTES_AFTER_MIDNIGHT_DEST` are calculated in UTC time.**

# COMMAND ----------

final_features =  ['DELAYS_SO_FAR','MINUTES_AFTER_MIDNIGHT_ORIGIN','MINUTES_AFTER_MIDNIGHT_DEST', 
                   'NETWORK_CONGESTION','AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR', 'AVG_DEW_DEG_ORIGIN',
                   'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST', 'QUARTER', 'DEP_HOUR_BIN',
                   'ARR_HOUR_BIN', 'IS_MORNING_FLIGHT','IS_EVENING_FLIGHT']

label_col = ['DEP_DEL15']
final_cols = list(set(final_features + label_col))

print("Number of features: ", len(final_features))
print(final_cols)

# COMMAND ----------

#Keep on Train
train_final = train_data.select(*final_cols)

#Keep on Val
val_final = val_data.select(*final_cols)

print("Remaining Col Count: ", len(train_final.columns))
train_final.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Model Variant #1

# COMMAND ----------

cat_cols = ['QUARTER','IS_MORNING_FLIGHT','IS_EVENING_FLIGHT']

num_cols = ['DELAYS_SO_FAR','MINUTES_AFTER_MIDNIGHT_ORIGIN','MINUTES_AFTER_MIDNIGHT_DEST', 
            'NETWORK_CONGESTION','AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR', 'AVG_DEW_DEG_ORIGIN',
            'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST']

# COMMAND ----------

#Check groupings for cat cols
cols_by_cat = 0
for col in cat_cols:
    col_count = train_final.select(col).distinct().count()
    cols_by_cat += col_count
    print(col, ": ", col_count)

print()
tot_col_count = len(num_cols)+cols_by_cat
print("Number of columns after OHE: ", tot_col_count)

# COMMAND ----------

#Apply Balance Ratio, build this only from Train
balancing_ratio = train_final.filter("DEP_DEL15 == 0").count() / train_final.count()
print("Balancing Ratio =", balancing_ratio)

# COMMAND ----------

train_final = train_final.withColumn("CLASS_WEIGHTS", when(train_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

val_final = val_final.withColumn("CLASS_WEIGHTS", when(val_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

# COMMAND ----------

#Returns a Pandas DF with top features and scores
def ExtractFeatureImp(featureImp, dataset, featuresCol):
    list_extract = []
    for i in dataset.schema[featuresCol].metadata["ml_attr"]["attrs"]:
        list_extract = list_extract + dataset.schema[featuresCol].metadata["ml_attr"]["attrs"][i]
    varlist = pd.DataFrame(list_extract)
    varlist['score'] = varlist['idx'].apply(lambda x: featureImp[x])
    return(varlist.sort_values('score', ascending = False))

# COMMAND ----------

cols = list(set(cat_cols + num_cols + label_col)) + ["CLASS_WEIGHTS"]
train = train_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')
val = val_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')

print((train.count(), len(train.columns)))
print((val.count(), len(val.columns)))
display(train)

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in cat_cols]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in cat_cols]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(cat_cols, col_vec_out)]

#Create pair of zips
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

#Assemble all the features together into one feature vector
res_cols = num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=res_cols, outputCol="features", handleInvalid='skip')
stages += [vector_assembler]

# COMMAND ----------

#Helper function to check and create a path if it doesn't exist already
def path_exists(path):
    print("Path: ", path)
    try:
        dbutils.fs.ls(path)
        return True
    except Exception as e:
        dbutils.fs.mkdirs(path)        
        return False

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_21"
# MAGIC nTree = 40
# MAGIC mDep = 15
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(train).transform(train)
# MAGIC     val_pip = pipeline.fit(val).transform(val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_22"
# MAGIC nTree = 40
# MAGIC mDep = 15
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(train).transform(train)
# MAGIC     val_pip = pipeline.fit(val).transform(val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model Variant #2

# COMMAND ----------

cat_cols = ['QUARTER', 'DEP_HOUR_BIN', 'ARR_HOUR_BIN']

num_cols = ['DELAYS_SO_FAR','MINUTES_AFTER_MIDNIGHT_ORIGIN','MINUTES_AFTER_MIDNIGHT_DEST', 
            'NETWORK_CONGESTION','AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR', 'AVG_DEW_DEG_ORIGIN',
            'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST']

# COMMAND ----------

cols = list(set(cat_cols + num_cols + label_col)) + ["CLASS_WEIGHTS"]
train = train_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')
val = val_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')

print((train.count(), len(train.columns)))
print((val.count(), len(val.columns)))
display(train)

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in cat_cols]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in cat_cols]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(cat_cols, col_vec_out)]

#Create pair of zips
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

#Assemble all the features together into one feature vector
res_cols = num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=res_cols, outputCol="features", handleInvalid='skip')
stages += [vector_assembler]

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_25"
# MAGIC nTree = 50
# MAGIC mDep = 18
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(train).transform(train)
# MAGIC     val_pip = pipeline.fit(val).transform(val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Model Variant #3
# MAGIC 
# MAGIC ##### New Feature - IS_EARLY_MORN_FLIGHT
# MAGIC 
# MAGIC For our business case, we would like to be more conservative in terms of predicting delay. i.e. In all cases we would prefer telling a customer that there is no delay, evven if there ends up being one. Therefore we want to minimize **False Positives (FP)**. When performing this analysis on our latest models the following [notebook] we found that there is a spike in **FP**'s for early morning flights, i.e. when `MINUTES_AFTER_MIDNIGHT_ORIGIN` is less than **180**. Therefore we wanted to address this pitfall of our model, by adding a special boolean term, that indicates whether or not it is an early morning flight.
# MAGIC 
# MAGIC [notebook]: https://dbc-c4580dc0-018b.cloud.databricks.com/?o=8229810859276230#notebook/2834511320022313/command/2834511320025772

# COMMAND ----------

train_final = train_final.withColumn("IS_EARLY_MORNING_FLIGHT", when(f.col("MINUTES_AFTER_MIDNIGHT_ORIGIN") <= 180,1).otherwise(0))
val_final = val_final.withColumn("IS_EARLY_MORNING_FLIGHT", when(f.col("MINUTES_AFTER_MIDNIGHT_ORIGIN") <= 180,1).otherwise(0))

# COMMAND ----------

cat_cols = ['QUARTER', 'IS_EARLY_MORNING_FLIGHT']

num_cols = ['DELAYS_SO_FAR','MINUTES_AFTER_MIDNIGHT_ORIGIN','MINUTES_AFTER_MIDNIGHT_DEST', 
            'NETWORK_CONGESTION','AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR', 'AVG_DEW_DEG_ORIGIN',
            'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST']

# COMMAND ----------

train_final = train_final.withColumn("CLASS_WEIGHTS", when(train_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

val_final = val_final.withColumn("CLASS_WEIGHTS", when(val_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

# COMMAND ----------

cols = list(set(cat_cols + num_cols + label_col)) + ["CLASS_WEIGHTS"]
train = train_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')
val = val_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')

print((train.count(), len(train.columns)))
print((val.count(), len(val.columns)))
display(train)

# COMMAND ----------

#Check groupings for cat cols
cols_by_cat = 0
for col in cat_cols:
    col_count = train_final.select(col).distinct().count()
    cols_by_cat += col_count
    print(col, ": ", col_count)

print()
tot_col_count = len(num_cols)+cols_by_cat
print("Number of columns after OHE: ", tot_col_count)

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in cat_cols]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in cat_cols]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(cat_cols, col_vec_out)]

#Create pair of zips
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

#Assemble all the features together into one feature vector
res_cols = num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=res_cols, outputCol="features", handleInvalid='skip')
stages += [vector_assembler]

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_26"
# MAGIC nTree = 40
# MAGIC mDep = 15
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(train).transform(train)
# MAGIC     val_pip = pipeline.fit(val).transform(val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Model Variant #4

# COMMAND ----------

cat_cols = ['QUARTER', 'IS_EARLY_MORNING_FLIGHT','DEP_HOUR_BIN','ARR_HOUR_BIN']

num_cols = ['DELAYS_SO_FAR','MINUTES_AFTER_MIDNIGHT_ORIGIN','MINUTES_AFTER_MIDNIGHT_DEST', 
            'NETWORK_CONGESTION','AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR', 'AVG_DEW_DEG_ORIGIN',
            'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST']

# COMMAND ----------

cols = list(set(cat_cols + num_cols + label_col)) + ["CLASS_WEIGHTS"]
train = train_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')
val = val_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')

print((train.count(), len(train.columns)))
print((val.count(), len(val.columns)))
display(train)

# COMMAND ----------

#Check groupings for cat cols
cols_by_cat = 0
for col in cat_cols:
    col_count = train_final.select(col).distinct().count()
    cols_by_cat += col_count
    print(col, ": ", col_count)

print()
tot_col_count = len(num_cols)+cols_by_cat
print("Number of columns after OHE: ", tot_col_count)

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in cat_cols]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in cat_cols]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(cat_cols, col_vec_out)]

#Create pair of zips
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

#Assemble all the features together into one feature vector
res_cols = num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=res_cols, outputCol="features", handleInvalid='skip')
stages += [vector_assembler]

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_27"
# MAGIC nTree = 40
# MAGIC mDep = 15
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(train).transform(train)
# MAGIC     val_pip = pipeline.fit(val).transform(val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------


