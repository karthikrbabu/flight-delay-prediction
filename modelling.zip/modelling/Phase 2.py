# Databricks notebook source
import numpy as np
import pandas as pd
import plotly as px
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from datetime import datetime
import time

import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.ml.feature import StringIndexer, VectorIndexer, VectorAssembler, StandardScaler, OneHotEncoder, SQLTransformer
from pyspark.ml.classification import LogisticRegression 
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml import Pipeline
from pyspark.sql import Window

from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

import mlflow
import mlflow.spark

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Goal 
# MAGIC Try out the **RandomForest** algorithm that we built earlier, on our latest data with the most relevant features + new features

# COMMAND ----------

train_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/train/part-00*.parquet")
val_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/validation/part-00*.parquet")

print(train_data.count())
display(train_data)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Lets look at the top features ranked by feature importance of our latest Random Forest Model

# COMMAND ----------

varlist = pd.read_csv('/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/rd_model_2/feat_imp.csv')
print(varlist.shape)
varlist.head(30)

# COMMAND ----------

varlist["score"].describe()

# COMMAND ----------

plt.hist(varlist["score"], 30, range=[0.0, 0.3], facecolor='gray', align='mid')


# COMMAND ----------

top_20 = varlist[0:20]["name"]
list(top_20)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Look at the new features from train data

# COMMAND ----------

print("Number of columns: ", len(train_data.columns))
np.array(train_data.columns)

# COMMAND ----------

#Manually override naming
top_20 = ['DELAYS_SO_FAR',
         'AVG_WND_SPEED_ORIGIN',
         'AVG_WND_SPEED_DEST',
         'AVG_TMP_DEG_ORIGIN',
         'AVG_TMP_DEG_DEST',
         'AVG_DEW_DEG_ORIGIN',
         'AVG_CIG_HEIGHT_ORIGIN',
         'AVG_CIG_HEIGHT_DEST',
         'AVG_VIS_DIS_ORIGIN',
         'ORIGIN_FLIGHT_COUNT',
         'AVG_SLP_ORIGIN',
         'MIN_VIS_DIS_ORIGIN',
         'AVG_VIS_DIS_DEST',
         'ORIGIN_PR',
         'DEST_PR',
         'AVG_DEW_DEG_DEST',
         'MIN_CIG_HEIGHT_ORIGIN',
         'DEST_FLIGHT_COUNT',
         'AVG_SLP_DEST',
         'CRS_ELAPSED_TIME']


new_features = ['CRS_ELAPSED_TIME_AVG_DIFF', 'WEST_TO_EAST', 'MINUTES_AFTER_MIDNIGHT_ORIGIN', 'MINUTES_AFTER_MIDNIGHT_DEST', 'HOLIDAY_WEEK', 'DEP_HOUR_BIN','ARR_HOUR_BIN','NETWORK_CONGESTION']

label_col = ['DEP_DEL15']

print(len(top_20))
print(len(new_features))
print(len(label_col))

keep_cols = set(top_20 + new_features + label_col)

print(len(keep_cols))

# COMMAND ----------

len(top_20 + new_features + label_col)

# COMMAND ----------

#Keep on Train
train_final = train_data.select(*keep_cols)

#Keep on Val
val_final = val_data.select(*keep_cols)

print("Remaining Col Count: ", len(train_final.columns))
train_final.printSchema()
display(train_final)


# COMMAND ----------

cat_cols = ['DEP_HOUR_BIN', 'ARR_HOUR_BIN', 'WEST_TO_EAST', 'HOLIDAY_WEEK']

num_cols = ['DELAYS_SO_FAR','AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST','AVG_TMP_DEG_ORIGIN',
            'AVG_TMP_DEG_DEST', 'AVG_DEW_DEG_ORIGIN', 'AVG_CIG_HEIGHT_ORIGIN', 'AVG_CIG_HEIGHT_DEST',
            'AVG_VIS_DIS_ORIGIN', 'ORIGIN_FLIGHT_COUNT', 'AVG_SLP_ORIGIN', 'MIN_VIS_DIS_ORIGIN',
            'AVG_VIS_DIS_DEST','ORIGIN_PR','DEST_PR','AVG_DEW_DEG_DEST', 'MIN_CIG_HEIGHT_ORIGIN',
            'DEST_FLIGHT_COUNT', 'AVG_SLP_DEST','CRS_ELAPSED_TIME', 'CRS_ELAPSED_TIME_AVG_DIFF',
            'MINUTES_AFTER_MIDNIGHT_ORIGIN', 'MINUTES_AFTER_MIDNIGHT_DEST', 'NETWORK_CONGESTION']

len(set(cat_cols + num_cols))

# COMMAND ----------

cols_by_cat = 0
for col in cat_cols:
    col_count = train_final.select(col).distinct().count()
    cols_by_cat += col_count
    print(col, ": ", col_count)

print()
tot_col_count = len(num_cols)+cols_by_cat
print("Number of columns after OHE: ", tot_col_count)

# COMMAND ----------

# MAGIC %md
# MAGIC This means we are reducing model parsimony from **918** to **43** columns

# COMMAND ----------

#Apply Balance Ratio, build this only from Train
balancing_ratio = train_final.filter("DEP_DEL15 == 0").count() / train_final.count()

print("Balancing Ratio =", balancing_ratio)

train_final = train_final.withColumn("CLASS_WEIGHTS", when(train_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))


val_final = val_final.withColumn("CLASS_WEIGHTS", when(val_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### To Extract Feature Importance

# COMMAND ----------

#Returns a Pandas DF with top features and scores
def ExtractFeatureImp(featureImp, dataset, featuresCol):
    list_extract = []
    for i in dataset.schema[featuresCol].metadata["ml_attr"]["attrs"]:
        list_extract = list_extract + dataset.schema[featuresCol].metadata["ml_attr"]["attrs"][i]
    varlist = pd.DataFrame(list_extract)
    varlist['score'] = varlist['idx'].apply(lambda x: featureImp[x])
    return(varlist.sort_values('score', ascending = False))

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### M4 - Random Forest
# MAGIC 
# MAGIC Trimmed down to take the top 21 features from feature importance, also including latest added feature engineered features

# COMMAND ----------

m3_cat = cat_cols
m3_cols = list(set(m3_cat + num_cols + label_col)) + ["CLASS_WEIGHTS"]
m3_train = train_final.select(*m3_cols).withColumnRenamed('DEP_DEL15', 'label')
m3_val = val_final.select(*m3_cols).withColumnRenamed('DEP_DEL15', 'label')

print((m3_train.count(), len(m3_train.columns)))
print((m3_val.count(), len(m3_val.columns)))
display(m3_train)

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in m3_cat]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in m3_cat]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(m3_cat, col_vec_out)]

#Create pair of zips
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

# COMMAND ----------

m3_cols = num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=m3_cols, outputCol="features", handleInvalid='skip')
stages += [vector_assembler]

# COMMAND ----------

#Helper function to check and create a path if it doesn't exist already
def path_exists(path):
    print("Path: ", path)
    try:
        dbutils.fs.ls(path)
        return True
    except Exception as e:
        dbutils.fs.mkdirs(path)        
        return False

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_4"
# MAGIC nTree = 30
# MAGIC mDep = 15
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(m3_train).transform(m3_train)
# MAGIC     val_pip = pipeline.fit(m3_val).transform(m3_val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = m3_train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = m3_val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, m3_val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### M5 - Random Forest

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_5"
# MAGIC nTree = 40
# MAGIC mDep = 15
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(m3_train).transform(m3_train)
# MAGIC     val_pip = pipeline.fit(m3_val).transform(m3_val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = m3_train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = m3_val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, m3_val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### M6 - Random Forest

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_6"
# MAGIC nTree = 40
# MAGIC mDep = 20
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(m3_train).transform(m3_train)
# MAGIC     val_pip = pipeline.fit(m3_val).transform(m3_val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = m3_train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = m3_val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, m3_val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### M7 - Random Forest

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_7"
# MAGIC nTree = 50
# MAGIC mDep = 20
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(m3_train).transform(m3_train)
# MAGIC     val_pip = pipeline.fit(m3_val).transform(m3_val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = m3_train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = m3_val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, m3_val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### M8 - Random Forest

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_8"
# MAGIC nTree = 50
# MAGIC mDep = 25
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(m3_train).transform(m3_train)
# MAGIC     val_pip = pipeline.fit(m3_val).transform(m3_val)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     m3_val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = m3_train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = m3_val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)  
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, m3_val_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')    
# MAGIC   

# COMMAND ----------

# varidx = [x for x in varlist['idx'][0:10]]

# COMMAND ----------

# slicer = VectorSlicer(inputCol="features", outputCol="features2", indices=varidx)
# m1_trim = slicer.transform(m1_train_results)

# COMMAND ----------

# m1_trim = m1_trim.drop('rawPrediction', 'probability', 'prediction')
# rf2 = RandomForestClassifier(labelCol="label", featuresCol="features2", seed = 8464,
#                             numTrees=10, cacheNodeIds = True, subsamplingRate = 0.7)
# mod2 = rf2.fit(m1_trim)
# m1_trim_results = mod2.transform(m1_trim)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Output Analysis

# COMMAND ----------

#Extract it all to evaluate later on.
model_version = ''
varlist = pd.read_csv('/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
valScoreAndLabels_pd = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
trainScoreAndLabels_pd = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')

# COMMAND ----------

import seaborn as sn
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

# COMMAND ----------

varlist.head(50)

# COMMAND ----------

trainScoreAndLabels_pd.head()

# COMMAND ----------

valScoreAndLabels_pd.head()

# COMMAND ----------

trainScoreAndLabels_pd["label"][0:10]

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Training Analysis

# COMMAND ----------

y_train_true = trainScoreAndLabels_pd["label"]
y_train_pred = trainScoreAndLabels_pd["raw"]
conf_mat_train = confusion_matrix(y_train_true, y_train_pred)

# COMMAND ----------

print("Accuracy Score: ", accuracy_score(y_train_true, y_train_pred))
print("F1 Score: ", f1_score(y_train_true, y_train_pred))
print(classification_report(y_train_true, y_train_pred))

# COMMAND ----------

df_cm_train = pd.DataFrame(conf_mat_train, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm_train, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Validation Analysis

# COMMAND ----------

y_val_true = valScoreAndLabels_pd["label"]
y_val_pred = valScoreAndLabels_pd["raw"]
conf_mat_val = confusion_matrix(y_val_true, y_val_pred)

# COMMAND ----------

print("Accuracy Score: ", accuracy_score(y_val_true, y_val_pred))
print("F1 Score: ", f1_score(y_val_true, y_val_pred))
print(classification_report(y_val_true, y_val_pred))

# COMMAND ----------

df_cm_val = pd.DataFrame(conf_mat_val, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm_val, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------


