# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Final Model Pipeline
# MAGIC After various iterations of model tuning, feature engineering/selection, and performance analysis, we have settled on the final set of features and parameters we'd like to use for our **Random Forest** model.
# MAGIC 
# MAGIC One thing we wish we could have done more is an exhaustive hyper parameter tuning, but for now we role with the best that we've seen through our research/ journey.
# MAGIC 
# MAGIC ### Goal 
# MAGIC Build a final model pipeline and evaluate our final model on train, validation, and test.

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Package Imports

# COMMAND ----------

import numpy as np
import pandas as pd
import plotly as px
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from datetime import datetime
import time

import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.sql.functions import isnan, when, count, col

from pyspark.ml.feature import StringIndexer, VectorIndexer, VectorAssembler, StandardScaler, OneHotEncoder, SQLTransformer
from pyspark.ml.classification import LogisticRegression 
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml import Pipeline
from pyspark.sql import Window

from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

import mlflow
import mlflow.spark

import seaborn as sn
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Load in Data
# MAGIC Already split into train, validation, and test

# COMMAND ----------

train_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/train/part-00*.parquet")
val_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/validation/part-00*.parquet")
test_data = spark.read.option("header", "true").parquet(f"dbfs:/mnt/mids-w261/team20SSDK/project_data/test/part-00*.parquet")

print("Train Data: ", train_data.count())
print("Validation Data: ", val_data.count())
print("Test Data: ", test_data.count())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Helper Functions
# MAGIC Auxillary functions for use in the pipeline

# COMMAND ----------

#Returns a Pandas DF with top features and scores based on the input RF model
def ExtractFeatureImp(featureImp, dataset, featuresCol):
    list_extract = []
    for i in dataset.schema[featuresCol].metadata["ml_attr"]["attrs"]:
        list_extract = list_extract + dataset.schema[featuresCol].metadata["ml_attr"]["attrs"][i]
    varlist = pd.DataFrame(list_extract)
    varlist['score'] = varlist['idx'].apply(lambda x: featureImp[x])
    return(varlist.sort_values('score', ascending = False))

# COMMAND ----------

#Helper function to check and create a path if it doesn't exist already
def path_exists(path):
    print("Path: ", path)
    try:
        dbutils.fs.ls(path)
        return True
    except Exception as e:
        dbutils.fs.mkdirs(path)        
        return False

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### NEW FEATURE
# MAGIC 
# MAGIC ##### IS_EARLY_MORN_FLIGHT
# MAGIC 
# MAGIC For our business case, we would like to be more conservative in terms of predicting delay. i.e. In all cases we would prefer telling a customer that there is no delay, evven if there ends up being one.
# MAGIC 
# MAGIC Therefore we want to minimize **False Positives (FP)**. When performing this analysis on our latest models the following [notebook] we found that there is a spike in **FP**'s for early morning flights, i.e. when `MINUTES_AFTER_MIDNIGHT_ORIGIN` is less than **180**. To address this pitfall, we are adding a special boolean term, that indicates whether or not the flight is an early morning flight.
# MAGIC 
# MAGIC By including this feature, we hope to give the Random Forest another viable split point to distinguish these scenarios
# MAGIC 
# MAGIC 
# MAGIC **Note: `MINUTES_AFTER_MIDNIGHT_ORIGIN` and `MINUTES_AFTER_MIDNIGHT_DEST` are calculated in UTC time.**
# MAGIC 
# MAGIC [notebook]: https://dbc-c4580dc0-018b.cloud.databricks.com/?o=8229810859276230#notebook/2834511320022313/command/2834511320025772

# COMMAND ----------

train_data = train_data.withColumn("IS_EARLY_MORNING_FLIGHT", when(f.col("MINUTES_AFTER_MIDNIGHT_ORIGIN") <= 180,1).otherwise(0))
val_data = val_data.withColumn("IS_EARLY_MORNING_FLIGHT", when(f.col("MINUTES_AFTER_MIDNIGHT_ORIGIN") <= 180,1).otherwise(0))
test_data = test_data.withColumn("IS_EARLY_MORNING_FLIGHT", when(f.col("MINUTES_AFTER_MIDNIGHT_ORIGIN") <= 180,1).otherwise(0))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Final Features

# COMMAND ----------

final_features = ['DELAYS_SO_FAR','MINUTES_AFTER_MIDNIGHT_ORIGIN','MINUTES_AFTER_MIDNIGHT_DEST', 
            'NETWORK_CONGESTION','AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR', 'AVG_DEW_DEG_ORIGIN',
            'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN','AVG_WND_SPEED_DEST','QUARTER',
            'IS_EARLY_MORNING_FLIGHT','DEP_HOUR_BIN','ARR_HOUR_BIN']

label_col = ['DEP_DEL15']
final_cols = list(set(final_features + label_col))

print("Number of features: ", len(final_features))
print(final_cols)

# COMMAND ----------

#Keep on Train
train_final = train_data.select(*final_cols)

#Keep on Val
val_final = val_data.select(*final_cols)

#Keep on Val
test_final = test_data.select(*final_cols)

print("Remaining Col Count: ", len(train_final.columns))
test_final.printSchema()

# COMMAND ----------

cat_cols = ['QUARTER', 'IS_EARLY_MORNING_FLIGHT',
            'DEP_HOUR_BIN','ARR_HOUR_BIN']

num_cols = ['DELAYS_SO_FAR','MINUTES_AFTER_MIDNIGHT_ORIGIN',
            'MINUTES_AFTER_MIDNIGHT_DEST', 'NETWORK_CONGESTION',
            'AVG_VIS_DIS_ORIGIN','DEST_PR','ORIGIN_PR','AVG_DEW_DEG_ORIGIN',
            'CRS_ELAPSED_TIME', 'AVG_WND_SPEED_ORIGIN',
            'AVG_WND_SPEED_DEST']

# COMMAND ----------

# MAGIC %md
# MAGIC ### Apply Balance Ratio
# MAGIC Compute the balance ratio only from training data

# COMMAND ----------

balancing_ratio = train_final.filter("DEP_DEL15 == 0").count() / train_final.count()
print("Balancing Ratio =", balancing_ratio)

# COMMAND ----------

train_final = train_final.withColumn("CLASS_WEIGHTS", when(train_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

val_final = val_final.withColumn("CLASS_WEIGHTS", when(val_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

test_final = test_final.withColumn("CLASS_WEIGHTS", when(test_final.DEP_DEL15 == 1, balancing_ratio) \
                               .otherwise(1 - balancing_ratio))

# COMMAND ----------

cols = list(set(cat_cols + num_cols + label_col)) + ["CLASS_WEIGHTS"]
train = train_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')
val = val_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')
test = test_final.select(*cols).withColumnRenamed('DEP_DEL15', 'label')

print((train.count(), len(train.columns)))
print((val.count(), len(val.columns)))
print((test.count(), len(test.columns)))
display(test)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model Pipeline
# MAGIC 
# MAGIC The following pipeline provides the necessary steps to 
# MAGIC * Pre Proces Data 
# MAGIC   * one hot encoding for categorical variable, 
# MAGIC   * assemble feature vectors
# MAGIC * Load/Train a Random Forest model
# MAGIC * Evaluate the Model
# MAGIC * Store the Model

# COMMAND ----------

col_vec_out = [x+'_catVec' for x in cat_cols]

#StringIndex into labelled indices
indexers = [StringIndexer(inputCol=x, outputCol= x+'_tmp') for x in cat_cols]

#OneHotEncoder, indices into sparse one hot encoded columns
encoders = [OneHotEncoder(dropLast=False, inputCol=x+'_tmp', outputCol=y) for x,y in zip(cat_cols, col_vec_out)]

#Create pair of zips
stages = [[i,j] for i,j in zip(indexers, encoders)]

#Flatten into stages
stages = [stage for sublist in stages for stage in sublist]

#Assemble all the features together into one feature vector
res_cols = num_cols + col_vec_out
vector_assembler = VectorAssembler(inputCols=res_cols, outputCol="features", handleInvalid='skip')
stages += [vector_assembler]

# COMMAND ----------

# MAGIC %%time
# MAGIC 
# MAGIC model_version = "rf_model_final"
# MAGIC nTree = 50
# MAGIC mDep = 18
# MAGIC subSamp = 1.0
# MAGIC 
# MAGIC # Explicitly create a new run.
# MAGIC # This allows this cell to be run multiple times.
# MAGIC # If you omit mlflow.start_run(), then this cell could run once, but a second run would hit conflicts when attempting to overwrite the first run.
# MAGIC with mlflow.start_run():
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     pipeline = Pipeline().setStages(stages)
# MAGIC   
# MAGIC     #MISLEADING - No model fitting is happening here. Just creating the 1 hot encoded columns
# MAGIC     train_pip = pipeline.fit(train).transform(train)
# MAGIC     val_pip = pipeline.fit(val).transform(val)
# MAGIC     test_pip = pipeline.fit(test).transform(test)    
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('pip_fit_time' ,done - start)
# MAGIC 
# MAGIC     rf = RandomForestClassifier(labelCol="label", featuresCol="features", weightCol="CLASS_WEIGHTS",
# MAGIC                             numTrees=nTree, maxDepth=mDep, cacheNodeIds = True, subsamplingRate = subSamp)  
# MAGIC     mlflow.log_param('numTrees', nTree)
# MAGIC     mlflow.log_param('maxDepth', mDep)
# MAGIC     mlflow.log_param('cacheNodeIds', True)
# MAGIC     mlflow.log_param('subsamplingRate', subSamp)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     rf_model = rf.fit(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_fit_time' ,done - start)
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     train_results = rf_model.transform(train_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_pred_time' ,done - start)  
# MAGIC 
# MAGIC     start = time.time()
# MAGIC     val_results = rf_model.transform(val_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_pred_time' ,done - start)
# MAGIC     
# MAGIC     start = time.time()
# MAGIC     test_results = rf_model.transform(test_pip)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('test_pred_time' ,done - start)    
# MAGIC 
# MAGIC     #Set up BinClassEval
# MAGIC     evaluator = BinaryClassificationEvaluator()
# MAGIC     evaluator.setRawPredictionCol("raw")
# MAGIC 
# MAGIC     trainScoreAndLabels = train_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     valScoreAndLabels = val_results.select(['probability','label', f.col("prediction").alias("raw")])
# MAGIC     testScoreAndLabels = test_results.select(['probability','label', f.col("prediction").alias("raw")])    
# MAGIC 
# MAGIC     print("Train Set")
# MAGIC     start=time.time()
# MAGIC     train_pr = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     train_roc = evaluator.evaluate(trainScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('train_metric_time' ,done - start)  
# MAGIC 
# MAGIC     print("train areaUnderPR: ", train_pr)
# MAGIC     print("train areaUnderROC: ", train_roc)
# MAGIC     mlflow.log_metric('train_pr' ,train_pr)
# MAGIC     mlflow.log_metric('train_roc' ,train_roc)
# MAGIC     print()
# MAGIC 
# MAGIC     print("Validation Set")
# MAGIC     start =time.time()
# MAGIC     val_pr = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     val_roc = evaluator.evaluate(valScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('val_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("val areaUnderPR: ", val_pr)
# MAGIC     print("val areaUnderROC: ", val_roc)
# MAGIC     mlflow.log_metric('val_pr' , val_pr)
# MAGIC     mlflow.log_metric('val_roc' ,val_roc)
# MAGIC     
# MAGIC     
# MAGIC     print("Test Set")
# MAGIC     start =time.time()
# MAGIC     test_pr = evaluator.evaluate(testScoreAndLabels, {evaluator.metricName: "areaUnderPR"})
# MAGIC     test_roc = evaluator.evaluate(testScoreAndLabels, {evaluator.metricName: "areaUnderROC"})
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('test_metric_time' ,done - start)    
# MAGIC 
# MAGIC     print("test areaUnderPR: ", test_pr)
# MAGIC     print("test areaUnderROC: ", test_roc)
# MAGIC     mlflow.log_metric('test_pr' , test_pr)
# MAGIC     mlflow.log_metric('test_roc' ,test_roc)      
# MAGIC 
# MAGIC     # Log this model.
# MAGIC     mlflow.spark.log_model(spark_model=rf_model, artifact_path=model_version)
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Save the model out in case we need to reference again in the future
# MAGIC     rf_model.write().overwrite().save(f"dbfs:/mnt/mids-w261/team20SSDK/models/{model_version}")
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('model_save_time' ,done - start)     
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #m3_train_results input is just used for Schema purposes
# MAGIC     varlist = ExtractFeatureImp(rf_model.featureImportances, test_results, "features")
# MAGIC     varlist["order"] = np.arange(1, len(varlist["idx"])+1)
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('extract_feat_imp_time' ,done - start)   
# MAGIC 
# MAGIC     start =time.time()
# MAGIC     #Log these artifacts for graphs and charts later on
# MAGIC     trainScoreAndLabels_pd = trainScoreAndLabels.toPandas()
# MAGIC     valScoreAndLabels_pd = valScoreAndLabels.toPandas()
# MAGIC     testScoreAndLabels_pd = testScoreAndLabels.toPandas()    
# MAGIC     
# MAGIC     #Create Path if it doesn't exist
# MAGIC     path_exists(f'dbfs:/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}')
# MAGIC     
# MAGIC     #Extract it all to evaluate later on.
# MAGIC     varlist.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv', index=False)
# MAGIC     valScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv', index=False)
# MAGIC     trainScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv',index=False)
# MAGIC     testScoreAndLabels_pd.to_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/test_pred.csv',index=False)    
# MAGIC     done = time.time()
# MAGIC     mlflow.log_metric('ouput_to_pd_time' , done - start)
# MAGIC     
# MAGIC     # Log the saved table as an artifact
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')
# MAGIC     mlflow.log_artifact(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/test_pred.csv')    
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Model Output Analysis

# COMMAND ----------

#Bring in all of the model outputs

model_version = 'rf_model_final'
feat_imp = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/feat_imp.csv')
valScoreAndLabels_pd = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/val_pred.csv')
trainScoreAndLabels_pd = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/train_pred.csv')
testScoreAndLabels_pd = pd.read_csv(f'/dbfs/mnt/mids-w261/team20SSDK/models/model_meta/{model_version}/test_pred.csv')

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Feature Importance Rankings

# COMMAND ----------

feat_imp.head(30)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Train Performance

# COMMAND ----------

y_train_true = trainScoreAndLabels_pd["label"]
y_train_pred = trainScoreAndLabels_pd["raw"]
conf_mat_train = confusion_matrix(y_train_true, y_train_pred)

print("Train Set:")
print("Accuracy Score: ", accuracy_score(y_train_true, y_train_pred))
print("F1 Score: ", f1_score(y_train_true, y_train_pred))
print(classification_report(y_train_true, y_train_pred))


df_cm_train = pd.DataFrame(conf_mat_train, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm_train, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Validation Performance

# COMMAND ----------

y_val_true = valScoreAndLabels_pd["label"]
y_val_pred = valScoreAndLabels_pd["raw"]
conf_mat_val = confusion_matrix(y_val_true, y_val_pred)

print("Validation Set:")
print("Accuracy Score: ", accuracy_score(y_val_true, y_val_pred))
print("F1 Score: ", f1_score(y_val_true, y_val_pred))
print(classification_report(y_val_true, y_val_pred))


df_cm_val = pd.DataFrame(conf_mat_val, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm_val, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Test Performance

# COMMAND ----------

y_test_true = testScoreAndLabels_pd["label"]
y_test_pred = testScoreAndLabels_pd["raw"]
conf_mat_test = confusion_matrix(y_test_true, y_test_pred)

print("Test Set:")
print("Accuracy Score: ", accuracy_score(y_test_true, y_test_pred))
print("F1 Score: ", f1_score(y_test_true, y_test_pred))
print(classification_report(y_test_true, y_test_pred))


df_cm_test = pd.DataFrame(conf_mat_test, range(2), range(2))
plt.figure(figsize=(10,7))
sn.set(font_scale=1.4) # for label size
sn.heatmap(df_cm_test, annot=True, annot_kws={"size": 14}) # font size


# |TN FN|
# |FP TP|
plt.show()

# COMMAND ----------


